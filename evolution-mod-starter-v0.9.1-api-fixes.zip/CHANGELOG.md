# Changelog

## 0.9.1 — API compatibility repair pass
- Updated several Minecraft 1.21.11 entity package imports.
- Updated item tooltip context imports to `Item.TooltipContext`.
- Replaced legacy mob position/rotation calls with current position and rotation methods.
- Updated trial-player teleport to use `TeleportTransition`.
- See `PATCH_NOTES_AR.md` for verification scope and limitations.

# EVOLUTION Changelog

## 0.9.1 — Deep audit and Minecraft 1.21.11 API corrections
- Fixed the loot-table callback to use `ResourceKey.identifier()` for Minecraft 1.21.11; the old `location()` call was incompatible with this target and could prevent compilation.
- Added regression checks for the loot-table key accessor so the old API call cannot silently return.
- Retained the 0.9.1 safeguards for GUI button events, attribution of ability kills, bounded area/knockback calculations, trial cleanup, and safe arena placement.
- Expanded the static verifier to 716 checks and ran the 1,000-round stress audit; this remains static analysis and does not replace Gradle compilation or in-game testing.

## 0.9.0 — Kill-driven progression, secret recipes, and mythic ending
- Replaced old automatic grade/rank growth with ten independent, point-funded upgrade branches on each fused essence. Points come from hostile kills while the fused essence is held; major bosses grant 12 points and count toward boss-gated upgrades.
- Added upgrade branches for damage, range, targets, defense, equipment resonance, duration, control, critical effects, elemental synergy, and mobility. Costs scale with branch level; there is no designed gameplay level cap (stored counters safely saturate at Integer.MAX_VALUE), and effect formulas use diminishing returns/safety bounds.
- Added respec, three activation styles, and reusable upgrade-stone catalysts that grant points without being consumed. Fused essences remain reusable and have no activation cooldown.
- Added ten authored binary reactions and eight secret triple recipes with unique effect combinations.
- Added a reusable Rift Key, secret Rift challenge, additional weighted Rift Key loot pool in selected rare structures, and villager trades for stones and the key.
- Added the endgame ritual: carrying all 26 distinct unmerged base essences announces that the game can be finished and opens a 26-slot GUI. Fusing them yields a reusable Mythic Essence that grants a powerful all-powers legend state. Only original unmerged essences qualify.
- Strengthened the Ender Dragon to 1,800 health with three phases, healing bursts, and escalating Enderman reinforcements.
- Updated Arabic/English strings, GUI layout, and the static verifier for the new progression model.

## 0.8.0
- Added base essence drops from hostile mobs, rare Grand Ascension drops, and the reusable chest loot pool for Evolution Stones.
- Added reusable fusion, codex, trials, and random trial rewards.

## Earlier releases
See previous release archives and reports.
