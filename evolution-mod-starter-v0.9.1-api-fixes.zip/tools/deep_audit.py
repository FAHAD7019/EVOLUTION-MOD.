#!/usr/bin/env python3
"""Independent, repeatable static/fuzz audit for EVOLUTION 0.9.1.

This inspects source/resources and model-tests formula invariants. It does not compile
against Minecraft/Fabric nor launch the game; those require the external Gradle deps.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, math, random, re, struct, sys, zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src/main"
RES = SRC / "resources"
JAVA = SRC / "java/dev/evolution/mod"
checks = 0
errors: list[str] = []

def check(ok: bool, label: str) -> None:
    global checks
    checks += 1
    if not ok:
        errors.append(label)

def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON {path.relative_to(ROOT)}: {exc}")
        return None

def java_text() -> str:
    return "\n".join(p.read_text(encoding="utf-8") for p in sorted(JAVA.glob("*.java")))

parser = argparse.ArgumentParser()
parser.add_argument("--rounds", type=int, default=1000)
parser.add_argument("--seed", type=int, default=20261029)
args = parser.parse_args()
rounds = max(1, min(args.rounds, 10000))
rng = random.Random(args.seed)

# 1) Version/build metadata and project skeleton.
props = {}
for line in (ROOT / "gradle.properties").read_text(encoding="utf-8").splitlines():
    line=line.strip()
    if line and not line.startswith("#") and "=" in line:
        k,v=line.split("=",1); props[k.strip()]=v.strip()
meta = read_json(RES / "fabric.mod.json")
check(props.get("minecraft_version")=="1.21.11", "Minecraft target is 1.21.11")
check(props.get("loader_version")=="0.20.1", "Fabric loader pinned")
check(props.get("fabric_api_version")=="0.141.6+1.21.11", "Fabric API pinned to matching MC version")
check(props.get("loom_version")=="1.14.10", "Loom version pinned")
check(props.get("mod_version")=="0.9.1", "release version is 0.9.1")
check(bool(meta) and meta.get("id")=="evolution", "fabric.mod.json mod id matches registrations")
check(bool(meta) and meta.get("depends",{}).get("minecraft")=="~1.21.11", "Fabric metadata MC dependency matches build")
check(bool(meta) and meta.get("depends",{}).get("java")==">=21", "Java 21 runtime declared")
check(bool(meta) and meta.get("entrypoints",{}).get("main")==["dev.evolution.mod.EvolutionMod"], "main entrypoint registered")
check(bool(meta) and meta.get("entrypoints",{}).get("client")==["dev.evolution.mod.EvolutionClient"], "client entrypoint registered")
check(bool(meta) and meta.get("accessWidener")=="evolution.accesswidener", "access widener referenced")
check((RES/"evolution.accesswidener").exists(), "access widener exists")
check("net/minecraft/world/inventory/MenuType <init>" in (RES/"evolution.accesswidener").read_text(), "private MenuType constructor is explicitly widened")
check("net.fabricmc.fabric-loom-remap" in (ROOT/"build.gradle").read_text(), "obfuscated 1.21.11 uses Loom remap plugin")
check("JavaLanguageVersion.of(21)" in (ROOT/"build.gradle").read_text(), "Gradle toolchain targets Java 21")
wf=(ROOT/".github/workflows/build.yml").read_text(encoding="utf-8")
check("evolution-0.9.1.jar" in wf and "gradle/actions/setup-gradle" in wf, "CI config builds and uploads versioned JAR")

# 2) Parse every JSON resource, compare locale keys and placeholders.
json_files=sorted(RES.rglob("*.json"))
check(len(json_files)>50, f"found {len(json_files)} JSON resource files")
all_json={}
for path in json_files:
    obj=read_json(path)
    all_json[path]=obj
    check(obj is not None, f"JSON parses: {path.relative_to(ROOT)}")
langs={name: read_json(RES/f"assets/evolution/lang/{name}.json") for name in ("en_us","ar_sa")}
if all(langs.values()):
    en, ar=langs["en_us"], langs["ar_sa"]
    check(set(en)==set(ar), f"Arabic/English translation keys match ({len(en)} each)")
    for key in set(en)&set(ar):
        en_placeholders=len(re.findall(r"%(?:\d+\$)?[sdif]", en[key])) if isinstance(en[key],str) else 0
        ar_placeholders=len(re.findall(r"%(?:\d+\$)?[sdif]", ar[key])) if isinstance(ar[key],str) else 0
        check(en_placeholders==ar_placeholders, f"placeholder parity: {key}")
    for diff in ("easy","medium","hard","impossible"):
        check(f"difficulty.evolution.{diff}" in en and f"difficulty.evolution.{diff}" in ar,
              f"difficulty label localized: {diff}")

source=java_text()
fixed_keys=set(re.findall(r'Component\.translatable\("([^"+]+)"',source))
fixed_keys = {key for key in fixed_keys if not key.endswith(".") and key != "container.inventory"}
for locale, lang in langs.items():
    if lang:
        missing=sorted(k for k in fixed_keys if k not in lang and k!="container.inventory")
        check(not missing, f"all fixed Java translation keys exist in {locale} ({len(missing)} missing)")
        if missing: errors.extend(f"missing {locale} key: {k}" for k in missing)
check("displayName" not in (JAVA/"TrialSystem.java").read_text() + (JAVA/"TrialSigilItem.java").read_text(), "difficulty labels no longer leak hard-coded Arabic into English UI")

# 3) Check all registered items have item definition, model, and valid texture.
mods=(JAVA/"ModItems.java").read_text(encoding="utf-8")
registered=set(re.findall(r'\b(?:register|registerUtility)\("([a-z0-9_]+)"',mods))
item_defs={p.stem:p for p in (RES/"assets/evolution/items").glob("*.json")}
models={p.stem:p for p in (RES/"assets/evolution/models/item").glob("*.json")}
textures={p.stem:p for p in (RES/"assets/evolution/textures/item").glob("*.png")}
check(len(registered)==38, f"38 unique item registrations found (found {len(registered)})")
check(registered==set(item_defs), f"item definitions exactly match registered items (missing={sorted(registered-set(item_defs))}; orphan={sorted(set(item_defs)-registered)})")
check(registered==set(models), f"item models exactly match registered items (missing={sorted(registered-set(models))}; orphan={sorted(set(models)-registered)})")
check(registered==set(textures), f"item textures exactly match registered items (missing={sorted(registered-set(textures))}; orphan={sorted(set(textures)-registered)})")
for item, path in item_defs.items():
    obj=all_json.get(path)
    model=(obj or {}).get("model",{}).get("model","")
    if model.startswith("evolution:item/"):
        check(model.split("/",1)[1] in models, f"item definition {item} references existing model")
    else:
        check(False, f"item definition {item} has expected model reference")
for model, path in models.items():
    obj=all_json.get(path) or {}
    for tex in obj.get("textures",{}).values():
        if tex.startswith("evolution:item/"):
            check(tex.split("/",1)[1] in textures, f"model {model} references an existing texture")
        else:
            check(tex.startswith("minecraft:"), f"model {model} references a namespaced texture")
# Full PNG decode and consistent, non-zero dimensions. PIL also verifies image CRCs/chunks.
try:
    from PIL import Image
    for item,path in textures.items():
        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            check(im.width>0 and im.height>0 and im.width<=1024 and im.height<=1024, f"PNG dimensions acceptable: {item} {im.size}")
except ImportError:
    check(False, "Pillow installed for full texture validation")

# 4) Recipe resources, IDs, and access-widener.
recipe_paths=sorted((RES/"data/evolution/recipe").glob("*.json"))
check(len(recipe_paths)>=4, "all expected custom recipes discovered")
for path in recipe_paths:
    obj=all_json.get(path) or {}
    rid=(obj.get("result") or {}).get("id","")
    check(rid.startswith("evolution:") and rid.split(":",1)[1] in registered, f"recipe result exists: {path.name}")
    for keyval in (obj.get("key") or {}).values():
        iid=keyval.get("item","")
        if iid.startswith("evolution:"):
            check(iid.split(":",1)[1] in registered, f"recipe ingredient exists: {iid}")
        else:
            check(iid.startswith("minecraft:"), f"recipe ingredient namespaced: {iid}")

# 5) Power registry, GUI buttons and all combinations/permutations.
ess=(JAVA/"EssenceItem.java").read_text(encoding="utf-8")
menu=(JAVA/"FusionMenu.java").read_text(encoding="utf-8")
screen=(JAVA/"FusionScreen.java").read_text(encoding="utf-8")
forge=(JAVA/"MythicForgeMenu.java").read_text(encoding="utf-8")
forge_screen=(JAVA/"MythicForgeScreen.java").read_text(encoding="utf-8")
trial=(JAVA/"TrialSystem.java").read_text(encoding="utf-8")
fsig=(JAVA/"TrialSigilItem.java").read_text(encoding="utf-8")
fd=(JAVA/"FusionData.java").read_text(encoding="utf-8")
enum_match=re.search(r"public enum Power\s*\{([^}]*)\}",ess,re.S)
powers=[x.strip() for x in enum_match.group(1).split(",") if x.strip()] if enum_match else []
check(len(powers)==26 and len(set(powers))==26, "26 unique Power enum values")
check(len(registered)==38, "all 26 powers plus 12 utility items are registered")
check("handleInventoryButtonClick(menu.containerId, id)" in screen, "fusion screen uses valid menu button channel")
check("handleInventoryButtonClick(menu.containerId, MythicForgeMenu.BUTTON_FORGE)" in forge_screen, "mythic screen uses valid menu button channel")
check("ContainerInput.ButtonClick" not in screen+forge_screen and "handleContainerInput" not in screen+forge_screen, "obsolete button-click API absent")
# Verify all 15 GUI button IDs are distinct and handled in clickMenuButton.
button_defs=re.findall(r"public static final int (BUTTON_[A-Z_]+) = (\d+);",menu)
button_nums=[int(v) for _,v in button_defs]
check(len(button_defs)==15 and len(button_nums)==len(set(button_nums)), "15 fusion GUI button IDs are unique")
for name, _ in button_defs:
    check(name in menu[menu.find("boolean clickMenuButton"):menu.find("private boolean fuse")], f"menu action has handler: {name}")
check("private static boolean repulse" in ess and "Math.min(5.0D" in ess and "Math.min(2.5D" in ess, "repulse movement is bounded against extreme upgrades")
check("Heightmap.Types.MOTION_BLOCKING" in trial and "trial.no_room_here" in trial, "trial chamber avoids leaf canopies and rejects locations without vertical clearance")
check("if (world.addFreshEntity(mob)) track(run, mob);" in trial, "failed hostile spawns cannot leave stale trial entity tracking")
check("bossSpawnFailed" in trial and "cleanupRun(run)" in trial and "trial.spawn_failed" in trial, "failed boss spawn cleans up rather than allowing a reward without the boss")
check("run.difficulty.label()" in trial and "difficulty.label()" in trial and "Component label()" in trial, "trial messages use localized difficulty components")
check("upgradeLevel(stack, upgrade) >= Integer.MAX_VALUE" in fd, "saturated upgrade counters cannot consume points without increasing")
check("currentLevel >= Integer.MAX_VALUE" in fd, "milestone arithmetic avoids integer overflow at maximum counter")
check("specialKills(stack, upgrade) >= requiredSpecialKills(stack, upgrade)" in fd, "central upgrade validation enforces creature-specific requirements")
check("world.damageSources().magic().typeHolder(), player, player" in ess, "magic damage kills retain player ownership")
check("private record LifeLeechState(ResourceKey<Level> dimension, long expiresAt)" in (JAVA/"EvolutionSystem.java").read_text(), "life-leech timer is dimension-local")
check("ServerLifecycleEvents.SERVER_STOPPING.register" in trial and "abandonTrial(fallenPlayer.getUUID())" in trial, "trials clean up on stop and player death")
check("Math.min(64.0D" in ess and "Math.min(64, base + bonus)" in ess, "area and target caps exist")
check("all 26" in (JAVA/"MythicForgeMenu.java").read_text() or "INGREDIENT_SLOTS" in forge, "mythic ritual has fixed ingredient slot count")
check("occupied != INGREDIENT_SLOTS" in forge and "found.size() != EssenceItem.Power.values().length" in forge, "mythic forge rejects missing or duplicate powers")
check("instanceof EssenceItem" in forge and "readPowers" not in forge, "mythic forge accepts original essences, not fused stones")

ordinary=[p for p in powers if p!="GRAND_ASCENSION"]
binary=list(itertools.combinations(ordinary,2))
triples=list(itertools.combinations(ordinary,3))
check(len(ordinary)==25 and len(binary)==300, "300 binary combos enumerated from 25 fusible powers")
check(len(triples)==2300, "2300 triple combos enumerated from 25 fusible powers")
def signature(xs): return "+".join(sorted(xs,key=lambda x:powers.index(x)))
perm_count=0
for combo in binary:
    expected=signature(combo)
    check(len(set(itertools.permutations(combo)))==2, f"binary permutation count {combo}")
    for perm in itertools.permutations(combo):
        check(signature(perm)==expected, f"binary signature order-invariant {combo}"); perm_count+=1
for combo in triples:
    expected=signature(combo)
    for perm in itertools.permutations(combo):
        check(signature(perm)==expected, f"triple signature order-invariant {combo}"); perm_count+=1
check(perm_count==14400, f"all {perm_count} binary/triple input permutations checked")

# Verify every power has code case and matching translation/item/model.
activation=ess[ess.find("public static boolean activatePower"):ess.find("private static MobEffectInstance effect(")]
for power in powers:
    lower=power.lower()
    check(f"case {power} ->" in activation, f"power behavior implemented: {power}")
    check(f"{lower}_essence" in registered, f"power item registered: {power}")
    check(f"item.evolution.{lower}_essence" in langs["en_us"] and f"tooltip.evolution.essence.{lower}" in langs["ar_sa"], f"power translation entries exist: {power}")

# 6) Exhaustive weighted loot intervals: model matches literal switch cutoffs and every roll maps once.
choose=trial[trial.find("private static Item chooseStone"):trial.find("private static List<ItemStack> bonusLoot")]
check("random.nextInt(1000)" in choose, "trial stone reward uses a 1000-point random roll")
cutoffs={
 "EASY":[740,940,980,995,1000],
 "MEDIUM":[440,790,940,990,1000],
 "HARD":[190,490,790,960,1000],
 "IMPOSSIBLE":[10,50,250,600,1000],
}
for diff, limits in cutoffs.items():
    check(all(0<limits[i]<=1000 for i in range(5)) and limits==sorted(limits), f"{diff} stone probability thresholds valid")
    counts=[0]*5
    for roll in range(1000):
        category=next(i for i,limit in enumerate(limits) if roll<limit)
        counts[category]+=1
    check(sum(counts)==1000 and all(c>0 for c in counts), f"{diff} all 1000 loot rolls map to exactly one stone tier")
    check(counts==[limits[0],limits[1]-limits[0],limits[2]-limits[1],limits[3]-limits[2],1000-limits[3]], f"{diff} empirical exhaustive counts match reward weights")
loot=(JAVA/"StoneLootModifier.java").read_text(encoding="utf-8")
weights={"village":[9000,600,300,80,19,1],"advanced":[7000,1700,850,330,100,20],"mid":[8000,1200,550,200,45,5],"early":[8500,950,400,120,25,5]}
for name, vals in weights.items():
    check(sum(vals)==10000, f"{name} loot weights sum to 10000")
check("LootTableEvents.MODIFY.register" in loot and "if (!source.isBuiltin()) return;" in loot, "loot modifier preserves datapack/nonbuiltin tables and adds to builtins")
check("key.identifier()" in loot and "key.location()" not in loot, "loot tables use the current 1.21.11 ResourceKey accessor")
check("10000 - keyWeight" in loot, "Rift Key uses a separate independently weighted roll")

# 7) Fuzz arithmetic/model invariants over 1000 rounds (100 cases each).
def upgrade_cost(level, branch):
    base=1 if branch==0 else 2 if branch in (1,3,5,9) else 3
    return base+math.floor(math.sqrt(level))
def target_limit(base,up): return max(1,min(64,base+math.floor(math.sqrt(max(0,up))*2)))
def radius(base,tier,rng_up): return max(1.0,min(64.0,base+min(12,math.sqrt(max(0,tier))*1.75)+min(28,math.sqrt(max(0,rng_up))*1.1)))
def repulse(tier,control):
    ctl=min(2.0,max(0,control)*0.02)
    return min(5.0,1.45+min(18,max(0,tier))*0.12+ctl), min(2.5,0.48+min(18,max(0,tier))*0.035+ctl*0.35)
for rnd in range(rounds):
    # Re-read every JSON resource in every round; this catches interrupted/corrupted package edits too.
    for path in json_files:
        try: json.loads(path.read_text(encoding="utf-8"))
        except Exception: check(False, f"round {rnd}: JSON remains parseable: {path.relative_to(ROOT)}")
        else: checks += 1
    for _ in range(100):
        level=rng.randrange(0,2**31-1)
        branch=rng.randrange(10)
        c=upgrade_cost(level,branch)
        check(c>0 and c<50000, f"round {rnd}: upgrade cost remains positive/safe")
        if level < 2**31-2:
            check(upgrade_cost(level+1,branch)>=c, f"round {rnd}: upgrade cost monotonic")
        up=rng.randrange(0,2**31-1)
        base=rng.randrange(1,20)
        check(1<=target_limit(base,up)<=64, f"round {rnd}: target count bounded")
        rr=radius(float(base),rng.randrange(0,1001),up)
        check(1<=rr<=64, f"round {rnd}: radius bounded")
        hx,vy=repulse(rng.randrange(0,1001),rng.randrange(0,1001))
        check(0<=hx<=5 and 0<=vy<=2.5, f"round {rnd}: repulse impulse bounded")
        next_level=level+1
        boss_req=0 if next_level<6 else 1+(next_level-6)//5
        check(boss_req>=0, f"round {rnd}: boss requirements do not become negative")
        special_req=0 if (branch not in (1,6,7,8) or next_level<5 or next_level%5) else (next_level//5)*20
        check(special_req>=0, f"round {rnd}: special kill thresholds do not become negative")

# 8) Java source parse-only: run separately by caller; do syntax delimiter checks here.
for path in sorted(JAVA.glob("*.java")):
    text=path.read_text(encoding="utf-8")
    check(text.count("{")==text.count("}"), f"balanced braces: {path.name}")
    check("TODO: implement" not in text, f"no bare implementation placeholder: {path.name}")
check("register(" in mods and "registerUtility(" in mods, "registration helpers exist")

print(f"EVOLUTION DEEP STATIC AUDIT: {'PASS' if not errors else 'FAIL'}")
print(f"Unique structural/resource checks plus {rounds} stress rounds; assertions evaluated: {checks:,}; RNG seed: {args.seed}")
print(f"JSON resources parsed per round: {len(json_files)}; exhaustive permutations: {perm_count:,}; loot rolls exhaustively checked: 4,000")
if errors:
    print(f"FAILURES: {len(errors)}")
    for e in errors[:100]: print("FAIL:", e)
    if len(errors)>100: print(f"... {len(errors)-100} additional failures omitted")
    sys.exit(1)
print("PASS: no static audit failures. This still does not replace Gradle type-check/build or Minecraft runtime testing.")
