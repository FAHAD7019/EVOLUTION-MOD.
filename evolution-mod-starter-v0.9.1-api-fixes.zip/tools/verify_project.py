#!/usr/bin/env python3
"""Static consistency checks for EVOLUTION 0.9.1. This does not compile or launch Minecraft."""
from __future__ import annotations
import hashlib
import json
import re
import struct
import sys
from itertools import combinations, permutations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'src/main/java/dev/evolution/mod'
RES = ROOT / 'src/main/resources'
ASSETS = RES / 'assets/evolution'
errors: list[str] = []
checks: list[str] = []

def check(ok: bool, message: str) -> None:
    (checks if ok else errors).append(message)

def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'Invalid JSON {path.relative_to(ROOT)}: {exc}')
        return None

# Parse every JSON file, not just the ones referenced below.
json_files = sorted(RES.rglob('*.json'))
for path in json_files:
    read_json(path)
check(bool(json_files), f'all {len(json_files)} resource JSON files were discovered and parsed')

meta = read_json(RES / 'fabric.mod.json')
check(bool(meta) and meta.get('id') == 'evolution', 'Fabric metadata declares the evolution mod id')
check(bool(meta) and meta.get('version') == '${version}', 'Fabric metadata retains the expandable build version')
check(bool(meta) and meta.get('depends', {}).get('minecraft') == '~1.21.11', 'Fabric metadata targets Minecraft 1.21.11')
check(bool(meta) and meta.get('entrypoints', {}).get('client') == ['dev.evolution.mod.EvolutionClient'], 'client GUI initializer is declared')
check(bool(meta) and meta.get('accessWidener') == 'evolution.accesswidener', 'metadata declares the access widener')

props = {}
for line in (ROOT / 'gradle.properties').read_text(encoding='utf-8').splitlines():
    line = line.strip()
    if line and not line.startswith('#') and '=' in line:
        key, value = line.split('=', 1)
        props[key.strip()] = value.strip()
check(props.get('minecraft_version') == '1.21.11', 'Gradle properties target Minecraft 1.21.11')
check(props.get('mod_version') == '0.9.1', 'release version is 0.9.1')
check(props.get('fabric_api_version') == '0.141.6+1.21.11', 'Fabric API is pinned to 1.21.11')
check(props.get('loader_version') == '0.20.1', 'Fabric Loader version is pinned')
check('accessWidenerPath' in (ROOT / 'build.gradle').read_text(encoding='utf-8'), 'Loom build file enables the access widener')
check('key.identifier()' in (JAVA / 'StoneLootModifier.java').read_text(encoding='utf-8')
      and 'key.location()' not in (JAVA / 'StoneLootModifier.java').read_text(encoding='utf-8'),
      'loot-table resource keys use the Minecraft 1.21.11 identifier() API')
check((ROOT / 'BUILD_GUIDE_AR.md').exists(), 'Arabic build guide is included')
check('evolution-0.9.1.jar' in (ROOT / '.github/workflows/build.yml').read_text(encoding='utf-8'), 'CI workflow targets the 0.9.1 JAR artifact')
check((RES / 'evolution.accesswidener').exists(), 'access widener file exists')

mods = (JAVA / 'ModItems.java').read_text(encoding='utf-8')
ess = (JAVA / 'EssenceItem.java').read_text(encoding='utf-8')
evo = (JAVA / 'EvolutionSystem.java').read_text(encoding='utf-8')
fusion = (JAVA / 'FusionData.java').read_text(encoding='utf-8')
menu = (JAVA / 'FusionMenu.java').read_text(encoding='utf-8')
screen = (JAVA / 'FusionScreen.java').read_text(encoding='utf-8')
fused = (JAVA / 'FusedEssenceItem.java').read_text(encoding='utf-8')
loot = (JAVA / 'StoneLootModifier.java').read_text(encoding='utf-8')
trades = (JAVA / 'EvolutionTrades.java').read_text(encoding='utf-8')
trial = (JAVA / 'TrialSystem.java').read_text(encoding='utf-8')
forge = (JAVA / 'MythicForgeMenu.java').read_text(encoding='utf-8')
forge_screen = (JAVA / 'MythicForgeScreen.java').read_text(encoding='utf-8')
mythic = (JAVA / 'MythicEssenceItem.java').read_text(encoding='utf-8')

# Additional regression checks from the v0.9.1 deep audit.
forge_screen = (JAVA / 'MythicForgeScreen.java').read_text(encoding='utf-8')
check('handleInventoryButtonClick(menu.containerId, id)' in screen,
      'fusion UI buttons use the Minecraft 1.21.11 menu-button API')
check('handleInventoryButtonClick(menu.containerId, MythicForgeMenu.BUTTON_FORGE)' in forge_screen,
      'mythic forge button uses the Minecraft 1.21.11 menu-button API')
check('ContainerInput.ButtonClick' not in screen + forge_screen and 'handleContainerInput' not in screen + forge_screen,
      'obsolete/nonexistent button-click calls are absent')
check('new net.minecraft.world.damagesource.DamageSource' in ess and 'world.damageSources().magic().typeHolder(), player, player' in ess,
      'spell damage retains magic type and records the player as attacker for per-stone kill progression')
check('recordKill(fusedInHand, bossKill, entity)' in evo and 'damageSource.getEntity() instanceof ServerPlayer player' in evo,
      'server kill event awards points to a fused essence held by the player who caused the kill')
check('private record LifeLeechState(ResourceKey<Level> dimension, long expiresAt)' in evo
      and 'state.dimension().equals(world.dimension())' in evo,
      'Life Leech expiry uses the activation dimension clock')
check('ServerLifecycleEvents.SERVER_STOPPING.register' in trial and 'abandonTrial(fallenPlayer.getUUID())' in trial,
      'trials are cleaned up on server stop and player death')
check('private static void cleanupRun(TrialRun run)' in trial and 'tracked.discard()' in trial and 'openExit(run)' in trial,
      'abandoned trials remove tracked mobs and reopen the exit')
check('targetLimit(int base, int targetUpgrade)' in ess and 'Math.min(64, base + bonus)' in ess
      and 'Math.min(64.0D' in ess and 'if (targetCount >= 64) break;' in ess,
      'unbounded upgrade counters cannot create unbounded target scans or mob loops')
check('source.getEntity() instanceof ServerPlayer attacker' in evo and 'Math.min(24000, ticks)' in ess,
      'life leech attribution and glowing durations are bounded')
check('ratio = dragon.getHealth() / Math.max(1.0D, dragon.getMaxHealth());' in evo
      and 'Recompute after healing so a single oversized hit cannot trigger both phases at once.' in evo,
      'dragon phase-three threshold is recalculated after phase-two healing')
check('specialKills(stack, upgrade) >= requiredSpecialKills(stack, upgrade)' in fusion,
      'the central upgrade authorization checks branch-specific mob-kill requirements')

item_ids = set(re.findall(r'register\("([a-z_]+_essence)"', mods))
enum_match = re.search(r'public enum Power\s*\{([^}]*)}', ess, re.S)
powers = [part.strip() for part in enum_match.group(1).split(',') if part.strip()] if enum_match else []
check(len(item_ids) == 26, f'26 essence item IDs registered (found {len(item_ids)})')
check(len(powers) == 26 and len(set(powers)) == 26, f'26 unique powers registered in the power enum (found {len(powers)})')
for power in powers:
    check(power.lower() + '_essence' in item_ids, f'{power} maps to an item registration')
check('public static boolean activatePower' in ess and 'public static void spawnActivationVisual' in ess, 'base power activation and visuals can be reused by fused and mythic items')
activation_start = ess.find('public static boolean activatePower')
activation_end = ess.find('private static MobEffectInstance effect', activation_start)
activation_body = ess[activation_start:activation_end] if activation_start >= 0 and activation_end > activation_start else ''
for power in powers:
    check(f'case {power} ->' in activation_body, f'{power} has an activation implementation')
check('world.getRandom().nextFloat() < 0.005F' in evo, 'Grand Ascension keeps an independent 0.5% drop roll')
check('held.shrink(1)' not in ess and 'Essences are reusable catalysts' in ess, 'base essences are not consumed by activation')
check('COOLDOWN_TICKS' not in fused and 'isOnCooldown(this)' not in fused and 'addCooldown(this' not in fused, 'fused essences have no activation cooldown')

# Fusion mathematics and point-funded progression (not automatic grade ranks).
check('enum Upgrade { DAMAGE, RANGE, TARGETS, DEFENSE, EQUIPMENT, DURATION, CONTROL, CRITICAL, ELEMENTAL, MOBILITY }' in fusion, 'all ten upgrade branches are declared')
for key in ('DAMAGE_KEY','RANGE_KEY','TARGETS_KEY','DEFENSE_KEY','EQUIPMENT_KEY','DURATION_KEY','CONTROL_KEY','CRITICAL_KEY','ELEMENTAL_KEY','MOBILITY_KEY'):
    check(key in fusion, f'{key} is present in per-stone saved progression data')
check('recordKill(ItemStack stack, boolean boss, net.minecraft.world.entity.LivingEntity victim)' in fusion and 'int awarded = boss ? 12 : 1' in fusion, 'regular hostile kills and major bosses award per-stone points')
check(all(name in fusion for name in ('SKELETON_KILLS_KEY','ENDERMAN_KILLS_KEY','SPIDER_KILLS_KEY','CREEPER_KILLS_KEY')) and 'requiredSpecialKills' in fusion and 'specialKills' in fusion, 'four monster-specific kill counters feed gated upgrades')
check('upgrade != Upgrade.CRITICAL && upgrade != Upgrade.RANGE' in fusion and 'nextLevel % 5 != 0' in fusion, 'special monster milestones gate selected branches only at every fifth level')
check('message.evolution.skill.special_kills_needed' in (JAVA/'FusionMenu.java').read_text(encoding='utf-8'), 'GUI reports missing branch-specific kill milestones')
check('requiredBossKills' in fusion and 'bossKills(stack) >= requiredBossKills(stack, upgrade)' in fusion, 'later upgrade levels can require boss kills')
check('upgradeCost' in fusion and 'Math.sqrt((double) level)' in fusion and 'canUpgrade' in fusion, 'upgrade cost increases with branch level without a fixed branch-level cap')
check('public static int respec(ItemStack stack)' in fusion and 'tag.putInt(STYLE_KEY, 0)' in fusion, 'respec refunds spent points and resets branch choices')
check('recordSuccessfulUse(held)' in fused and 'Ten separate upgrade branches' in fused, 'successful activations are tracked without auto-ranking the stone')
check('baseTier' not in fusion and 'useCount(stack) / 10' not in fusion, 'legacy weak/medium/normal/strong grade system is absent')
check('BUTTON_DAMAGE' in menu and 'BUTTON_MOBILITY' in menu and 'BUTTON_RESPEC' in menu and 'BUTTON_STYLE' in menu, 'menu connects all ten branches, style and respec')
check('addSkillButton' in screen and 'BUTTON_ELEMENTAL' in screen, 'screen exposes compact skill tree buttons')
check('stone.shrink(1)' not in fusion and 'never consumed' in fusion, 'upgrade stones are reusable and not consumed by point upgrades')
check('POINTS_KEY' in fusion and 'CustomData.set(DataComponents.CUSTOM_DATA, stack, tag)' in fusion, 'points and upgrades persist on the fused item itself')
check('binarySynergyKey' in fusion and 'secretTripleKey' in fusion and 'thermal_shock' in fusion, 'binary elemental reactions and secret triple recipes are implemented')
check(fusion.count('return "') >= 20, 'fusion data contains multiple authored synergy/triple recipe identifiers')
check('applyDefensiveBranch' in fused and 'applyEquipmentResonance' in fused, 'defense and equipment branches affect gameplay')
check('applyBinaryBonus' in fused and 'applyTripleBonus' in fused, 'binary and triple fusions apply additional effect bundles')

# Canonical combo count and order invariance.
ordinary = [power for power in powers if power != 'GRAND_ASCENSION']
check(len(ordinary) == 25, '25 ordinary powers are fusable')
check(len(list(combinations(ordinary, 2))) == 300, 'there are 300 unique binary combinations')
check(len(list(combinations(ordinary, 3))) == 2300, 'there are 2,300 unique triple combinations')
check(len({tuple(sorted(pair, key=ordinary.index)) for pair in permutations(ordinary, 2)}) == 300, 'binary slot ordering canonicalizes to 300 unique combinations')
check(len({tuple(sorted(group, key=ordinary.index)) for group in permutations(ordinary, 3)}) == 2300, 'triple slot ordering canonicalizes to 2,300 unique combinations')

# Loot, trading, random trials and secret zone.
check('LootTableEvents.MODIFY.register' in loot and 'source.isBuiltin()' in loot, 'loot is added to builtin vanilla loot tables without replacing them')
check(all(f'ModItems.STONE_{kind}' in loot for kind in ('COMMON','REFINED','SUPERIOR','LEGENDARY','VOID')), 'all five stone rarities participate in random structure loot')
weights = re.findall(r'new Weights\((\d+), (\d+), (\d+), (\d+), (\d+), (\d+)\)', loot)
check(len(weights) == 4 and all(sum(map(int, row)) == 10000 for row in weights), 'all four structure rarity tables sum to 10,000 weights')
check('riftKeyWeight' in loot and 'ModItems.RIFT_KEY' in loot, 'rare Rift Key has an independent loot roll')
check('TradeOfferHelper.registerVillagerOffers' in trades and 'ModItems.RIFT_KEY' in trades, 'villagers trade stones and the Rift Key')
check('CommandRegistrationCallback.EVENT.register' in trial and all(f'Commands.literal("{difficulty}")' in trial for difficulty in ('easy','medium','hard','impossible')), 'trials expose four difficulty commands')
check('bonusLootChance' in trial and 'bonusStoneChance' in trial and 'chooseStone(run.difficulty, random)' in trial, 'trial loot and extra-stone chances use separate random rolls')
check('drop(run.world, run.center, new ItemStack(stone, 1))' in trial, 'each successful trial guarantees one random stone')
check('buildChamber' in trial and 'Blocks.TINTED_GLASS' in trial and 'openExit(run)' in trial, 'trial system builds a sealed arena and opens its exit after completion')
check('startSecretRift' in trial and 'IMPOSSIBLE' in trial, 'Rift Key has a secret impossible-difficulty challenge path')

# Mythic finale: exactly all separate unmerged original essences.
check('announceMythicReady' in evo and 'evolution_mythic_ready_announced' in evo and 'message.evolution.mythic.ready' in evo, 'collecting all original essences announces that the game can be finished')
check('Power.values().length' in evo and 'new MythicForgeMenu' in evo, 'all 26 distinct original essences trigger the forge GUI')
check('INGREDIENT_SLOTS = EssenceItem.Power.values().length' in forge, 'mythic forge has one ingredient slot per base essence')
check('instanceof EssenceItem' in forge and '!found.add(essence.getPower())' in forge and 'occupied != INGREDIENT_SLOTS' in forge, 'mythic forge rejects fused stones, duplicates, and missing originals')
check('input.removeItem(i, 1)' in forge and 'ModItems.MYTHIC_ESSENCE' in forge, 'mythic ritual consumes the 26 originals and grants the final essence')
check('screen.evolution.mythic_forge.title' in evo and 'BUTTON_FORGE' in forge_screen, 'mythic collection opens a GUI with a forge action')
check('evolution_is_legend' in mythic and 'MobEffects.STRENGTH' in mythic and 'Power.values()' in mythic, 'reusable Mythic Essence activates all powers and grants a legend state')
check('health.setBaseValue(1800.0D)' in evo and 'ratio <= 0.70D' in evo and 'ratio <= 0.25D' in evo, 'Ender Dragon has 1,800 health and three phase thresholds')
check('spawnDragonAdds(world, dragon, 8)' in evo and 'spawnDragonAdds(world, dragon, 16)' in evo, 'Ender Dragon phases summon escalating Enderman reinforcements')
check('imageHeight = 252' in forge_screen and 'inventoryLabelY = 137' in forge_screen, 'mythic GUI has non-overlapping progress and inventory areas')

# Collectibles, item models/textures and recipe resources.
asset_ids = item_ids | {'fused_essence','fusion_altar','fusion_codex','stone_common','stone_refined','stone_superior','stone_legendary','stone_void','trial_sigil','mythic_altar','mythic_essence','rift_key'}
models = {path.stem for path in (ASSETS / 'models/item').glob('*.json')}
item_defs = {path.stem for path in (ASSETS / 'items').glob('*.json')}
textures = {path.stem for path in (ASSETS / 'textures/item').glob('*.png')}
check(models == asset_ids, f'one item model per registered item ({len(models)} models)')
check(item_defs == asset_ids, f'one item definition per registered item ({len(item_defs)} definitions)')
check(textures == asset_ids, f'one texture per registered item ({len(textures)} textures)')
hashes = [hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted((ASSETS / 'textures/item').glob('*.png'))]
check(len(hashes) == len(set(hashes)), 'all item PNG textures are distinct')
for path in sorted((ASSETS / 'items').glob('*.json')):
    obj = read_json(path)
    if obj:
        model_obj = obj.get('model', {})
        check(model_obj.get('type') == 'minecraft:model' and model_obj.get('model') == f'evolution:item/{path.stem}', f'{path.name} points to its item model')
for path in sorted((ASSETS / 'models/item').glob('*.json')):
    obj = read_json(path)
    if obj:
        check(obj.get('parent') == 'minecraft:item/generated', f'{path.name} uses generated-item parent')
        check(obj.get('textures', {}).get('layer0') == f'evolution:item/{path.stem}', f'{path.name} references its own item texture')
for path in sorted((ASSETS / 'textures/item').glob('*.png')):
    data = path.read_bytes()
    valid = len(data) >= 33 and data[:8] == b'\x89PNG\r\n\x1a\n' and data[12:16] == b'IHDR'
    check(valid, f'{path.name} has a valid PNG header')
    if valid:
        width, height, bit_depth, color_type, compression, filtering, interlace = struct.unpack('>IIBBBBB', data[16:29])
        check((width, height) in {(32, 32), (16, 16)}, f'{path.name} has 16x16 or 32x32 pixel-art dimensions')
        check(color_type == 6, f'{path.name} is RGBA with alpha channel')
        check(b'IDAT' in data and b'IEND' in data, f'{path.name} contains image data and end chunk')

langs = {locale: read_json(ASSETS / f'lang/{locale}.json') for locale in ('en_us', 'ar_sa')}
if all(value is not None for value in langs.values()):
    check(set(langs['en_us']) == set(langs['ar_sa']), 'Arabic and English language keys match exactly')
    for locale, lang in langs.items():
        for item_id in item_ids | {'fused_essence','fusion_altar','fusion_codex','stone_common','stone_refined','stone_superior','stone_legendary','stone_void','trial_sigil','mythic_altar','mythic_essence','rift_key'}:
            check(f'item.evolution.{item_id}' in lang, f'{locale} names {item_id}')
        for power in powers:
            slug = power.lower().removesuffix('_essence')
            check(f'tooltip.evolution.essence.{slug}' in lang, f'{locale} has a tooltip for {slug}')
            check(f'message.evolution.power.{slug}' in lang, f'{locale} has a use message for {slug}')
        for suffix in ('damage','range','targets','defense','equipment','duration','control','critical','elemental','mobility'):
            check(f'upgrade.evolution.{suffix}' in lang, f'{locale} names the {suffix} upgrade')
        for style in ('0','1','2'):
            check(f'style.evolution.{style}' in lang, f'{locale} names activation style {style}')
        for name in ('thermal_shock','plasma_burst','cryo_storm','soul_hunt','seismic_wall','glacier_breath','renewal','windrunner','night_rider','deep_seeker'):
            check(f'synergy.evolution.{name}' in lang, f'{locale} names binary synergy {name}')
        for name in ('storm_phantom','prism_tempest','eternal_cycle','fortress','night_reaper','glacier_diver','relic_hunter','overdrive'):
            check(f'secret.evolution.{name}' in lang, f'{locale} names secret triple {name}')
        for key in ('message.evolution.skill.kill_points','message.evolution.mythic.ready','message.evolution.mythic.legend','message.evolution.dragon.phase_two','message.evolution.dragon.phase_three','label.evolution.mythic.progress','message.evolution.trial.failed'):
            check(key in lang, f'{locale} includes {key}')

# Every fixed Component.translatable string in Java must exist in both mod language files.
source_text = '\n'.join(path.read_text(encoding='utf-8') for path in sorted(JAVA.glob('*.java')))
fixed_keys = set(re.findall(r'Component\.translatable\(\"([^\"]+)\"', source_text))
fixed_keys = {key for key in fixed_keys if not key.endswith('.') and key != 'container.inventory'}
missing_fixed = {locale: sorted(key for key in fixed_keys if key not in lang)
                 for locale, lang in langs.items() if lang is not None}
check(all(not missing for missing in missing_fixed.values()),
      'all fixed Java translation keys exist in both Arabic and English (dynamic prefixes and vanilla keys excluded)')
if any(missing_fixed.values()):
    for locale, missing in missing_fixed.items():
        for key in missing:
            errors.append(f'Missing fixed {locale} translation: {key}')

# Verify the craftable ritual/altar/codex/sigil definitions and Java source delimiters.
for filename, expected_id in (('mythic_altar.json','evolution:mythic_altar'), ('fusion_altar.json','evolution:fusion_altar'), ('fusion_codex.json','evolution:fusion_codex'), ('trial_sigil.json','evolution:trial_sigil')):
    recipe = read_json(RES / f'data/evolution/recipe/{filename}')
    check(bool(recipe) and recipe.get('type') == 'minecraft:crafting_shaped' and recipe.get('result', {}).get('id') == expected_id, f'{filename} crafts {expected_id}')
for path in sorted(JAVA.glob('*.java')):
    source = path.read_text(encoding='utf-8')
    check(source.count('{') == source.count('}'), f'{path.name} has balanced curly braces')
    check('TODO: implement' not in source, f'{path.name} has no bare TODO implementation placeholder')
check(fusion.count('public static boolean hasTripleSynergy') == 1, 'FusionData has exactly one hasTripleSynergy definition')
check(not any(old in '\n'.join(json.dumps(lang, ensure_ascii=False) for lang in langs.values() if lang) for old in ('tier.evolution.weak','tooltip.evolution.fusion.base_tier','tooltip.evolution.fusion.rank')), 'old automatic grade/rank translation keys are removed')

if errors:
    print('STATIC CHECKS FAILED')
    for message in errors:
        print('FAIL:', message)
    print(f'\n{len(errors)} failure(s); {len(checks)} passed.')
    sys.exit(1)
print('STATIC CHECKS PASSED (not a Java/Gradle compilation or Minecraft runtime test)')
for message in checks:
    print('OK:', message)
print(f'\n{len(checks)} static checks passed. This is not a substitute for Gradle build and in-game testing.')
