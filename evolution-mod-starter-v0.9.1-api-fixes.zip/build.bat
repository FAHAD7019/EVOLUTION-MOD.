@echo off
setlocal
if exist gradlew.bat (
  call gradlew.bat build
  if errorlevel 1 exit /b 1
  echo Build finished. Check build\libs\ for the remapped mod JAR.
  exit /b 0
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle Wrapper is not included yet and Gradle is not installed on PATH.
  echo Gradle is not installed and this archive does not include the Gradle Wrapper JAR.
  echo Install Gradle 9.2.1 with JDK 21 or run the GitHub Actions workflow in an online repository.
  exit /b 1
)
gradle build
if errorlevel 1 exit /b 1
echo Build finished. Check build\libs\ for the remapped mod JAR.
