package dev.evolution.mod;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Very rare structure loot that opens the secret rift trial. The key is reusable. */
public final class RiftKeyItem extends Item {
    public RiftKeyItem(Properties properties) { super(properties.stacksTo(1)); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer serverPlayer) TrialSystem.startSecretRift(serverPlayer);
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> consumer, TooltipFlag flag) {
        consumer.accept(Component.translatable("tooltip.evolution.rift_key").withStyle(ChatFormatting.LIGHT_PURPLE));
        consumer.accept(Component.translatable("tooltip.evolution.rift_key.reusable").withStyle(ChatFormatting.GRAY));
    }
}
