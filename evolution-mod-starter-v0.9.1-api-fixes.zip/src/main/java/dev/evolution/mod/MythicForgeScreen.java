package dev.evolution.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** A 26-slot ritual interface for forging the ultimate all-powers essence. */
public final class MythicForgeScreen extends AbstractContainerScreen<MythicForgeMenu> {
    public MythicForgeScreen(MythicForgeMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 230;
        imageHeight = 252;
        inventoryLabelY = 137;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.translatable("button.evolution.mythic.forge"), button -> {
            if (minecraft != null && minecraft.gameMode != null)
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, MythicForgeMenu.BUTTON_FORGE);
        }).bounds(leftPos + 55, topPos + 98, 120, 20).build());
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        graphics.fill(x, y, x + imageWidth, y + imageHeight, 0xF0100B1E);
        graphics.fill(x, y, x + imageWidth, y + 2, 0xFFFFD36B);
        graphics.fill(x, y + imageHeight - 2, x + imageWidth, y + imageHeight, 0xFF8B5CF6);
        graphics.fill(x, y, x + 2, y + imageHeight, 0xFFFFD36B);
        graphics.fill(x + imageWidth - 2, y, x + imageWidth, y + imageHeight, 0xFF8B5CF6);
        graphics.fill(x + 8, y + 14, x + imageWidth - 8, y + 94, 0xAA21152F);
        for (int i = 0; i < EssenceItem.Power.values().length; i++) {
            int sx = x + 52 + (i % 7) * 18, sy = y + 20 + (i / 7) * 18;
            graphics.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF090610);
            graphics.fill(sx, sy, sx + 16, sy + 16, 0xFF55436F);
        }
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++) drawSlot(graphics, x + 34 + col * 18, y + 149 + row * 18);
        for (int col = 0; col < 9; col++) drawSlot(graphics, x + 34 + col * 18, y + 221);
    }

    private static void drawSlot(GuiGraphics graphics, int x, int y) {
        graphics.fill(x - 1, y - 1, x + 17, y + 17, 0xFF0C0C12);
        graphics.fill(x, y, x + 16, y + 16, 0xFF574D6A);
        graphics.fill(x + 1, y + 1, x + 15, y + 15, 0xFF282536);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        String heading = title.getString();
        graphics.drawString(font, heading, (imageWidth - font.width(heading)) / 2, 5, 0xFFFFD36B, false);
        String status = menu.status().getString();
        graphics.drawString(font, status, (imageWidth - font.width(status)) / 2, 121, 0xFFD8B4FE, false);
        graphics.drawString(font, Component.translatable("container.inventory"), 10, inventoryLabelY, 0xFFE9DDFB, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
