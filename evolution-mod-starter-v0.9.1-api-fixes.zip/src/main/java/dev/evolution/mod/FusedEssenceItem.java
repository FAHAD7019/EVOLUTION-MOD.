package dev.evolution.mod;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Infinitely reusable two/three-power stone. Ten separate upgrade branches are purchased with per-stone kill points. */
public final class FusedEssenceItem extends Item {
    public FusedEssenceItem(Properties properties) { super(properties.stacksTo(1).rarity(net.minecraft.world.item.Rarity.RARE)); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(level instanceof ServerLevel world) || !(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        List<EssenceItem.Power> powers = FusionData.readPowers(held);
        if (powers.size() < 2 || powers.size() > 3) {
            serverPlayer.displayClientMessage(Component.translatable("message.evolution.fusion.invalid"), true);
            return InteractionResult.FAIL;
        }
        int effectivePower = FusionData.effectTier(held);
        int range = FusionData.rangeLevel(held);
        int targets = FusionData.targetLevel(held);
        int style = FusionData.style(held);
        int duration = FusionData.durationLevel(held);
        int control = FusionData.controlLevel(held);
        int critical = FusionData.criticalLevel(held);
        int elemental = FusionData.elementalLevel(held);
        int mobility = FusionData.mobilityLevel(held);
        int activatedCount = 0;
        for (EssenceItem.Power power : powers) {
            if (EssenceItem.activatePower(world, serverPlayer, power, effectivePower, range, targets, style,
                    duration, control, critical, elemental, mobility)) {
                activatedCount++;
                EssenceItem.spawnActivationVisual(world, serverPlayer, power);
            }
        }
        if (activatedCount == 0) {
            serverPlayer.displayClientMessage(Component.translatable("message.evolution.power.no_targets"), true);
            return InteractionResult.FAIL;
        }

        applyDefensiveBranch(serverPlayer, held);
        applyEquipmentResonance(serverPlayer, held);
        if (powers.size() == 2) {
            String binarySynergy = FusionData.binarySynergyKey(powers);
            if (!binarySynergy.isBlank()) applyBinaryBonus(world, serverPlayer, binarySynergy, elemental, duration);
        }
        if (FusionData.hasTripleSynergy(powers)) applyTripleBonus(world, serverPlayer, powers, effectivePower, elemental);
        FusionData.recordSuccessfulUse(held); // A stat only; this does not auto-upgrade the stone.
        world.playSound(null, serverPlayer.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.7F, 1.15F);
        serverPlayer.displayClientMessage(Component.translatable("message.evolution.fusion.activated", activatedCount), true);
        serverPlayer.displayClientMessage(Component.translatable("message.evolution.skill.current_points", FusionData.points(held), FusionData.kills(held)), true);
        return InteractionResult.SUCCESS; // The fused stone never depletes and has no cooldown.
    }

    private static void applyDefensiveBranch(ServerPlayer player, ItemStack held) {
        int level = FusionData.defenseLevel(held);
        if (level <= 0) return;
        int duration = 100 + (int) Math.min(2400L, (long) level * 30L);
        player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, Math.min(3, level / 4)));
        if (level >= 3) player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, Math.min(4, level / 3)));
        if (level >= 10) player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, Math.min(duration, 200), Math.min(2, level / 10)));
    }

    /** Equipment resonance rewards loadouts without replacing vanilla enchantment or durability data. */
    private static void applyEquipmentResonance(ServerPlayer player, ItemStack held) {
        int level = FusionData.equipmentLevel(held);
        if (level <= 0) return;
        int armorPieces = 0;
        for (EquipmentSlot slot : List.of(EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET)) {
            if (!player.getItemBySlot(slot).isEmpty()) armorPieces++;
        }
        int resonanceDuration = 80 + (int) Math.min(24000L, (long) level * 10L);
        if (armorPieces > 0) player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, resonanceDuration, Math.min(2, (armorPieces + level) / 5)));
        if (!player.getOffhandItem().isEmpty()) player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, resonanceDuration, Math.min(2, level / 5)));
        if (level >= 3 && armorPieces >= 4) player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 120, Math.min(3, level / 4)));
    }

    private static void applyBinaryBonus(ServerLevel world, ServerPlayer player, String synergy, int elementalLevel, int durationUpgrade) {
        int duration = 200 + (int) Math.min(24000L, (long) durationUpgrade * 50L) + (int) Math.min(6000L, (long) elementalLevel * 30L);
        switch (synergy) {
            case "thermal_shock" -> {
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
                player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration / 2, Math.min(2, elementalLevel / 5)));
                world.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 1.0D, player.getZ(), 36, 1.8D, 1.1D, 1.8D, 0.04D);
            }
            case "plasma_burst" -> {
                player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, duration, Math.min(3, 1 + elementalLevel / 8)));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
                world.sendParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 1.0D, player.getZ(), 32, 1.4D, 0.8D, 1.4D, 0.06D);
            }
            case "cryo_storm" -> {
                player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration / 2, Math.min(2, elementalLevel / 6)));
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, duration, 0));
                world.sendParticles(ParticleTypes.SNOWFLAKE, player.getX(), player.getY() + 1.0D, player.getZ(), 44, 1.8D, 1.0D, 1.8D, 0.02D);
            }
            case "soul_hunt" -> {
                EvolutionSystem.activateLifeLeech(player);
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, Math.min(duration, 600), 0));
                player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, duration, Math.min(3, elementalLevel / 8)));
            }
            case "seismic_wall" -> {
                player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, Math.min(3, 1 + elementalLevel / 8)));
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, Math.min(4, 1 + elementalLevel / 5)));
                world.sendParticles(ParticleTypes.POOF, player.getX(), player.getY(), player.getZ(), 28, 1.5D, 0.4D, 1.5D, 0.02D);
            }
            case "glacier_breath" -> {
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, duration, 0));
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, duration, 0));
            }
            case "renewal" -> {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, Math.min(3, 1 + elementalLevel / 7)));
                player.heal(2.0F + Math.min(18, elementalLevel));
            }
            case "windrunner" -> {
                player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, Math.min(4, 1 + elementalLevel / 8)));
                player.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, duration, Math.min(3, elementalLevel / 8)));
            }
            case "night_rider" -> {
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, Math.min(duration, 1200), 0));
                player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
                player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, Math.min(2, elementalLevel / 10)));
            }
            case "deep_seeker" -> {
                player.addEffect(new MobEffectInstance(MobEffects.HASTE, duration, Math.min(3, 1 + elementalLevel / 8)));
                player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, duration, 0));
            }
            default -> { return; }
        }
        player.displayClientMessage(Component.translatable("message.evolution.binary_synergy", Component.translatable("synergy.evolution." + synergy)).withStyle(ChatFormatting.AQUA), false);
        world.sendParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0D, player.getZ(), 18, 0.8D, 0.8D, 0.8D, 0.25D);
    }

    private static void applyTripleBonus(ServerLevel world, ServerPlayer player, List<EssenceItem.Power> powers, int tier, int elementalLevel) {
        int duration = 240 + (int) Math.min(3600L, (long) tier * 45L) + (int) Math.min(24000L, (long) elementalLevel * 60L);
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, tier >= 5 ? 2 : 1));
        if (powers.contains(EssenceItem.Power.THUNDER_STRIKE)
                && (powers.contains(EssenceItem.Power.DASH) || powers.contains(EssenceItem.Power.SHADOW_STEP))) {
            player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, tier >= 2 ? 2 : 1));
            player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, duration, tier >= 3 ? 1 : 0));
        } else if (powers.contains(EssenceItem.Power.HEALING)
                && (powers.contains(EssenceItem.Power.REGENERATION) || powers.contains(EssenceItem.Power.LIFE_LEECH))) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, tier >= 2 ? 2 : 1));
        } else if (powers.contains(EssenceItem.Power.FIRE_WARD) && powers.contains(EssenceItem.Power.FROST_EDGE)) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration * 2, 0));
            player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, tier >= 3 ? 1 : 0));
        }

        String secret = FusionData.secretTripleKey(powers);
        if (!secret.isBlank()) {
            switch (secret) {
                case "storm_phantom" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 160, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, duration, 1));
                }
                case "prism_tempest" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration * 2, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, 1));
                    world.sendParticles(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.0D, player.getZ(), 48, 2.5D, 1.2D, 2.5D, 0.04D);
                }
                case "eternal_cycle" -> {
                    player.heal(8.0F + tier);
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, 3));
                }
                case "fortress" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, 4));
                    player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 0));
                }
                case "night_reaper" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, duration, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, 1));
                }
                case "glacier_diver" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, duration, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, duration, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration / 2, 0));
                }
                case "relic_hunter" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.HASTE, duration, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
                    player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, 1));
                }
                case "overdrive" -> {
                    player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, duration, 3));
                    player.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, 1));
                }
                default -> { }
            }
            player.displayClientMessage(Component.translatable("message.evolution.secret_triple", Component.translatable("secret.evolution." + secret)).withStyle(ChatFormatting.LIGHT_PURPLE), false);
        } else {
            player.displayClientMessage(Component.translatable("message.evolution.fusion.triple_bonus"), true);
        }
        world.sendParticles(ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.0D, player.getZ(), 24, 1.0D, 0.8D, 1.0D, 0.65D);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> consumer, TooltipFlag flag) {
        consumer.accept(Component.translatable("tooltip.evolution.fused_essence").withStyle(ChatFormatting.LIGHT_PURPLE));
        List<EssenceItem.Power> powers = FusionData.readPowers(stack);
        if (powers.isEmpty()) {
            consumer.accept(Component.translatable("tooltip.evolution.fused_essence_invalid").withStyle(ChatFormatting.RED));
            return;
        }
        consumer.accept(Component.translatable("tooltip.evolution.skill.points", FusionData.points(stack)).withStyle(ChatFormatting.GOLD));
        consumer.accept(Component.translatable("tooltip.evolution.skill.kills", FusionData.kills(stack), FusionData.bossKills(stack)).withStyle(ChatFormatting.AQUA));
        consumer.accept(Component.translatable("tooltip.evolution.skill.skeleton_kills", FusionData.skeletonKills(stack)).withStyle(ChatFormatting.GRAY));
        consumer.accept(Component.translatable("tooltip.evolution.skill.enderman_kills", FusionData.endermanKills(stack)).withStyle(ChatFormatting.GRAY));
        consumer.accept(Component.translatable("tooltip.evolution.skill.spider_kills", FusionData.spiderKills(stack)).withStyle(ChatFormatting.GRAY));
        consumer.accept(Component.translatable("tooltip.evolution.skill.creeper_kills", FusionData.creeperKills(stack)).withStyle(ChatFormatting.GRAY));
        consumer.accept(Component.translatable("tooltip.evolution.skill.damage", FusionData.upgradeLevel(stack, FusionData.Upgrade.DAMAGE)).withStyle(ChatFormatting.RED));
        consumer.accept(Component.translatable("tooltip.evolution.skill.range", FusionData.rangeLevel(stack)).withStyle(ChatFormatting.BLUE));
        consumer.accept(Component.translatable("tooltip.evolution.skill.targets", FusionData.targetLevel(stack)).withStyle(ChatFormatting.GREEN));
        consumer.accept(Component.translatable("tooltip.evolution.skill.defense", FusionData.defenseLevel(stack)).withStyle(ChatFormatting.AQUA));
        consumer.accept(Component.translatable("tooltip.evolution.skill.equipment", FusionData.equipmentLevel(stack)).withStyle(ChatFormatting.GOLD));
        consumer.accept(Component.translatable("tooltip.evolution.skill.duration", FusionData.durationLevel(stack)).withStyle(ChatFormatting.AQUA));
        consumer.accept(Component.translatable("tooltip.evolution.skill.control", FusionData.controlLevel(stack)).withStyle(ChatFormatting.BLUE));
        consumer.accept(Component.translatable("tooltip.evolution.skill.critical", FusionData.criticalLevel(stack)).withStyle(ChatFormatting.RED));
        consumer.accept(Component.translatable("tooltip.evolution.skill.elemental", FusionData.elementalLevel(stack)).withStyle(ChatFormatting.LIGHT_PURPLE));
        consumer.accept(Component.translatable("tooltip.evolution.skill.mobility", FusionData.mobilityLevel(stack)).withStyle(ChatFormatting.GREEN));
        consumer.accept(Component.translatable("tooltip.evolution.skill.style", Component.translatable("style.evolution." + FusionData.style(stack))).withStyle(ChatFormatting.LIGHT_PURPLE));
        consumer.accept(Component.translatable("tooltip.evolution.fusion.uses", FusionData.useCount(stack)).withStyle(ChatFormatting.GRAY));
        for (EssenceItem.Power power : powers) {
            String id = power.name().toLowerCase(Locale.ROOT) + "_essence";
            consumer.accept(Component.literal("• ").append(Component.translatable("item.evolution." + id)).withStyle(ChatFormatting.AQUA));
        }
        String secret = FusionData.secretTripleKey(powers);
        if (!secret.isBlank()) consumer.accept(Component.translatable("secret.evolution." + secret).withStyle(ChatFormatting.LIGHT_PURPLE));
        else if (FusionData.hasTripleSynergy(powers)) consumer.accept(Component.translatable("tooltip.evolution.fusion.triple_bonus").withStyle(ChatFormatting.GOLD));
        consumer.accept(Component.translatable("tooltip.evolution.fused_essence_hint").withStyle(ChatFormatting.GRAY));
    }


}
