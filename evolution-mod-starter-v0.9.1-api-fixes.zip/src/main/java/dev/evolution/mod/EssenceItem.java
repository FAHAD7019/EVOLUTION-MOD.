package dev.evolution.mod;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/** A server-authoritative reusable base power. */
public final class EssenceItem extends Item {
    private final Power power;

    public EssenceItem(Properties properties, Power power) {
        super(properties);
        this.power = power;
    }

    @Override
    public net.minecraft.world.InteractionResult use(Level level, net.minecraft.world.entity.player.Player player, net.minecraft.world.InteractionHand hand) {
        // Report the use to the client prediction layer so the server receives the use packet.
        if (level.isClientSide()) return net.minecraft.world.InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer) || !(level instanceof ServerLevel world))
            return net.minecraft.world.InteractionResult.PASS;

        if (power == Power.HEALING && player.getHealth() >= player.getMaxHealth()) {
            serverPlayer.displayClientMessage(Component.translatable("message.evolution.power.healing_full"), true);
            return net.minecraft.world.InteractionResult.FAIL;
        }

        boolean activated = activate(world, serverPlayer);
        if (!activated) {
            if (power != Power.GRAND_ASCENSION) {
                serverPlayer.displayClientMessage(Component.translatable("message.evolution.power.no_targets"), true);
            }
            return net.minecraft.world.InteractionResult.FAIL;
        }
        // Essences are reusable catalysts: activation never consumes the item.
        spawnActivationVisual(world, player, power);
        if (power != Power.GRAND_ASCENSION && power != Power.LIFE_LEECH) {
            serverPlayer.displayClientMessage(Component.translatable("message.evolution.power." + power.name().toLowerCase(Locale.ROOT)), true);
        }
        return net.minecraft.world.InteractionResult.SUCCESS;
    }

    private boolean activate(ServerLevel world, ServerPlayer player) {
        return activatePower(world, player, power);
    }

    /** Applies one ordinary essence at its base level. */
    public static boolean activatePower(ServerLevel world, ServerPlayer player, Power power) {
        return activatePower(world, player, power, 0);
    }

    /** Fused essences scale their effects using per-stone upgrades, with bounded inputs. */
    public static boolean activatePower(ServerLevel world, ServerPlayer player, Power power, int powerTier) {
        return activatePower(world, player, power, powerTier, 0, 0, 0);
    }

    /** Compatibility overload for powers without a manually upgraded branch. */
    public static boolean activatePower(ServerLevel world, ServerPlayer player, Power power, int powerTier,
                                        int rangeUpgrade, int targetUpgrade, int style) {
        return activatePower(world, player, power, powerTier, rangeUpgrade, targetUpgrade, style, 0, 0, 0, 0, 0);
    }

    /** Ten upgrade branches change power, duration, targeting, control, critical hits and movement. */
    public static boolean activatePower(ServerLevel world, ServerPlayer player, Power power, int powerTier,
                                        int rangeUpgrade, int targetUpgrade, int style, int durationUpgrade,
                                        int controlUpgrade, int criticalUpgrade, int elementalUpgrade, int mobilityUpgrade) {
        int tier = Math.max(0, Math.min(1000, powerTier));
        int safeRange = Math.max(0, Math.min(1000, rangeUpgrade));
        int safeTargets = Math.max(0, Math.min(1000, targetUpgrade));
        int safeStyle = Math.max(0, Math.min(2, style));
        int safeDuration = Math.max(0, Math.min(100000, durationUpgrade));
        int safeControl = Math.max(0, Math.min(1000, controlUpgrade));
        int safeCritical = Math.max(0, Math.min(1000, criticalUpgrade));
        int safeElemental = Math.max(0, Math.min(1000, elementalUpgrade));
        int safeMobility = Math.max(0, Math.min(1000, mobilityUpgrade));
        switch (power) {
            case SPEED -> player.addEffect(scaledEffect(MobEffects.SPEED, 320, 1, tier, safeDuration));
            case STRENGTH -> player.addEffect(scaledEffect(MobEffects.STRENGTH, 240, 0, tier, safeDuration));
            case HEALING -> {
                if (player.getHealth() >= player.getMaxHealth()) return false;
                player.heal(8.0F + tier * 2.0F);
            }
            case SHADOW -> player.addEffect(scaledEffect(MobEffects.INVISIBILITY, 160, 0, tier, safeDuration));
            case LEAP -> { player.addEffect(scaledEffect(MobEffects.JUMP_BOOST, 280, 1, tier, safeDuration)); player.addEffect(scaledEffect(MobEffects.SPEED, 160, 0, tier, safeDuration)); }
            case STONE_SKIN -> player.addEffect(scaledEffect(MobEffects.RESISTANCE, 240, 0, tier, safeDuration));
            case FIRE_WARD -> player.addEffect(scaledEffect(MobEffects.FIRE_RESISTANCE, 900, 0, tier, safeDuration));
            case DEEP_BREATH -> player.addEffect(scaledEffect(MobEffects.WATER_BREATHING, 1200, 0, tier, safeDuration));
            case NIGHT_SIGHT -> player.addEffect(scaledEffect(MobEffects.NIGHT_VISION, 1200, 0, tier, safeDuration));
            case MINER -> player.addEffect(scaledEffect(MobEffects.HASTE, 360, 1, tier, safeDuration));
            case REGENERATION -> player.addEffect(scaledEffect(MobEffects.REGENERATION, 200, 1, tier, safeDuration));
            case ABSORPTION -> player.addEffect(scaledEffect(MobEffects.ABSORPTION, 600, 1, tier, safeDuration));
            case FEATHERFALL -> player.addEffect(scaledEffect(MobEffects.SLOW_FALLING, 500, 0, tier, safeDuration));
            case DASH -> burstForward(player, 1.65D + 0.16D * Math.min(18, tier) + mobilityBonus(safeMobility), 0.28D + 0.025D * Math.min(18, tier) + mobilityBonus(safeMobility) * 0.25D);
            case THUNDER_STRIKE -> {
                double radius = boundedRadius(5.5D, tier, safeRange);
                float damage = (6.0F + tier * 1.5F + safeElemental * 0.28F);
                int targets = targetLimit(3, safeTargets);
                if (safeStyle == 1) { radius *= 0.72D; damage *= 1.65F; targets = 1; }
                else if (safeStyle == 2) { radius = Math.min(64.0D, radius + 2.0D); damage *= 0.78F; targets = Math.min(64, targets + 5); }
                if (safeCritical > 0 && world.getRandom().nextFloat() < Math.min(0.65F, safeCritical * 0.025F)) {
                    damage *= 2.0F;
                    player.displayClientMessage(Component.translatable("message.evolution.skill.critical_hit"), true);
                }
                if (!hitNearbyHostiles(world, player, radius, damage, targets, safeControl)) return false;
            }
            case REPULSE -> { if (!repulse(world, player, tier, safeRange, safeControl, safeStyle)) return false; }
            case FROST_EDGE -> { if (!slowNearbyHostiles(world, player, tier, safeRange, safeTargets, safeDuration, safeControl, safeStyle)) return false; }
            case LIFE_LEECH -> { EvolutionSystem.activateLifeLeech(player); player.addEffect(scaledEffect(MobEffects.STRENGTH, 160, 0, tier, safeDuration)); player.displayClientMessage(Component.translatable("message.evolution.power.life_leech_hint"), true); }
            case HUNTER -> { if (!highlightHostiles(world, player, boundedRadius(24.0D, tier, safeRange), highlightDuration(240, tier, safeDuration))) return false; }
            case DANGER_SENSE -> { if (!highlightHostiles(world, player, boundedRadius(18.0D, tier, safeRange), highlightDuration(160, tier, safeDuration))) return false; if (player.getHealth() <= 8.0F) player.addEffect(scaledEffect(MobEffects.RESISTANCE, 100, 0, tier, safeDuration)); }
            case SHADOW_STEP -> { burstForward(player, 1.95D + 0.18D * Math.min(12, tier) + mobilityBonus(safeMobility), 0.12D + 0.02D * Math.min(12, tier) + mobilityBonus(safeMobility) * 0.18D); player.addEffect(scaledEffect(MobEffects.INVISIBILITY, 80, 0, tier, safeDuration)); }
            case ENERGY_SHIELD -> { player.addEffect(scaledEffect(MobEffects.ABSORPTION, 600, 2, tier, safeDuration)); player.addEffect(scaledEffect(MobEffects.RESISTANCE, 160, 0, tier, safeDuration)); }
            case PROSPECTOR -> { player.addEffect(scaledEffect(MobEffects.HASTE, 500, 0, tier, safeDuration)); player.addEffect(scaledEffect(MobEffects.NIGHT_VISION, 500, 0, tier, safeDuration)); }
            case VENOM_GUARD -> { player.removeEffect(MobEffects.POISON); player.addEffect(scaledEffect(MobEffects.RESISTANCE, 180, 0, tier, safeDuration)); player.addEffect(scaledEffect(MobEffects.REGENERATION, 100, 0, tier, safeDuration)); }
            case EVOLUTION_SURGE -> { player.addEffect(scaledEffect(MobEffects.SPEED, 240, 1, tier, safeDuration)); player.addEffect(scaledEffect(MobEffects.STRENGTH, 240, 1, tier, safeDuration)); player.addEffect(scaledEffect(MobEffects.RESISTANCE, 240, 0, tier, safeDuration)); }
            case GRAND_ASCENSION -> { return grandAscension(world, player); }
        }
        return true;
    }

    /** Diminishing range returns keep unlimited upgrade counters from creating world-sized scans. */
    private static double boundedRadius(double base, int tier, int rangeUpgrade) {
        double tierBonus = Math.min(12.0D, Math.sqrt(Math.max(0, tier)) * 1.75D);
        double rangeBonus = Math.min(28.0D, Math.sqrt(Math.max(0, rangeUpgrade)) * 1.1D);
        return Math.max(1.0D, Math.min(64.0D, base + tierBonus + rangeBonus));
    }

    /** Target-count upgrades grow with diminishing returns and never scan thousands of mobs per use. */
    private static int targetLimit(int base, int targetUpgrade) {
        int bonus = (int) Math.floor(Math.sqrt(Math.max(0, targetUpgrade)) * 2.0D);
        return Math.max(1, Math.min(64, base + bonus));
    }

    private static int highlightDuration(int base, int tier, int durationUpgrade) {
        long proposed = (long) base + (long) Math.min(1000, Math.max(0, tier)) * 30L
                + (long) Math.min(100000, Math.max(0, durationUpgrade)) * 20L;
        return (int) Math.max(1L, Math.min(24000L, proposed));
    }

    private static double mobilityBonus(int mobilityUpgrade) {
        return Math.min(4.0D, Math.sqrt(Math.max(0, mobilityUpgrade)) * 0.15D);
    }

    private static MobEffectInstance scaledEffect(Holder<net.minecraft.world.effect.MobEffect> effect, int ticks, int amplifier, int tier) {
        return scaledEffect(effect, ticks, amplifier, tier, 0);
    }

    private static MobEffectInstance scaledEffect(Holder<net.minecraft.world.effect.MobEffect> effect, int ticks, int amplifier, int tier, int durationUpgrade) {
        int safeTier = Math.max(0, Math.min(1000, tier));
        int safeDuration = Math.max(0, Math.min(100000, durationUpgrade));
        double scaledTicks = ticks * (1.0D + 0.10D * safeTier) * (1.0D + 0.03D * safeDuration);
        int duration = (int) Math.max(1L, Math.min(Integer.MAX_VALUE, Math.round(scaledTicks)));
        int scaledAmplifier = amplifier + Math.min(4, safeTier / 5);
        return new MobEffectInstance(effect, duration, scaledAmplifier);
    }

    private static MobEffectInstance effect(net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect, int ticks, int amplifier) {
        return new MobEffectInstance(effect, ticks, amplifier);
    }

    private static void burstForward(ServerPlayer player, double forward, double lift) {
        var look = player.getLookAngle();
        double safeForward = Math.max(0.0D, Math.min(4.0D, forward));
        double safeLift = Math.max(0.0D, Math.min(1.5D, lift));
        player.push(look.x * safeForward, safeLift, look.z * safeForward);
    }

    private static boolean hitNearbyHostiles(ServerLevel world, ServerPlayer player, double radius, float damage, int maxTargets, int controlUpgrade) {
        int hitCount = 0;
        AABB area = player.getBoundingBox().inflate(radius);
        List<LivingEntity> targets = world.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive() && isHostileTarget(e) && player.distanceToSqr(e) <= radius * radius);
        targets.sort(java.util.Comparator.comparingDouble(player::distanceToSqr));
        for (LivingEntity target : targets) {
            if (hitCount >= Math.max(1, maxTargets)) break;
            // Preserve magic damage semantics while attributing the hit to the player. This lets
            // AFTER_DEATH award progression to the fused essence that was held during the kill.
            var playerMagicDamage = new net.minecraft.world.damagesource.DamageSource(
                    world.damageSources().magic().typeHolder(), player, player);
            target.hurtServer(world, playerMagicDamage, damage);
            if (controlUpgrade > 0 && world.getRandom().nextFloat() < Math.min(0.8F, controlUpgrade * 0.04F)) {
                target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40 + Math.min(1200, controlUpgrade * 20), Math.min(2, controlUpgrade / 10)));
            }
            world.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + target.getBbHeight() * 0.55D, target.getZ(), 10, 0.3D, 0.35D, 0.3D, 0.03D);
            hitCount++;
        }
        return hitCount > 0;
    }

    private static boolean isHostileTarget(LivingEntity entity) {
        return entity instanceof Enemy || entity.getType() == net.minecraft.world.entity.EntityType.ENDER_DRAGON
                || entity.getType() == net.minecraft.world.entity.EntityType.WITHER
                || entity.getType() == net.minecraft.world.entity.EntityType.WARDEN;
    }

    private static boolean repulse(ServerLevel world, ServerPlayer player, int tier, int rangeUpgrade, int controlUpgrade, int style) {
        int targetCount = 0;
        double radius = Math.max(1.0D, Math.min(64.0D, boundedRadius(5.0D, tier, rangeUpgrade)
                + (style == 2 ? 2.0D : 0.0D) - (style == 1 ? 1.5D : 0.0D)));
        for (LivingEntity target : world.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius), e -> e != player && e.isAlive() && isHostileTarget(e) && player.distanceToSqr(e) <= radius * radius)) {
            if (targetCount >= 64) break;
            double dx = target.getX() - player.getX();
            double dz = target.getZ() - player.getZ();
            double length = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
            double control = Math.min(2.0D, controlUpgrade * 0.02D);
            // Keep even extremely developed stones from launching mobs with world-breaking velocity.
            double horizontalPush = Math.min(5.0D, 1.45D + Math.min(18, tier) * 0.12D + control);
            double verticalPush = Math.min(2.5D, 0.48D + Math.min(18, tier) * 0.035D + control * 0.35D);
            target.push(dx / length * horizontalPush, verticalPush, dz / length * horizontalPush);
            world.sendParticles(ParticleTypes.POOF, target.getX(), target.getY() + 0.5D, target.getZ(), 5, 0.25D, 0.25D, 0.25D, 0.02D);
            targetCount++;
        }
        return targetCount > 0;
    }

    private static boolean slowNearbyHostiles(ServerLevel world, ServerPlayer player, int tier, int rangeUpgrade, int targetUpgrade, int durationUpgrade, int controlUpgrade, int style) {
        int targetCount = 0;
        double radius = Math.max(1.0D, Math.min(64.0D, boundedRadius(6.0D, tier, rangeUpgrade)
                + (style == 2 ? 2.0D : 0.0D) - (style == 1 ? 1.5D : 0.0D)));
        int maxTargets = style == 1 ? 1 : targetLimit(6, targetUpgrade);
        int slowDuration = 120 + Math.min(24000, durationUpgrade * 20) + Math.min(6000, controlUpgrade * 12);
        int slowAmplifier = Math.min(4, 1 + controlUpgrade / 8);
        for (LivingEntity target : world.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius), e -> e != player && e.isAlive() && isHostileTarget(e) && player.distanceToSqr(e) <= radius * radius)) {
            if (targetCount >= maxTargets) break;
            target.addEffect(scaledEffect(MobEffects.SLOWNESS, slowDuration, slowAmplifier, tier, durationUpgrade));
            world.sendParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getY() + 0.8D, target.getZ(), 8, 0.3D, 0.4D, 0.3D, 0.01D);
            targetCount++;
        }
        return targetCount > 0;
    }

    private static boolean highlightHostiles(ServerLevel world, ServerPlayer player, double radius, int ticks) {
        int targetCount = 0;
        radius = Math.max(1.0D, Math.min(64.0D, radius));
        ticks = Math.max(1, Math.min(24000, ticks));
        for (LivingEntity target : world.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius), e -> e != player && e.isAlive() && isHostileTarget(e) && player.distanceToSqr(e) <= radius * radius)) {
            if (targetCount >= 128) break;
            target.addEffect(effect(MobEffects.GLOWING, ticks, 0));
            targetCount++;
        }
        return targetCount > 0;
    }

    /** Applies maximum legal enchantment levels while respecting the vanilla incompatibility rules. */
    private static boolean grandAscension(ServerLevel world, ServerPlayer player) {
        // Inventory internals became private in current versions. Use the public main-inventory
        // accessor and LivingEntity equipment accessors so this remains mapped-API compatible.
        int changed = enchantList(world, player.getInventory().getNonEquipmentItems());
        for (EquipmentSlot slot : List.of(
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
                EquipmentSlot.FEET, EquipmentSlot.OFFHAND)) {
            ItemStack original = player.getItemBySlot(slot);
            ItemStack upgraded = upgradeStack(world, original);
            if (upgraded != original) {
                player.setItemSlot(slot, upgraded);
                changed++;
            }
        }
        if (changed == 0) {
            player.displayClientMessage(Component.translatable("message.evolution.power.grand_ascension_none"), true);
            return false;
        }
        player.displayClientMessage(Component.translatable("message.evolution.power.grand_ascension_count", changed), true);
        return true;
    }

    private static int enchantList(ServerLevel world, List<ItemStack> stacks) {
        int changed = 0;
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack original = stacks.get(i);
            ItemStack upgraded = upgradeStack(world, original);
            if (upgraded != original) {
                stacks.set(i, upgraded);
                changed++;
            }
        }
        return changed;
    }

    /** Returns the original stack unchanged when there is no legal improvement to apply. */
    private static ItemStack upgradeStack(ServerLevel world, ItemStack original) {
        if (original.isEmpty()) return original;
        boolean alreadyEnchanted = EnchantmentHelper.hasAnyEnchantments(original);
        if (!original.isEnchantable() && !alreadyEnchanted) return original;

        ItemStack upgraded = original.copy();
        var enchantmentRegistry = world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> candidates = enchantmentRegistry.listElements().toList();
        // Copy the current set because each compatible new enchantment is added as we go.
        Set<Holder<Enchantment>> currentEnchantments = new HashSet<>(upgraded.getEnchantments().keySet());
        for (Holder.Reference<Enchantment> candidate : candidates) {
            Enchantment enchantment = candidate.value();
            String enchantmentId = candidate.unwrapKey().map(key -> key.identifier().toString()).orElse("");
            // These curses are harmful and are intentionally excluded from the legendary upgrade.
            if (enchantmentId.equals("minecraft:binding_curse") || enchantmentId.equals("minecraft:vanishing_curse")) continue;
            if (!enchantment.canEnchant(upgraded)) continue;
            int oldLevel = EnchantmentHelper.getItemEnchantmentLevel(candidate, upgraded);
            int maxLevel = enchantment.getMaxLevel();
            if (oldLevel >= maxLevel) continue;

            boolean compatible = true;
            for (Holder<Enchantment> existing : currentEnchantments) {
                if (!existing.equals(candidate) && !Enchantment.areCompatible(existing, candidate)) {
                    compatible = false;
                    break;
                }
            }
            if (!compatible) continue;

            upgraded.enchant(candidate, maxLevel);
            int newLevel = EnchantmentHelper.getItemEnchantmentLevel(candidate, upgraded);
            if (newLevel > oldLevel) currentEnchantments.add(candidate);
        }
        return ItemStack.matches(original, upgraded) ? original : upgraded;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay displayComponent, Consumer<Component> textConsumer, TooltipFlag type) {
        textConsumer.accept(Component.translatable(tooltipKey()).withStyle(ChatFormatting.GRAY));
        if (power == Power.GRAND_ASCENSION) textConsumer.accept(Component.translatable("tooltip.evolution.essence.grand_ascension_warning").withStyle(ChatFormatting.DARK_PURPLE));
    }

    private String tooltipKey() { return "tooltip.evolution.essence." + power.name().toLowerCase(Locale.ROOT); }

    public static void spawnActivationVisual(ServerLevel world, net.minecraft.world.entity.player.Player player, Power power) {
        DustParticleOptions dust = new DustParticleOptions(colorFor(power), 1.0F);
        double x = player.getX(), y = player.getY(), z = player.getZ();
        for (int i = 0; i < 18; i++) {
            double angle = Math.PI * 2.0D * i / 18.0D;
            double radius = 0.35D + (i % 3) * 0.12D;
            world.sendParticles(dust, x + Math.cos(angle) * radius, y + 0.15D + (i % 6) * 0.16D, z + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
        }
        world.sendParticles(power == Power.GRAND_ASCENSION ? ParticleTypes.TOTEM_OF_UNDYING : ParticleTypes.ENCHANT, x, y + 0.8D, z, 12, 0.35D, 0.55D, 0.35D, 0.06D);
    }

    public static int colorFor(Power power) {
        return switch (power) {
            case SPEED -> 0x28DFFF; case STRENGTH -> 0xFF572F; case HEALING -> 0x35E58A; case SHADOW -> 0xA45BEB; case LEAP -> 0xFFD34A;
            case STONE_SKIN -> 0x8C8C8C; case FIRE_WARD -> 0xFF6A24; case DEEP_BREATH -> 0x35D8E6; case NIGHT_SIGHT -> 0x496CFF; case MINER -> 0xD7C64A;
            case REGENERATION -> 0xFF76BB; case ABSORPTION -> 0x9BEA48; case FEATHERFALL -> 0xEAEAFF; case DASH -> 0x30DDB8; case THUNDER_STRIKE -> 0xFFF252;
            case REPULSE -> 0xFF9B4A; case FROST_EDGE -> 0x80E7FF; case LIFE_LEECH -> 0xE52C50; case HUNTER -> 0xFF92B1; case DANGER_SENSE -> 0xE94FFF;
            case SHADOW_STEP -> 0x6623AF; case ENERGY_SHIELD -> 0x5178FF; case PROSPECTOR -> 0xCF8B51; case VENOM_GUARD -> 0x52E5A2; case EVOLUTION_SURGE -> 0xA5F75B; case GRAND_ASCENSION -> 0xF5D777;
        };
    }

    public Power getPower() { return power; }

    public enum Power {
        SPEED, STRENGTH, HEALING, SHADOW, LEAP, STONE_SKIN, FIRE_WARD, DEEP_BREATH, NIGHT_SIGHT, MINER, REGENERATION, ABSORPTION, FEATHERFALL, DASH, THUNDER_STRIKE, REPULSE, FROST_EDGE, LIFE_LEECH, HUNTER, DANGER_SENSE, SHADOW_STEP, ENERGY_SHIELD, PROSPECTOR, VENOM_GUARD, EVOLUTION_SURGE, GRAND_ASCENSION
    }
}
