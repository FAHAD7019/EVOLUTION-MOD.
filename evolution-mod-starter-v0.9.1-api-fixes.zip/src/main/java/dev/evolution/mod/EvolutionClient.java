package dev.evolution.mod;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screens.MenuScreens;

/** Client-only registrations for the mod's container interfaces. */
public final class EvolutionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MenuScreens.register(ModMenus.FUSION_MENU, FusionScreen::new);
        MenuScreens.register(ModMenus.MYTHIC_FORGE_MENU, MythicForgeScreen::new);
    }
}
