package dev.evolution.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import java.util.function.Consumer;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

/** A portable recipe journal. Discovery history is stored on the book item itself. */
public final class FusionCodexItem extends Item {
    private static final String ENTRIES_KEY = "evolution_fusion_codex_entries";
    private static final int MAX_ENTRIES = FusionData.pairCombinationCount() + FusionData.tripleCombinationCount();

    public FusionCodexItem(Properties properties) { super(properties.stacksTo(1)); }

    /** Records a recipe on every codex the player currently carries; duplicates are ignored. */
    public static void recordDiscovery(ServerPlayer player, List<EssenceItem.Power> powers) {
        String signature = encode(powers);
        for (ItemStack candidate : player.getInventory().getNonEquipmentItems()) {
            if (!candidate.is(ModItems.FUSION_CODEX)) continue;
            CompoundTag tag = copyTag(candidate);
            List<String> entries = readEntries(tag);
            if (entries.contains(signature) || entries.size() >= MAX_ENTRIES) continue;
            entries.add(signature);
            tag.putString(ENTRIES_KEY, String.join(";", entries));
            CustomData.set(DataComponents.CUSTOM_DATA, candidate, tag);
        }
        ItemStack offhand = player.getOffhandItem();
        if (offhand.is(ModItems.FUSION_CODEX)) {
            CompoundTag tag = copyTag(offhand);
            List<String> entries = readEntries(tag);
            if (!entries.contains(signature) && entries.size() < MAX_ENTRIES) {
                entries.add(signature);
                tag.putString(ENTRIES_KEY, String.join(";", entries));
                CustomData.set(DataComponents.CUSTOM_DATA, offhand, tag);
            }
        }
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;
        ItemStack book = player.getItemInHand(hand);
        List<String> entries = readEntries(copyTag(book));
        serverPlayer.sendSystemMessage(Component.translatable("message.evolution.codex.title").withStyle(ChatFormatting.GOLD));
        serverPlayer.sendSystemMessage(Component.translatable("message.evolution.codex.count", entries.size(), MAX_ENTRIES));
        if (entries.isEmpty()) {
            serverPlayer.sendSystemMessage(Component.translatable("message.evolution.codex.empty"));
            return InteractionResult.SUCCESS;
        }
        int first = Math.max(0, entries.size() - 8);
        for (int i = first; i < entries.size(); i++) {
            List<EssenceItem.Power> powers = decode(entries.get(i));
            if (powers.isEmpty()) continue;
            StringJoiner names = new StringJoiner(" + ");
            for (EssenceItem.Power power : powers) {
                names.add(Component.translatable("item.evolution." + power.name().toLowerCase(java.util.Locale.ROOT) + "_essence").getString());
            }
            serverPlayer.sendSystemMessage(Component.literal("• " + names));
        }
        if (entries.size() > 8) serverPlayer.sendSystemMessage(Component.translatable("message.evolution.codex.more", entries.size() - 8));
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> consumer, TooltipFlag flag) {
        List<String> entries = readEntries(copyTag(stack));
        consumer.accept(Component.translatable("tooltip.evolution.fusion_codex").withStyle(ChatFormatting.GRAY));
        consumer.accept(Component.translatable("tooltip.evolution.codex.count", entries.size(), MAX_ENTRIES).withStyle(ChatFormatting.AQUA));
    }

    private static String encode(List<EssenceItem.Power> powers) {
        return powers.stream().sorted((a, b) -> Integer.compare(a.ordinal(), b.ordinal()))
            .map(power -> Integer.toString(power.ordinal())).collect(java.util.stream.Collectors.joining("."));
    }

    private static List<EssenceItem.Power> decode(String encoded) {
        List<EssenceItem.Power> result = new ArrayList<>();
        try {
            for (String token : encoded.split("\\.")) {
                int index = Integer.parseInt(token);
                EssenceItem.Power power = EssenceItem.Power.values()[index];
                if (power == EssenceItem.Power.GRAND_ASCENSION || result.contains(power)) return List.of();
                result.add(power);
            }
        } catch (RuntimeException invalid) { return List.of(); }
        return result.size() >= 2 && result.size() <= 3 ? result : List.of();
    }

    private static List<String> readEntries(CompoundTag tag) {
        String raw = tag.getStringOr(ENTRIES_KEY, "");
        if (raw.isBlank()) return new ArrayList<>();
        List<String> entries = new ArrayList<>();
        for (String part : raw.split(";")) {
            if (!part.isBlank() && decode(part).size() >= 2 && !entries.contains(part)) entries.add(part);
        }
        return entries;
    }

    private static CompoundTag copyTag(ItemStack stack) {
        CustomData old = stack.get(DataComponents.CUSTOM_DATA);
        return old == null ? new CompoundTag() : old.copyTag();
    }
}
