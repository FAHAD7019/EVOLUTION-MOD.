package dev.evolution.mod;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipDisplay;
import java.util.function.Consumer;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

/** A portable trial key. Crouch-use cycles difficulty; ordinary use starts the selected trial. */
public final class TrialSigilItem extends Item {
    private static final String DIFFICULTY_KEY = "evolution_trial_difficulty";

    public TrialSigilItem(Properties properties) { super(properties.stacksTo(16)); }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> consumer, TooltipFlag flag) {
        consumer.accept(Component.translatable("tooltip.evolution.trial_sigil"));
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        int index = data == null ? 0 : Math.floorMod(data.copyTag().getIntOr(DIFFICULTY_KEY, 0), TrialSystem.Difficulty.values().length);
        consumer.accept(Component.translatable("item.evolution.trial_sigil.selected", TrialSystem.Difficulty.values()[index].label()));
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;
        ItemStack stack = player.getItemInHand(hand);
        if (player.isCrouching()) {
            CustomData old = stack.get(DataComponents.CUSTOM_DATA);
            CompoundTag tag = old == null ? new CompoundTag() : old.copyTag();
            int current = Math.floorMod(tag.getIntOr(DIFFICULTY_KEY, 0), TrialSystem.Difficulty.values().length);
            int next = (current + 1) % TrialSystem.Difficulty.values().length;
            tag.putInt(DIFFICULTY_KEY, next);
            CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
            TrialSystem.Difficulty difficulty = TrialSystem.Difficulty.values()[next];
            serverPlayer.displayClientMessage(Component.translatable("item.evolution.trial_sigil.selected", difficulty.label()), true);
            return InteractionResult.SUCCESS;
        }
        CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
        int index = customData == null ? 0 : Math.floorMod(customData.copyTag().getIntOr(DIFFICULTY_KEY, 0), TrialSystem.Difficulty.values().length);
        boolean started = TrialSystem.startTrial(serverPlayer, TrialSystem.Difficulty.values()[index]);
        if (started && !player.getAbilities().instabuild) stack.shrink(1);
        return started ? InteractionResult.SUCCESS : InteractionResult.FAIL;
    }
}
