package dev.evolution.mod;

import java.util.EnumSet;
import java.util.Set;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Twenty-six ingredient slots; the ritual only accepts all distinct, unmerged base essences. */
public final class MythicForgeMenu extends AbstractContainerMenu {
    public static final int BUTTON_FORGE = 0;
    private static final int INGREDIENT_SLOTS = EssenceItem.Power.values().length;
    private final SimpleContainer input;

    public MythicForgeMenu(int id, Inventory inventory) { this(id, inventory, new SimpleContainer(INGREDIENT_SLOTS)); }

    public MythicForgeMenu(int id, Inventory inventory, SimpleContainer input) {
        super(ModMenus.MYTHIC_FORGE_MENU, id);
        this.input = input;
        checkContainerSize(input, INGREDIENT_SLOTS);
        input.startOpen(inventory.player);
        for (int slot = 0; slot < INGREDIENT_SLOTS; slot++) {
            addSlot(new Slot(input, slot, 52 + (slot % 7) * 18, 20 + (slot / 7) * 18) {
                @Override public boolean mayPlace(ItemStack stack) { return stack.getItem() instanceof EssenceItem; }
                @Override public int getMaxStackSize(ItemStack stack) { return 1; }
            });
        }
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++)
            addSlot(new Slot(inventory, 9 + row * 9 + col, 34 + col * 18, 149 + row * 18));
        for (int col = 0; col < 9; col++) addSlot(new Slot(inventory, col, 34 + col * 18, 221));
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id != BUTTON_FORGE || !(player instanceof ServerPlayer serverPlayer)) return false;
        Set<EssenceItem.Power> found = EnumSet.noneOf(EssenceItem.Power.class);
        int occupied = 0;
        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            occupied++;
            if (!(stack.getItem() instanceof EssenceItem essence) || !found.add(essence.getPower())) {
                serverPlayer.displayClientMessage(Component.translatable("message.evolution.mythic.invalid"), false);
                return false;
            }
        }
        if (occupied != INGREDIENT_SLOTS || found.size() != EssenceItem.Power.values().length) {
            serverPlayer.displayClientMessage(Component.translatable("message.evolution.mythic.missing", found.size(), INGREDIENT_SLOTS), false);
            return false;
        }
        for (int i = 0; i < input.getContainerSize(); i++) input.removeItem(i, 1);
        input.setChanged();
        serverPlayer.getInventory().placeItemBackInInventory(new ItemStack(ModItems.MYTHIC_ESSENCE));
        serverPlayer.displayClientMessage(Component.translatable("message.evolution.mythic.forged"), false);
        broadcastChanges();
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        if (index < 0 || index >= slots.size()) return ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack source = slot.getItem();
        ItemStack original = source.copy();
        if (index < INGREDIENT_SLOTS) {
            if (!moveItemStackTo(source, INGREDIENT_SLOTS, slots.size(), true)) return ItemStack.EMPTY;
        } else {
            if (!(source.getItem() instanceof EssenceItem) || !moveItemStackTo(source, 0, INGREDIENT_SLOTS, false)) return ItemStack.EMPTY;
        }
        if (source.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        if (source.getCount() == original.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, source);
        return original;
    }

    public Component status() {
        Set<EssenceItem.Power> found = EnumSet.noneOf(EssenceItem.Power.class);
        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.getItem() instanceof EssenceItem essence) found.add(essence.getPower());
        }
        return Component.translatable("label.evolution.mythic.progress", found.size(), INGREDIENT_SLOTS);
    }

    @Override public boolean stillValid(Player player) { return player.isAlive() && !player.isRemoved(); }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (player instanceof ServerPlayer serverPlayer) {
            for (int i = 0; i < input.getContainerSize(); i++) {
                ItemStack stack = input.removeItemNoUpdate(i);
                if (!stack.isEmpty()) serverPlayer.getInventory().placeItemBackInInventory(stack);
            }
        }
        input.stopOpen(player);
    }
}
