package dev.evolution.mod;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** The reusable endgame essence forged from all 26 separate base powers. */
public final class MythicEssenceItem extends Item {
    public MythicEssenceItem(Properties properties) { super(properties.stacksTo(1).rarity(net.minecraft.world.item.Rarity.EPIC)); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(level instanceof ServerLevel world) || !(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;
        int applied = 0;
        for (EssenceItem.Power power : EssenceItem.Power.values()) {
            if (EssenceItem.activatePower(world, serverPlayer, power, 40, 40, 40, 2)) applied++;
            EssenceItem.spawnActivationVisual(world, serverPlayer, power);
        }
        int duration = 20 * 60 * 10;
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.STRENGTH, duration, 4));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, duration, 3));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.SPEED, duration, 3));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 2));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, 4));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, duration, 0));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.HASTE, duration, 3));
        serverPlayer.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, duration, 0));
        serverPlayer.addTag("evolution_is_legend");
        world.sendParticles(ParticleTypes.END_ROD, serverPlayer.getX(), serverPlayer.getY() + 1.0D, serverPlayer.getZ(), 100, 2.2D, 1.5D, 2.2D, 0.06D);
        world.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, serverPlayer.getX(), serverPlayer.getY() + 1.0D, serverPlayer.getZ(), 50, 1.3D, 1.2D, 1.3D, 0.1D);
        world.playSound(null, serverPlayer.blockPosition(), SoundEvents.TOTEM_OF_UNDYING, SoundSource.PLAYERS, 1.6F, 0.7F);
        serverPlayer.displayClientMessage(Component.translatable("message.evolution.mythic.legend"), false);
        serverPlayer.displayClientMessage(Component.translatable("message.evolution.mythic.powers", applied), false);
        return InteractionResult.SUCCESS; // Infinite uses; activating the relic never consumes it.
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> consumer, TooltipFlag flag) {
        consumer.accept(Component.translatable("tooltip.evolution.mythic_essence").withStyle(ChatFormatting.LIGHT_PURPLE));
        consumer.accept(Component.translatable("tooltip.evolution.mythic_essence.power_count", EssenceItem.Power.values().length).withStyle(ChatFormatting.GOLD));
        consumer.accept(Component.translatable("tooltip.evolution.mythic_essence.reusable").withStyle(ChatFormatting.AQUA));
    }
}
