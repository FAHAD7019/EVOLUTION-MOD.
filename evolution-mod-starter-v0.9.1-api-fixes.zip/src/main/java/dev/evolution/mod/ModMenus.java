package dev.evolution.mod;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;

/** Registration for the server-synchronized fusion and mythic forge GUIs. */
public final class ModMenus {
    public static final MenuType<FusionMenu> FUSION_MENU = register("fusion", new MenuType<>(FusionMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final MenuType<MythicForgeMenu> MYTHIC_FORGE_MENU = register("mythic_forge", new MenuType<>(MythicForgeMenu::new, FeatureFlags.DEFAULT_FLAGS));
    private ModMenus() {}

    private static <T extends AbstractContainerMenu> MenuType<T> register(String path, MenuType<T> type) {
        Identifier id = Identifier.fromNamespaceAndPath(EvolutionMod.MOD_ID, path);
        ResourceKey<MenuType<?>> key = ResourceKey.create(Registries.MENU, id);
        Registry.register(BuiltInRegistries.MENU, key, type);
        return type;
    }

    public static void initialize() { /* Loading the class performs registration. */ }
}
