package dev.evolution.mod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class EvolutionMod implements ModInitializer {
    public static final String MOD_ID = "evolution";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModMenus.initialize();
        EvolutionSystem.initialize();
        TrialSystem.initialize();
        StoneLootModifier.initialize();
        EvolutionTrades.initialize();
        LOGGER.info("Evolution: World vs You initialized.");
    }
}
