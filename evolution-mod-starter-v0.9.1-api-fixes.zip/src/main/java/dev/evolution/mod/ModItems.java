package dev.evolution.mod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.Function;

/** Registry for the complete set of Evolution essences. */
public final class ModItems {
    private static final Map<EssenceItem.Power, Item> POWER_ITEMS = new EnumMap<>(EssenceItem.Power.class);
    public static final Item SPEED_ESSENCE = register("speed_essence", EssenceItem.Power.SPEED);
    public static final Item STRENGTH_ESSENCE = register("strength_essence", EssenceItem.Power.STRENGTH);
    public static final Item HEALING_ESSENCE = register("healing_essence", EssenceItem.Power.HEALING);
    public static final Item SHADOW_ESSENCE = register("shadow_essence", EssenceItem.Power.SHADOW);
    public static final Item LEAP_ESSENCE = register("leap_essence", EssenceItem.Power.LEAP);
    public static final Item STONE_SKIN_ESSENCE = register("stone_skin_essence", EssenceItem.Power.STONE_SKIN);
    public static final Item FIRE_WARD_ESSENCE = register("fire_ward_essence", EssenceItem.Power.FIRE_WARD);
    public static final Item DEEP_BREATH_ESSENCE = register("deep_breath_essence", EssenceItem.Power.DEEP_BREATH);
    public static final Item NIGHT_SIGHT_ESSENCE = register("night_sight_essence", EssenceItem.Power.NIGHT_SIGHT);
    public static final Item MINER_ESSENCE = register("miner_essence", EssenceItem.Power.MINER);
    public static final Item REGENERATION_ESSENCE = register("regeneration_essence", EssenceItem.Power.REGENERATION);
    public static final Item ABSORPTION_ESSENCE = register("absorption_essence", EssenceItem.Power.ABSORPTION);
    public static final Item FEATHERFALL_ESSENCE = register("featherfall_essence", EssenceItem.Power.FEATHERFALL);
    public static final Item DASH_ESSENCE = register("dash_essence", EssenceItem.Power.DASH);
    public static final Item THUNDER_STRIKE_ESSENCE = register("thunder_strike_essence", EssenceItem.Power.THUNDER_STRIKE);
    public static final Item REPULSE_ESSENCE = register("repulse_essence", EssenceItem.Power.REPULSE);
    public static final Item FROST_EDGE_ESSENCE = register("frost_edge_essence", EssenceItem.Power.FROST_EDGE);
    public static final Item LIFE_LEECH_ESSENCE = register("life_leech_essence", EssenceItem.Power.LIFE_LEECH);
    public static final Item HUNTER_ESSENCE = register("hunter_essence", EssenceItem.Power.HUNTER);
    public static final Item DANGER_SENSE_ESSENCE = register("danger_sense_essence", EssenceItem.Power.DANGER_SENSE);
    public static final Item SHADOW_STEP_ESSENCE = register("shadow_step_essence", EssenceItem.Power.SHADOW_STEP);
    public static final Item ENERGY_SHIELD_ESSENCE = register("energy_shield_essence", EssenceItem.Power.ENERGY_SHIELD);
    public static final Item PROSPECTOR_ESSENCE = register("prospector_essence", EssenceItem.Power.PROSPECTOR);
    public static final Item VENOM_GUARD_ESSENCE = register("venom_guard_essence", EssenceItem.Power.VENOM_GUARD);
    public static final Item EVOLUTION_SURGE_ESSENCE = register("evolution_surge_essence", EssenceItem.Power.EVOLUTION_SURGE);
    public static final Item GRAND_ASCENSION_ESSENCE = register("grand_ascension_essence", EssenceItem.Power.GRAND_ASCENSION);
    public static final Item FUSED_ESSENCE = registerUtility("fused_essence", props -> new FusedEssenceItem(props.stacksTo(1).rarity(Rarity.RARE)));
    public static final Item STONE_COMMON = registerUtility("stone_common", props -> new UpgradeStoneItem(props.rarity(Rarity.COMMON)));
    public static final Item STONE_REFINED = registerUtility("stone_refined", props -> new UpgradeStoneItem(props.rarity(Rarity.UNCOMMON)));
    public static final Item STONE_SUPERIOR = registerUtility("stone_superior", props -> new UpgradeStoneItem(props.rarity(Rarity.RARE)));
    public static final Item STONE_LEGENDARY = registerUtility("stone_legendary", props -> new UpgradeStoneItem(props.rarity(Rarity.EPIC)));
    public static final Item STONE_VOID = registerUtility("stone_void", props -> new UpgradeStoneItem(props.rarity(Rarity.EPIC)));
    public static final Item TRIAL_SIGIL = registerUtility("trial_sigil", TrialSigilItem::new);
    public static final Item FUSION_ALTAR = registerUtility("fusion_altar", FusionAltarItem::new);
    public static final Item FUSION_CODEX = registerUtility("fusion_codex", FusionCodexItem::new);
    public static final Item MYTHIC_ALTAR = registerUtility("mythic_altar", props -> new MythicAltarItem(props.rarity(Rarity.EPIC)));
    public static final Item MYTHIC_ESSENCE = registerUtility("mythic_essence", MythicEssenceItem::new);
    public static final Item RIFT_KEY = registerUtility("rift_key", props -> new RiftKeyItem(props.rarity(Rarity.EPIC)));

    private ModItems() {}

    private static Item register(String path, EssenceItem.Power power) {
        Identifier id = Identifier.fromNamespaceAndPath(EvolutionMod.MOD_ID, path);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        Item.Properties properties = new Item.Properties().setId(key);
        if (power == EssenceItem.Power.GRAND_ASCENSION) properties = properties.rarity(Rarity.EPIC);
        Item item = Registry.register(BuiltInRegistries.ITEM, key, new EssenceItem(properties, power));
        POWER_ITEMS.put(power, item);
        return item;
    }

    private static Item registerUtility(String path, Function<Item.Properties, Item> factory) {
        Identifier id = Identifier.fromNamespaceAndPath(EvolutionMod.MOD_ID, path);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        Item.Properties properties = new Item.Properties().setId(key);
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(properties));
    }

    public static Item essenceFor(EssenceItem.Power power) { return POWER_ITEMS.get(power); }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(SPEED_ESSENCE);
            entries.accept(STRENGTH_ESSENCE);
            entries.accept(HEALING_ESSENCE);
            entries.accept(SHADOW_ESSENCE);
            entries.accept(LEAP_ESSENCE);
            entries.accept(STONE_SKIN_ESSENCE);
            entries.accept(FIRE_WARD_ESSENCE);
            entries.accept(DEEP_BREATH_ESSENCE);
            entries.accept(NIGHT_SIGHT_ESSENCE);
            entries.accept(MINER_ESSENCE);
            entries.accept(REGENERATION_ESSENCE);
            entries.accept(ABSORPTION_ESSENCE);
            entries.accept(FEATHERFALL_ESSENCE);
            entries.accept(DASH_ESSENCE);
            entries.accept(THUNDER_STRIKE_ESSENCE);
            entries.accept(REPULSE_ESSENCE);
            entries.accept(FROST_EDGE_ESSENCE);
            entries.accept(LIFE_LEECH_ESSENCE);
            entries.accept(HUNTER_ESSENCE);
            entries.accept(DANGER_SENSE_ESSENCE);
            entries.accept(SHADOW_STEP_ESSENCE);
            entries.accept(ENERGY_SHIELD_ESSENCE);
            entries.accept(PROSPECTOR_ESSENCE);
            entries.accept(VENOM_GUARD_ESSENCE);
            entries.accept(EVOLUTION_SURGE_ESSENCE);
            entries.accept(GRAND_ASCENSION_ESSENCE);
            entries.accept(FUSED_ESSENCE);
            entries.accept(STONE_COMMON);
            entries.accept(STONE_REFINED);
            entries.accept(STONE_SUPERIOR);
            entries.accept(STONE_LEGENDARY);
            entries.accept(STONE_VOID);
            entries.accept(TRIAL_SIGIL);
            entries.accept(FUSION_ALTAR);
            entries.accept(FUSION_CODEX);
            entries.accept(MYTHIC_ALTAR);
            entries.accept(MYTHIC_ESSENCE);
            entries.accept(RIFT_KEY);
        });
    }
}
