package dev.evolution.mod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.skeleton.Skeleton;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.phys.AABB;

import java.util.ArrayDeque;
import java.util.EnumSet;
import java.util.List;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Server-side systems for the single-player Evolution mod.
 * World evolution is derived from saved overworld day time, so reloading a
 * world does not independently increment the difficulty.
 */
public final class EvolutionSystem {
    private static final long UPDATE_INTERVAL_TICKS = 100L; // Recheck nearby hostile mobs every 5 seconds.
    private static final double MOB_SCAN_RADIUS = 40.0D;
    private static final double MOB_SCAN_RADIUS_SQUARED = MOB_SCAN_RADIUS * MOB_SCAN_RADIUS;
    private static final int MAX_EVOLUTION_LEVEL = 5;
    private static final int COMBAT_HISTORY_SIZE = 20;
    private static final int MIN_KILLS_FOR_ADAPTATION = 8;

    private static final Map<UUID, CombatProfile> COMBAT_PROFILES = new HashMap<>();
    private static final Map<UUID, LifeLeechState> LIFE_LEECH_UNTIL = new HashMap<>();
    private static int lastAnnouncedLevel = -1;

    private record LifeLeechState(ResourceKey<Level> dimension, long expiresAt) {}

    private EvolutionSystem() {
    }

    public static void initialize() {
        ServerTickEvents.END_WORLD_TICK.register(EvolutionSystem::onWorldTick);
        ServerLivingEntityEvents.AFTER_DEATH.register(EvolutionSystem::onEntityDeath);
        ServerLivingEntityEvents.AFTER_DAMAGE.register(EvolutionSystem::onEntityAfterDamage);

        // Combat history is session-only. Clear it when a single-player integrated server starts/stops,
        // avoiding accidental carry-over between worlds and releasing UUIDs from memory.
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            COMBAT_PROFILES.clear();
            LIFE_LEECH_UNTIL.clear();
            lastAnnouncedLevel = evolutionLevel(server.overworld());
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            COMBAT_PROFILES.clear();
            LIFE_LEECH_UNTIL.clear();
            lastAnnouncedLevel = -1;
        });
    }

    private static void onWorldTick(ServerLevel world) {
        ServerLevel overworld = world.getServer().overworld();
        int level = evolutionLevel(overworld);
        if (world.dimension().equals(Level.END) && world.getGameTime() % 20L == 0L) strengthenEnderDragon(world);
        if (world.dimension().equals(Level.OVERWORLD) && world.getGameTime() % 100L == 0L) {
            for (ServerPlayer candidate : world.getServer().getPlayerList().getPlayers()) announceMythicReady(candidate);
        }
        if (world.getGameTime() % 20L == 0L) {
            // Game time is dimension-local. Expire an activation only against the clock of its own dimension.
            LIFE_LEECH_UNTIL.entrySet().removeIf(entry -> entry.getValue().dimension().equals(world.dimension())
                    && entry.getValue().expiresAt() <= world.getGameTime());
        }

        // Announce once per new level, from the overworld tick only, so loaded dimensions cannot duplicate it.
        if (world.dimension().equals(Level.OVERWORLD)) {
            if (lastAnnouncedLevel < 0) {
                lastAnnouncedLevel = level;
            } else if (level > lastAnnouncedLevel) {
                lastAnnouncedLevel = level;
                for (ServerPlayer player : world.getServer().getPlayerList().getPlayers()) {
                    player.displayClientMessage(
                            Component.translatable("message.evolution.world_level", level), false);
                }
            } else if (level < lastAnnouncedLevel) {
                // Handles a deliberate time reset through commands without leaving stale announcement state.
                lastAnnouncedLevel = level;
            }
        }

        if (level <= 0 || world.getGameTime() % UPDATE_INTERVAL_TICKS != 0L) {
            return;
        }

        // Prevent a mob standing inside two players' scan boxes from being processed twice in one pass.
        Set<UUID> updatedMobs = new HashSet<>();
        for (ServerPlayer player : world.players()) {
            AABB scanBox = player.getBoundingBox().inflate(MOB_SCAN_RADIUS);
            CombatProfile profile = COMBAT_PROFILES.get(player.getUUID());

            for (Mob mob : world.getEntitiesOfClass(Mob.class, scanBox,
                    candidate -> candidate instanceof Enemy
                            && candidate.isAlive()
                            && player.distanceToSqr(candidate) <= MOB_SCAN_RADIUS_SQUARED)) {
                if (!updatedMobs.add(mob.getUUID())) {
                    continue;
                }
                applyEvolutionBuffs(mob, level);
                applyAdaptiveBehavior(mob, player, profile, level);
            }
        }
    }

    private static int evolutionLevel(ServerLevel overworld) {
        long day = Math.max(0L, overworld.getDayTime() / 24_000L);
        return (int) Math.min(MAX_EVOLUTION_LEVEL, day / 2L);
    }

    private static void applyEvolutionBuffs(Mob mob, int level) {
        if (level <= 0) {
            return;
        }

        // Effect amplifiers are zero-based: 0 = level I, 1 = level II, etc.
        int speedAmplifier = switch (level) {
            case 1, 2 -> 0;
            case 3, 4 -> 1;
            default -> 2;
        };
        mob.addEffect(new MobEffectInstance(MobEffects.SPEED, 140, speedAmplifier));

        if (level >= 2) {
            int strengthAmplifier = level >= 4 ? 1 : 0;
            mob.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 140, strengthAmplifier));
        }

        if (level >= 3) {
            mob.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 140, 0));
        }
    }

    private static void applyAdaptiveBehavior(Mob mob, ServerPlayer player, CombatProfile profile, int level) {
        if (profile == null || profile.totalKills() < MIN_KILLS_FOR_ADAPTATION || level < 1) {
            return;
        }

        double distanceSquared = mob.distanceToSqr(player);
        CombatStyle style = profile.dominantStyle();

        if (style == CombatStyle.RANGED && distanceSquared >= 100.0D) {
            // If ranged combat dominates, distant hostile mobs gain an extra speed step to close the gap.
            int baseAmplifier = switch (level) {
                case 1, 2 -> 0;
                case 3, 4 -> 1;
                default -> 2;
            };
            int adaptiveAmplifier = Math.min(3, baseAmplifier + 1);
            mob.addEffect(new MobEffectInstance(MobEffects.SPEED, 120, adaptiveAmplifier));
        } else if (style == CombatStyle.MELEE && distanceSquared <= 25.0D) {
            // If close combat dominates, nearby hostile mobs briefly become harder to damage.
            int amplifier = level >= 4 ? 1 : 0;
            mob.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 120, amplifier));
        }
    }

    /** Starts the ten-second Life Leech window for one player. */
    public static void activateLifeLeech(ServerPlayer player) {
        if (player.level() instanceof ServerLevel world) {
            LIFE_LEECH_UNTIL.put(player.getUUID(), new LifeLeechState(world.dimension(), world.getGameTime() + 200L));
        }
    }

    private static void onEntityAfterDamage(LivingEntity damaged, DamageSource source,
                                            float baseDamageTaken, float damageTaken, boolean blocked) {
        if (!(damaged instanceof Enemy) || damageTaken <= 0.0F) return;
        if (!(source.getEntity() instanceof ServerPlayer attacker)) return;
        if (!(attacker.level() instanceof ServerLevel world)) return;
        LifeLeechState state = LIFE_LEECH_UNTIL.get(attacker.getUUID());
        if (state == null) return;
        if (!state.dimension().equals(world.dimension()) || world.getGameTime() >= state.expiresAt()) {
            LIFE_LEECH_UNTIL.remove(attacker.getUUID());
            return;
        }
        // Heal 35% of damage actually dealt, capped at one heart per hit.
        attacker.heal(Math.min(2.0F, damageTaken * 0.35F));
        world.sendParticles(ParticleTypes.HEART, attacker.getX(), attacker.getY() + 1.0D, attacker.getZ(),
                1, 0.2D, 0.25D, 0.2D, 0.0D);
    }

    private static void onEntityDeath(LivingEntity entity, DamageSource damageSource) {
        boolean bossKill = isMajorBoss(entity);
        if (!(entity instanceof Enemy) && !bossKill) return;
        if (!(entity.level() instanceof ServerLevel world)) return;
        if (!(damageSource.getEntity() instanceof ServerPlayer player)) return;

        // Combat-style adaptation only uses normal hostile mobs; boss kills have their own milestone.
        if (entity instanceof Enemy) recordCombatStyle(player, damageSource);
        ItemStack fusedInHand = player.getMainHandItem().is(ModItems.FUSED_ESSENCE) ? player.getMainHandItem()
                : (player.getOffhandItem().is(ModItems.FUSED_ESSENCE) ? player.getOffhandItem() : ItemStack.EMPTY);
        if (!fusedInHand.isEmpty() && !FusionData.readPowers(fusedInHand).isEmpty()) {
            int points = FusionData.recordKill(fusedInHand, bossKill, entity);
            player.displayClientMessage(Component.translatable("message.evolution.skill.kill_points", points,
                    FusionData.points(fusedInHand), bossKill), true);
        }

        int level = evolutionLevel(world.getServer().overworld());
        // The legendary drop is rolled independently: 0.5% per qualifying hostile kill.
        boolean grandAscension = world.getRandom().nextFloat() < 0.005F;
        if (!grandAscension) {
            float dropChance = 0.12F + (level * 0.05F); // 12% at level 0, 37% at level 5.
            if (world.getRandom().nextFloat() >= dropChance) return;
        }

        Item essence = grandAscension ? ModItems.GRAND_ASCENSION_ESSENCE : chooseEssence(entity, world);
        ItemStack stack = new ItemStack(essence);
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }

        player.displayClientMessage(Component.translatable(grandAscension
                ? "message.evolution.grand_ascension_dropped"
                : "message.evolution.essence_dropped"), true);
        world.sendParticles(ParticleTypes.ENCHANT,
                entity.getX(), entity.getY() + 0.4D, entity.getZ(),
                6, 0.22D, 0.22D, 0.22D, 0.015D);
        spawnEssenceDropVisual(world, entity, essence);
    }

    private static boolean isMajorBoss(LivingEntity entity) {
        return entity instanceof EnderDragon || entity.getType() == EntityType.WITHER || entity.getType() == EntityType.WARDEN
                || entity.getTags().contains("evolution_trial_boss");
    }

    /** The all-powers ending is announced only when every original, unmerged essence is carried. */
    private static void announceMythicReady(ServerPlayer player) {
        if (player.getTags().contains("evolution_mythic_ready_announced")) return;
        Set<EssenceItem.Power> carried = EnumSet.noneOf(EssenceItem.Power.class);
        for (ItemStack stack : player.getInventory().getNonEquipmentItems()) {
            if (stack.getItem() instanceof EssenceItem essence) carried.add(essence.getPower());
        }
        if (player.getOffhandItem().getItem() instanceof EssenceItem essence) carried.add(essence.getPower());
        if (carried.size() == EssenceItem.Power.values().length) {
            player.addTag("evolution_mythic_ready_announced");
            player.displayClientMessage(Component.translatable("message.evolution.mythic.ready"), false);
            // The collection milestone immediately opens the final ritual GUI. Players still
            // place each original essence manually; fused (two/three-power) stones do not qualify.
            player.openMenu(new SimpleMenuProvider(
                    (id, inventory, owner) -> new MythicForgeMenu(id, inventory),
                    Component.translatable("screen.evolution.mythic_forge.title")));
        }
    }

    /** A greatly strengthened Ender Dragon with 1,800 health, three phases and escalating adds. */
    private static void strengthenEnderDragon(ServerLevel world) {
        if (!world.dimension().equals(Level.END)) return;
        AABB arena = new AABB(-256.0D, world.getMinY(), -256.0D, 256.0D, world.getMaxY(), 256.0D);
        for (EnderDragon dragon : world.getEntitiesOfClass(EnderDragon.class, arena, Entity::isAlive)) {
            var health = dragon.getAttribute(Attributes.MAX_HEALTH);
            if (health != null && health.getBaseValue() < 1799.0D) {
                health.setBaseValue(1800.0D);
                dragon.setHealth(1800.0F);
                dragon.addTag("evolution_dragon_powered");
                world.sendParticles(ParticleTypes.DRAGON_BREATH, dragon.getX(), dragon.getY(), dragon.getZ(), 80, 6.0D, 3.0D, 6.0D, 0.05D);
                for (ServerPlayer player : world.players()) player.displayClientMessage(Component.translatable("message.evolution.dragon.strong"), false);
            }
            var attack = dragon.getAttribute(Attributes.ATTACK_DAMAGE);
            if (attack != null && attack.getBaseValue() < 48.0D) attack.setBaseValue(48.0D);
            double ratio = dragon.getHealth() / Math.max(1.0D, dragon.getMaxHealth());
            if (ratio <= 0.70D && !dragon.getTags().contains("evolution_dragon_phase_two")) {
                dragon.addTag("evolution_dragon_phase_two");
                dragon.heal(250.0F);
                spawnDragonAdds(world, dragon, 8);
                world.sendParticles(ParticleTypes.DRAGON_BREATH, dragon.getX(), dragon.getY(), dragon.getZ(), 100, 7.0D, 4.0D, 7.0D, 0.08D);
                for (ServerPlayer player : world.players()) player.displayClientMessage(Component.translatable("message.evolution.dragon.phase_two"), false);
                // Recompute after healing so a single oversized hit cannot trigger both phases at once.
                ratio = dragon.getHealth() / Math.max(1.0D, dragon.getMaxHealth());
            }
            if (ratio <= 0.25D && !dragon.getTags().contains("evolution_dragon_phase_three")) {
                dragon.addTag("evolution_dragon_phase_three");
                dragon.heal(350.0F);
                spawnDragonAdds(world, dragon, 16);
                world.sendParticles(ParticleTypes.DRAGON_BREATH, dragon.getX(), dragon.getY(), dragon.getZ(), 140, 8.0D, 5.0D, 8.0D, 0.1D);
                for (ServerPlayer player : world.players()) player.displayClientMessage(Component.translatable("message.evolution.dragon.phase_three"), false);
            }
        }
    }

    private static void spawnDragonAdds(ServerLevel world, EnderDragon dragon, int count) {
        for (int i = 0; i < count; i++) {
            EnderMan enderman = EntityType.ENDERMAN.create(world);
            if (enderman == null) continue;
            double angle = world.getRandom().nextDouble() * Math.PI * 2.0D;
            double radius = 8.0D + world.getRandom().nextDouble() * 8.0D;
            int x = (int) Math.floor(dragon.getX() + Math.cos(angle) * radius);
            int z = (int) Math.floor(dragon.getZ() + Math.sin(angle) * radius);
            int y = Math.max(world.getMinY() + 1, Math.min(world.getMaxY() - 2, (int) dragon.getY()));
            enderman.snapTo(x + 0.5D, y, z + 0.5D);
            enderman.setYRot(world.getRandom().nextFloat() * 360.0F);
            enderman.setXRot(0.0F);
            enderman.setPersistenceRequired();
            world.addFreshEntity(enderman);
        }
    }

    /** Adds a small color-coded ring to make a dropped essence visible without custom renderers. */
    private static void spawnEssenceDropVisual(ServerLevel world, LivingEntity entity, Item essence) {
        EssenceItem.Power power = powerForEssence(essence);
        DustParticleOptions dust = new DustParticleOptions(EssenceItem.colorFor(power), 0.9F);
        double x = entity.getX();
        double y = entity.getY() + Math.min(0.8D, entity.getBbHeight() * 0.45D);
        double z = entity.getZ();
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2.0D * i / 8.0D;
            world.sendParticles(dust, x + Math.cos(angle) * 0.32D, y, z + Math.sin(angle) * 0.32D,
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    private static EssenceItem.Power powerForEssence(Item essence) {
        for (EssenceItem.Power power : EssenceItem.Power.values()) {
            Item registered = switch (power) {
                case SPEED -> ModItems.SPEED_ESSENCE;
                case STRENGTH -> ModItems.STRENGTH_ESSENCE;
                case HEALING -> ModItems.HEALING_ESSENCE;
                case SHADOW -> ModItems.SHADOW_ESSENCE;
                case LEAP -> ModItems.LEAP_ESSENCE;
                case STONE_SKIN -> ModItems.STONE_SKIN_ESSENCE;
                case FIRE_WARD -> ModItems.FIRE_WARD_ESSENCE;
                case DEEP_BREATH -> ModItems.DEEP_BREATH_ESSENCE;
                case NIGHT_SIGHT -> ModItems.NIGHT_SIGHT_ESSENCE;
                case MINER -> ModItems.MINER_ESSENCE;
                case REGENERATION -> ModItems.REGENERATION_ESSENCE;
                case ABSORPTION -> ModItems.ABSORPTION_ESSENCE;
                case FEATHERFALL -> ModItems.FEATHERFALL_ESSENCE;
                case DASH -> ModItems.DASH_ESSENCE;
                case THUNDER_STRIKE -> ModItems.THUNDER_STRIKE_ESSENCE;
                case REPULSE -> ModItems.REPULSE_ESSENCE;
                case FROST_EDGE -> ModItems.FROST_EDGE_ESSENCE;
                case LIFE_LEECH -> ModItems.LIFE_LEECH_ESSENCE;
                case HUNTER -> ModItems.HUNTER_ESSENCE;
                case DANGER_SENSE -> ModItems.DANGER_SENSE_ESSENCE;
                case SHADOW_STEP -> ModItems.SHADOW_STEP_ESSENCE;
                case ENERGY_SHIELD -> ModItems.ENERGY_SHIELD_ESSENCE;
                case PROSPECTOR -> ModItems.PROSPECTOR_ESSENCE;
                case VENOM_GUARD -> ModItems.VENOM_GUARD_ESSENCE;
                case EVOLUTION_SURGE -> ModItems.EVOLUTION_SURGE_ESSENCE;
                case GRAND_ASCENSION -> ModItems.GRAND_ASCENSION_ESSENCE;
            };
            if (registered == essence) return power;
        }
        return EssenceItem.Power.SPEED;
    }

    private static void recordCombatStyle(ServerPlayer player, DamageSource damageSource) {
        Entity directEntity = damageSource.getDirectEntity();
        CombatStyle style;
        if (directEntity instanceof Projectile projectile) {
            // Only count projectiles actually owned by this player; don't infer from the held item.
            if (projectile.getOwner() != player) {
                return;
            }
            style = CombatStyle.RANGED;
        } else if (directEntity == player) {
            style = CombatStyle.MELEE;
        } else {
            // Fire, fall damage, TNT, and other indirect causes must not masquerade as melee kills.
            return;
        }

        CombatProfile profile = COMBAT_PROFILES.computeIfAbsent(
                player.getUUID(), ignored -> new CombatProfile());
        profile.record(style);
    }

    private static Item chooseEssence(LivingEntity entity, ServerLevel world) {
        if (entity instanceof Spider) return ModItems.LEAP_ESSENCE;
        if (entity instanceof EnderMan) return ModItems.SHADOW_ESSENCE;
        if (entity instanceof Zombie) return ModItems.HEALING_ESSENCE;
        if (entity instanceof Skeleton) return ModItems.SPEED_ESSENCE;
        if (entity instanceof Creeper) return ModItems.STRENGTH_ESSENCE;
        Item[] common = new Item[] {
            ModItems.SPEED_ESSENCE,
            ModItems.STRENGTH_ESSENCE,
            ModItems.HEALING_ESSENCE,
            ModItems.SHADOW_ESSENCE,
            ModItems.LEAP_ESSENCE,
            ModItems.STONE_SKIN_ESSENCE,
            ModItems.FIRE_WARD_ESSENCE,
            ModItems.DEEP_BREATH_ESSENCE,
            ModItems.NIGHT_SIGHT_ESSENCE,
            ModItems.MINER_ESSENCE,
            ModItems.REGENERATION_ESSENCE,
            ModItems.ABSORPTION_ESSENCE,
            ModItems.FEATHERFALL_ESSENCE,
            ModItems.DASH_ESSENCE,
            ModItems.THUNDER_STRIKE_ESSENCE,
            ModItems.REPULSE_ESSENCE,
            ModItems.FROST_EDGE_ESSENCE,
            ModItems.LIFE_LEECH_ESSENCE,
            ModItems.HUNTER_ESSENCE,
            ModItems.DANGER_SENSE_ESSENCE,
            ModItems.SHADOW_STEP_ESSENCE,
            ModItems.ENERGY_SHIELD_ESSENCE,
            ModItems.PROSPECTOR_ESSENCE,
            ModItems.VENOM_GUARD_ESSENCE,
            ModItems.EVOLUTION_SURGE_ESSENCE,
        };
        return common[world.getRandom().nextInt(common.length)];
    }

    private enum CombatStyle {
        MELEE,
        RANGED,
        MIXED
    }

    /** Keeps only recent kills, so the adaptation can change when the player changes play style. */
    private static final class CombatProfile {
        private final ArrayDeque<CombatStyle> recentKills = new ArrayDeque<>();

        private void record(CombatStyle style) {
            recentKills.addLast(style);
            while (recentKills.size() > COMBAT_HISTORY_SIZE) {
                recentKills.removeFirst();
            }
        }

        private int totalKills() {
            return recentKills.size();
        }

        private CombatStyle dominantStyle() {
            int melee = 0;
            int ranged = 0;
            for (CombatStyle style : recentKills) {
                if (style == CombatStyle.MELEE) {
                    melee++;
                } else if (style == CombatStyle.RANGED) {
                    ranged++;
                }
            }
            if (ranged >= melee + 4) {
                return CombatStyle.RANGED;
            }
            if (melee >= ranged + 4) {
                return CombatStyle.MELEE;
            }
            return CombatStyle.MIXED;
        }
    }
}
