package dev.evolution.mod;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

/** An upgrade catalyst that can be reused indefinitely. */
public final class UpgradeStoneItem extends Item {
    public UpgradeStoneItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display,
                                Consumer<Component> consumer, TooltipFlag flag) {
        consumer.accept(Component.translatable("tooltip.evolution.stone_reusable")
            .withStyle(ChatFormatting.AQUA));
        consumer.accept(Component.translatable("tooltip.evolution.stone_find_chests")
            .withStyle(ChatFormatting.GRAY));
    }
}
