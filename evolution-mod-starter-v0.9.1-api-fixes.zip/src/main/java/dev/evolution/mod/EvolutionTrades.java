package dev.evolution.mod;

import java.util.Optional;

import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.item.ItemCost;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;

/** Small stone economy: clerics trade common stones, while high-tier deals need late-game materials. */
public final class EvolutionTrades {
    private EvolutionTrades() {}

    public static void initialize() {
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CLERIC, 2, offers -> {
            offers.add((villager, random) -> new MerchantOffer(new ItemCost(Items.EMERALD, 10), new ItemStack(ModItems.STONE_COMMON), 6, 8, 0.05F));
            offers.add((villager, random) -> new MerchantOffer(new ItemCost(Items.EMERALD, 18), Optional.of(new ItemCost(Items.AMETHYST_SHARD, 4)), new ItemStack(ModItems.STONE_REFINED), 4, 12, 0.05F));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CLERIC, 4, offers -> {
            offers.add((villager, random) -> new MerchantOffer(new ItemCost(Items.EMERALD, 24), Optional.of(new ItemCost(Items.AMETHYST_SHARD, 12)), new ItemStack(ModItems.STONE_SUPERIOR), 3, 20, 0.05F));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CLERIC, 5, offers -> {
            offers.add((villager, random) -> new MerchantOffer(new ItemCost(Items.EMERALD, 36), Optional.of(new ItemCost(Items.DIAMOND, 4)), new ItemStack(ModItems.STONE_LEGENDARY), 2, 30, 0.05F));
            offers.add((villager, random) -> new MerchantOffer(new ItemCost(Items.EMERALD, 48), Optional.of(new ItemCost(Items.ECHO_SHARD, 2)), new ItemStack(ModItems.STONE_VOID), 1, 40, 0.05F));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CARTOGRAPHER, 5, offers -> {
            offers.add((villager, random) -> new MerchantOffer(new ItemCost(Items.EMERALD, 32), Optional.of(new ItemCost(Items.ECHO_SHARD, 1)), new ItemStack(ModItems.RIFT_KEY), 1, 25, 0.05F));
        });
    }
}
