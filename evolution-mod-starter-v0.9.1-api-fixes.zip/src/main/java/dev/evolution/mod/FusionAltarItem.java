package dev.evolution.mod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Portable handheld access point for the fusion and un-fusion screen. */
public final class FusionAltarItem extends Item {
    public FusionAltarItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.openMenu(new SimpleMenuProvider(
                    (containerId, inventory, owner) -> new FusionMenu(containerId, inventory),
                    Component.translatable("screen.evolution.fusion.title")));
        }
        return InteractionResult.SUCCESS;
    }
}
