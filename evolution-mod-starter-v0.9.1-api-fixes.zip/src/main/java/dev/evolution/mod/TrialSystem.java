package dev.evolution.mod;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.skeleton.Skeleton;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.item.ItemEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** A command-started, biome-independent trial chamber with randomized stone rewards. */
public final class TrialSystem {
    private static final int HALF_SIZE = 12;
    private static final int WALL_HEIGHT = 7;
    private static final Map<UUID, TrialRun> ACTIVE_RUNS = new HashMap<>();
    private static final Map<UUID, UUID> ENTITY_TO_RUN_OWNER = new HashMap<>();
    private static final Random RANDOM = new Random();

    private TrialSystem() {}

    public static void initialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
        ServerLivingEntityEvents.AFTER_DEATH.register(TrialSystem::onEntityDeath);
        ServerTickEvents.END_WORLD_TICK.register(TrialSystem::onWorldTick);
        // These maps hold live entity UUIDs and ServerLevel references; never let them leak between worlds.
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ACTIVE_RUNS.clear();
            ENTITY_TO_RUN_OWNER.clear();
        });
        // Clean active arenas while levels are still loaded, so stopping the game cannot save a sealed, orphaned room.
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (TrialRun run : new ArrayList<>(ACTIVE_RUNS.values())) cleanupRun(run);
            ACTIVE_RUNS.clear();
            ENTITY_TO_RUN_OWNER.clear();
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            ACTIVE_RUNS.clear();
            ENTITY_TO_RUN_OWNER.clear();
        });
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("evolution")
                .then(Commands.literal("trial")
                    .then(Commands.literal("easy").executes(ctx -> startFromCommand(ctx.getSource(), Difficulty.EASY)))
                    .then(Commands.literal("medium").executes(ctx -> startFromCommand(ctx.getSource(), Difficulty.MEDIUM)))
                    .then(Commands.literal("hard").executes(ctx -> startFromCommand(ctx.getSource(), Difficulty.HARD)))
                    .then(Commands.literal("impossible").executes(ctx -> startFromCommand(ctx.getSource(), Difficulty.IMPOSSIBLE)))
                    .then(Commands.literal("status").executes(ctx -> status(ctx.getSource())))));
    }

    private static int startFromCommand(CommandSourceStack source, Difficulty difficulty) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        startTrial(player, difficulty);
        return 1;
    }

    private static int status(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        TrialRun run = ACTIVE_RUNS.get(player.getUUID());
        if (run == null) {
            player.displayClientMessage(Component.translatable("message.evolution.trial.none"), false);
        } else {
            player.displayClientMessage(Component.translatable("message.evolution.trial.status", run.difficulty.label(), run.wave, run.difficulty.waves, run.alive.size()), false);
        }
        return 1;
    }

    static boolean startTrial(ServerPlayer player, Difficulty difficulty) {
        return startTrial(player, difficulty, false);
    }

    static boolean startSecretRift(ServerPlayer player) {
        return startTrial(player, Difficulty.IMPOSSIBLE, true);
    }

    private static boolean startTrial(ServerPlayer player, Difficulty difficulty, boolean secretRift) {
        UUID playerId = player.getUUID();
        if (ACTIVE_RUNS.containsKey(playerId)) {
            player.displayClientMessage(Component.translatable("message.evolution.trial.already_active"), false);
            return false;
        }
        ServerLevel world = player.serverLevel();
        // Put the room nearby, but do not overwrite the player's current build or the terrain below it.
        int centerX = player.blockPosition().getX() + 42;
        int centerZ = player.blockPosition().getZ() + 8;
        int maxSurface = player.blockPosition().getY();
        for (int x = centerX - HALF_SIZE; x <= centerX + HALF_SIZE; x++) {
            for (int z = centerZ - HALF_SIZE; z <= centerZ + HALF_SIZE; z++) {
                // Include leaf canopies and structures in the height check; do not build through tree crowns.
                maxSurface = Math.max(maxSurface, world.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z));
            }
        }
        // Never force the room down into a high ceiling (e.g. Nether bedrock roof) just to fit it.
        int floorY = maxSurface + 3;
        if (floorY + WALL_HEIGHT + 1 >= world.getMaxY() - 1) {
            player.displayClientMessage(Component.translatable("message.evolution.trial.no_room_here"), false);
            return false;
        }
        BlockPos center = new BlockPos(centerX, floorY, centerZ);
        int theme = secretRift ? 4 : RANDOM.nextInt(4);
        buildChamber(world, center, difficulty, theme);
        TrialRun run = new TrialRun(playerId, world, center, difficulty, theme, secretRift);
        ACTIVE_RUNS.put(playerId, run);
        player.teleportTo(new net.minecraft.world.level.portal.TeleportTransition(
                world,
                new net.minecraft.world.phys.Vec3(centerX + 0.5D, floorY + 1.0D, centerZ + 0.5D),
                net.minecraft.world.phys.Vec3.ZERO,
                player.getYRot(),
                player.getXRot(),
                Set.of(),
                net.minecraft.world.level.portal.TeleportTransition.DO_NOTHING));
        player.displayClientMessage(Component.translatable("message.evolution.trial.started", difficulty.label()), false);
        player.displayClientMessage(Component.translatable("message.evolution.trial.warning"), false);
        if (secretRift) player.displayClientMessage(Component.translatable("message.evolution.rift.entered"), false);
        return spawnWave(run);
    }

    private static void buildChamber(ServerLevel world, BlockPos center, Difficulty difficulty, int theme) {
        BlockState floor = theme == 4 ? Blocks.PURPUR_BLOCK.defaultBlockState() : switch (difficulty) {
            case EASY -> Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
            case MEDIUM -> Blocks.STONE_BRICKS.defaultBlockState();
            case HARD -> Blocks.DEEPSLATE_BRICKS.defaultBlockState();
            case IMPOSSIBLE -> Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        };
        BlockState wall = theme == 4 ? Blocks.OBSIDIAN.defaultBlockState() : switch (difficulty) {
            case EASY -> Blocks.STONE_BRICKS.defaultBlockState();
            case MEDIUM -> Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
            case HARD -> Blocks.DEEPSLATE_TILES.defaultBlockState();
            case IMPOSSIBLE -> Blocks.OBSIDIAN.defaultBlockState();
        };
        for (int dx = -HALF_SIZE; dx <= HALF_SIZE; dx++) {
            for (int dz = -HALF_SIZE; dz <= HALF_SIZE; dz++) {
                world.setBlockAndUpdate(center.offset(dx, 0, dz), floor);
                // Glass ceiling keeps the combat chamber sealed while preserving visibility.
                world.setBlockAndUpdate(center.offset(dx, WALL_HEIGHT + 1, dz), Blocks.TINTED_GLASS.defaultBlockState());
                if (Math.abs(dx) == HALF_SIZE || Math.abs(dz) == HALF_SIZE) {
                    for (int dy = 1; dy <= WALL_HEIGHT; dy++) {
                        BlockState part = (Math.abs(dx) == HALF_SIZE && Math.abs(dz) == HALF_SIZE)
                                ? Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState() : wall;
                        world.setBlockAndUpdate(center.offset(dx, dy, dz), part);
                    }
                }
            }
        }
        // Decorative light pylons and a central marker make the generated trial room easy to recognize.
        for (int dx : new int[]{-8, 8}) for (int dz : new int[]{-8, 8}) {
            for (int dy = 1; dy <= 3; dy++) world.setBlockAndUpdate(center.offset(dx, dy, dz), Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
            world.setBlockAndUpdate(center.offset(dx, 4, dz), Blocks.SEA_LANTERN.defaultBlockState());
        }
        world.setBlockAndUpdate(center, theme == 4 ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.AMETHYST_BLOCK.defaultBlockState());
        world.setBlockAndUpdate(center.above(), Blocks.AIR.defaultBlockState());
        // A different elemental floor pattern is rolled for every normal trial; the secret rift has a void pattern.
        BlockState accent = switch (theme) {
            case 0 -> Blocks.MOSS_BLOCK.defaultBlockState();
            case 1 -> Blocks.BLUE_ICE.defaultBlockState();
            case 2 -> Blocks.MAGMA_BLOCK.defaultBlockState();
            case 3 -> Blocks.CALCITE.defaultBlockState();
            default -> Blocks.CRYING_OBSIDIAN.defaultBlockState();
        };
        int accents = theme == 4 ? 14 : 5 + RANDOM.nextInt(8);
        for (int i = 0; i < accents; i++) {
            int dx = RANDOM.nextInt(HALF_SIZE - 4) - (HALF_SIZE - 4) / 2;
            int dz = RANDOM.nextInt(HALF_SIZE - 4) - (HALF_SIZE - 4) / 2;
            if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
            world.setBlockAndUpdate(center.offset(dx, 0, dz), accent);
        }
        // Every chamber has its own randomly positioned rune pylons; the rift is deliberately more ornate.
        for (int i = 0; i < (theme == 4 ? 8 : 3 + RANDOM.nextInt(4)); i++) {
            int dx = RANDOM.nextBoolean() ? -9 + RANDOM.nextInt(3) : 7 + RANDOM.nextInt(3);
            int dz = RANDOM.nextBoolean() ? -9 + RANDOM.nextInt(3) : 7 + RANDOM.nextInt(3);
            for (int dy = 1; dy <= 2 + RANDOM.nextInt(3); dy++) world.setBlockAndUpdate(center.offset(dx, dy, dz), theme == 4 ? Blocks.AMETHYST_BLOCK.defaultBlockState() : Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState());
        }
    }

    private static boolean spawnWave(TrialRun run) {
        ServerLevel world = run.world;
        int wave = run.wave;
        boolean bossSpawnFailed = false;
        int regularCount = switch (run.difficulty) {
            case EASY -> 3 + wave;
            case MEDIUM -> 5 + wave * 2;
            case HARD -> 7 + wave * 3;
            case IMPOSSIBLE -> 10 + wave * 4;
        };
        for (int i = 0; i < regularCount; i++) {
            Mob mob;
            int choice = RANDOM.nextInt(100);
            if (run.secretRift) {
                if (choice < 28) mob = new EnderMan(EntityType.ENDERMAN, world);
                else if (choice < 52) mob = new Blaze(EntityType.BLAZE, world);
                else if (choice < 72) mob = new Witch(EntityType.WITCH, world);
                else if (choice < 88) mob = new Skeleton(EntityType.SKELETON, world);
                else mob = new Zombie(EntityType.ZOMBIE, world);
            } else {
                if (choice < 54) mob = new Zombie(EntityType.ZOMBIE, world);
                else if (choice < 84) mob = new Skeleton(EntityType.SKELETON, world);
                else mob = new Spider(EntityType.SPIDER, world);
            }
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double radius = 5.0D + RANDOM.nextDouble() * 5.0D;
            mob.snapTo(run.center.getX() + 0.5D + Math.cos(angle) * radius, run.center.getY() + 1.0D, run.center.getZ() + 0.5D + Math.sin(angle) * radius);
            mob.setYRot(RANDOM.nextFloat() * 360.0F);
            mob.setXRot(0.0F);
            mob.setPersistenceRequired();
            applyDifficulty(mob, run.difficulty, wave);
            if (world.addFreshEntity(mob)) track(run, mob);
        }
        if (wave == run.difficulty.waves) {
            Zombie boss = new Zombie(EntityType.ZOMBIE, world);
            boss.snapTo(run.center.getX() + 0.5D, run.center.getY() + 1.0D, run.center.getZ() - 4.5D);
            boss.setYRot(0.0F);
            boss.setXRot(0.0F);
            boss.setCustomName(Component.translatable("entity.evolution.trial_boss"));
            boss.setCustomNameVisible(true);
            boss.setPersistenceRequired();
            boss.addTag("evolution_trial_boss");
            int healthBoost = run.secretRift ? 24 : switch (run.difficulty) { case EASY -> 4; case MEDIUM -> 8; case HARD -> 14; case IMPOSSIBLE -> 20; };
            boss.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 20 * 60 * 30, healthBoost));
            boss.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 20 * 60 * 30, run.secretRift ? 4 : run.difficulty == Difficulty.IMPOSSIBLE ? 3 : 1));
            boss.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 20 * 60 * 30, run.secretRift ? 2 : run.difficulty == Difficulty.IMPOSSIBLE ? 1 : 0));
            if (run.secretRift) boss.addEffect(new MobEffectInstance(MobEffects.SPEED, 20 * 60 * 30, 1));
            boss.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(run.difficulty == Difficulty.IMPOSSIBLE ? Items.NETHERITE_SWORD : Items.DIAMOND_SWORD));
            boss.setItemSlot(EquipmentSlot.HEAD, new ItemStack(run.difficulty == Difficulty.IMPOSSIBLE ? Items.NETHERITE_HELMET : Items.DIAMOND_HELMET));
            boss.setItemSlot(EquipmentSlot.CHEST, new ItemStack(run.difficulty == Difficulty.IMPOSSIBLE ? Items.NETHERITE_CHESTPLATE : Items.DIAMOND_CHESTPLATE));
            if (world.addFreshEntity(boss)) {
                run.bossId = boss.getUUID();
                boss.setHealth(boss.getMaxHealth());
                track(run, boss);
            } else {
                bossSpawnFailed = true;
            }
        }
        run.waveAnnounced = true;
        ServerPlayer player = world.getServer().getPlayerList().getPlayer(run.playerId);
        if (bossSpawnFailed || run.alive.isEmpty()) {
            ACTIVE_RUNS.remove(run.playerId);
            cleanupRun(run);
            if (player != null) player.displayClientMessage(Component.translatable("message.evolution.trial.spawn_failed"), false);
            return false;
        }
        if (player != null) player.displayClientMessage(Component.translatable("message.evolution.trial.wave", wave, run.difficulty.waves), false);
        return true;
    }

    private static void applyDifficulty(Mob mob, Difficulty difficulty, int wave) {
        mob.setPersistenceRequired();
        if (difficulty == Difficulty.MEDIUM || difficulty == Difficulty.HARD || difficulty == Difficulty.IMPOSSIBLE) {
            mob.addEffect(new MobEffectInstance(MobEffects.SPEED, 20 * 60 * 20, difficulty == Difficulty.IMPOSSIBLE ? 1 : 0));
        }
        if (difficulty == Difficulty.HARD || difficulty == Difficulty.IMPOSSIBLE) {
            mob.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 20 * 60 * 20, difficulty == Difficulty.IMPOSSIBLE ? 1 : 0));
        }
        if (difficulty == Difficulty.IMPOSSIBLE) mob.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 20 * 60 * 20, 0));
    }

    private static void track(TrialRun run, Mob mob) {
        run.alive.add(mob.getUUID());
        ENTITY_TO_RUN_OWNER.put(mob.getUUID(), run.playerId);
    }

    private static void onEntityDeath(LivingEntity entity, net.minecraft.world.damagesource.DamageSource source) {
        // A player death aborts the run instead of leaving an active challenge that blocks retrying forever.
        if (entity instanceof ServerPlayer fallenPlayer) {
            abandonTrial(fallenPlayer.getUUID());
            fallenPlayer.displayClientMessage(Component.translatable("message.evolution.trial.failed"), false);
            return;
        }
        UUID owner = ENTITY_TO_RUN_OWNER.remove(entity.getUUID());
        if (owner == null) return;
        TrialRun run = ACTIVE_RUNS.get(owner);
        if (run == null) return;
        run.alive.remove(entity.getUUID());
        if (!run.alive.isEmpty()) return;
        if (run.wave < run.difficulty.waves) {
            run.wave++;
            spawnWave(run);
        } else {
            finishTrial(run);
        }
    }

    private static void finishTrial(TrialRun run) {
        ACTIVE_RUNS.remove(run.playerId);
        Random random = new Random();
        Item stone = chooseStone(run.difficulty, random);
        drop(run.world, run.center, new ItemStack(stone, 1)); // The stone is guaranteed in every victory.
        if (run.secretRift) {
            drop(run.world, run.center.offset(2, 0, 0), new ItemStack(ModItems.STONE_VOID, 1));
            drop(run.world, run.center.offset(-2, 0, 0), new ItemStack(ModItems.STONE_LEGENDARY, 1));
            drop(run.world, run.center.offset(0, 0, 2), new ItemStack(ModItems.STONE_SUPERIOR, 2));
        }
        boolean bonusLoot = random.nextFloat() < run.difficulty.bonusLootChance;
        if (bonusLoot) {
            List<ItemStack> loot = bonusLoot(run.difficulty, random);
            for (ItemStack stack : loot) drop(run.world, run.center, stack);
        }
        if (random.nextFloat() < run.difficulty.bonusStoneChance) {
            drop(run.world, run.center, new ItemStack(chooseStone(run.difficulty, random), 1));
        }
        ServerPlayer player = run.world.getServer().getPlayerList().getPlayer(run.playerId);
        if (player != null) {
            player.displayClientMessage(Component.translatable("message.evolution.trial.complete", run.difficulty.label()), false);
            player.displayClientMessage(Component.translatable(bonusLoot ? "message.evolution.trial.bonus_yes" : "message.evolution.trial.bonus_no"), false);
            player.displayClientMessage(Component.translatable("message.evolution.trial.reward_hint"), false);
            if (run.secretRift) player.displayClientMessage(Component.translatable("message.evolution.rift.reward"), false);
        }
        openExit(run);
    }

    private static void openExit(TrialRun run) {
        // The exit is physically sealed during combat and opens only after the final boss dies.
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = 1; dy <= 3; dy++) {
                run.world.setBlockAndUpdate(run.center.offset(dx, dy, HALF_SIZE), Blocks.AIR.defaultBlockState());
            }
        }
        for (int dx : new int[]{-2, 2}) {
            run.world.setBlockAndUpdate(run.center.offset(dx, 2, HALF_SIZE), Blocks.SEA_LANTERN.defaultBlockState());
        }
    }

    private static Item chooseStone(Difficulty difficulty, Random random) {
        // Percent weights; each table totals exactly 100. Difficulty changes odds, not the guarantee.
        int roll = random.nextInt(1000);
        return switch (difficulty) {
            case EASY -> roll < 740 ? ModItems.STONE_COMMON : roll < 940 ? ModItems.STONE_REFINED : roll < 980 ? ModItems.STONE_SUPERIOR : roll < 995 ? ModItems.STONE_LEGENDARY : ModItems.STONE_VOID;
            case MEDIUM -> roll < 440 ? ModItems.STONE_COMMON : roll < 790 ? ModItems.STONE_REFINED : roll < 940 ? ModItems.STONE_SUPERIOR : roll < 990 ? ModItems.STONE_LEGENDARY : ModItems.STONE_VOID;
            case HARD -> roll < 190 ? ModItems.STONE_COMMON : roll < 490 ? ModItems.STONE_REFINED : roll < 790 ? ModItems.STONE_SUPERIOR : roll < 960 ? ModItems.STONE_LEGENDARY : ModItems.STONE_VOID;
            case IMPOSSIBLE -> roll < 10 ? ModItems.STONE_COMMON : roll < 50 ? ModItems.STONE_REFINED : roll < 250 ? ModItems.STONE_SUPERIOR : roll < 600 ? ModItems.STONE_LEGENDARY : ModItems.STONE_VOID;
        };
    }

    private static List<ItemStack> bonusLoot(Difficulty difficulty, Random random) {
        List<Item> pool = new ArrayList<>(List.of(Items.IRON_INGOT, Items.GOLD_INGOT, Items.EMERALD, Items.DIAMOND, Items.GOLDEN_APPLE));
        if (difficulty == Difficulty.HARD || difficulty == Difficulty.IMPOSSIBLE) pool.add(Items.ECHO_SHARD);
        if (difficulty == Difficulty.IMPOSSIBLE) { pool.add(Items.NETHERITE_SCRAP); pool.add(Items.GOLDEN_APPLE); }
        List<ItemStack> result = new ArrayList<>();
        int count = 1 + random.nextInt(difficulty == Difficulty.IMPOSSIBLE ? 4 : 3);
        for (int i = 0; i < count; i++) {
            Item item = pool.get(random.nextInt(pool.size()));
            int amount = item == Items.IRON_INGOT || item == Items.GOLD_INGOT || item == Items.EMERALD ? 2 + random.nextInt(4) : 1;
            result.add(new ItemStack(item, amount));
        }
        return result;
    }

    private static void drop(ServerLevel world, BlockPos center, ItemStack stack) {
        ItemEntity itemEntity = new ItemEntity(world, center.getX() + 0.5D + (RANDOM.nextDouble() - 0.5D), center.getY() + 1.6D, center.getZ() + 0.5D + (RANDOM.nextDouble() - 0.5D), stack);
        itemEntity.setDefaultPickUpDelay();
        world.addFreshEntity(itemEntity);
    }

    private static void onWorldTick(ServerLevel world) {
        // Each boss has three health-triggered phases; phase summons are tracked as part of the same run.
        if (world.getGameTime() % 10L == 0L) {
            for (TrialRun run : ACTIVE_RUNS.values()) if (run.world == world) updateBossPhase(run);
        }
        // Release stale owner/entity indexes if a trial was abandoned after the player disconnected.
        if (world.getGameTime() % 200L != 0L) return;
        Iterator<Map.Entry<UUID, TrialRun>> iterator = ACTIVE_RUNS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, TrialRun> entry = iterator.next();
            TrialRun run = entry.getValue();
            if (run.world != world || world.getServer().getPlayerList().getPlayer(entry.getKey()) != null) continue;
            // An abandoned session must not leave persistent trial mobs or an entity-owner index behind.
            cleanupRun(run);
            iterator.remove();
        }
    }


    private static void abandonTrial(UUID playerId) {
        TrialRun run = ACTIVE_RUNS.remove(playerId);
        if (run != null) cleanupRun(run);
    }

    /** Clears all entities and owner references for an interrupted run and prevents a sealed soft-lock. */
    private static void cleanupRun(TrialRun run) {
        for (UUID entityId : new HashSet<>(run.alive)) {
            Entity tracked = run.world.getEntity(entityId);
            if (tracked != null) tracked.discard();
            ENTITY_TO_RUN_OWNER.remove(entityId, run.playerId);
        }
        run.alive.clear();
        openExit(run);
    }

    private static void updateBossPhase(TrialRun run) {
        if (run.bossId == null) return;
        Entity found = run.world.getEntity(run.bossId);
        if (!(found instanceof LivingEntity boss) || !boss.isAlive()) return;
        double ratio = boss.getHealth() / Math.max(1.0D, boss.getMaxHealth());
        ServerPlayer player = run.world.getServer().getPlayerList().getPlayer(run.playerId);
        if (run.bossPhase == 0 && ratio <= 0.67D) {
            run.bossPhase = 1;
            boss.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 20 * 60 * 10, run.secretRift ? 5 : 2));
            boss.addEffect(new MobEffectInstance(MobEffects.SPEED, 20 * 60 * 10, run.secretRift ? 2 : 1));
            boss.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 20 * 60 * 10, 1));
            boss.heal(boss.getMaxHealth() * (run.secretRift ? 0.24F : 0.12F));
            spawnPhaseAdds(run, run.secretRift ? 4 : 2);
            run.world.sendParticles(net.minecraft.core.particles.ParticleTypes.FLAME, boss.getX(), boss.getY() + 1, boss.getZ(), 60, 1.5D, 1.5D, 1.5D, 0.04D);
            if (player != null) player.displayClientMessage(Component.translatable("message.evolution.trial.boss_phase", 2, 3), false);
        } else if (run.bossPhase == 1 && ratio <= 0.33D) {
            run.bossPhase = 2;
            boss.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 20 * 60 * 10, run.secretRift ? 6 : 3));
            boss.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 20 * 60 * 10, run.secretRift ? 3 : 2));
            boss.addEffect(new MobEffectInstance(MobEffects.SPEED, 20 * 60 * 10, 2));
            boss.heal(boss.getMaxHealth() * (run.secretRift ? 0.30F : 0.18F));
            spawnPhaseAdds(run, run.secretRift ? 7 : 4);
            run.world.sendParticles(net.minecraft.core.particles.ParticleTypes.SOUL_FIRE_FLAME, boss.getX(), boss.getY() + 1, boss.getZ(), 90, 2.0D, 1.5D, 2.0D, 0.06D);
            if (player != null) player.displayClientMessage(Component.translatable("message.evolution.trial.boss_phase", 3, 3), false);
        }
    }

    private static void spawnPhaseAdds(TrialRun run, int count) {
        for (int i = 0; i < count; i++) {
            Mob add;
            int type = RANDOM.nextInt(100);
            if (run.secretRift && type < 40) add = new EnderMan(EntityType.ENDERMAN, run.world);
            else if (run.secretRift && type < 70) add = new Blaze(EntityType.BLAZE, run.world);
            else if (type < 45) add = new Spider(EntityType.SPIDER, run.world);
            else if (type < 75) add = new Skeleton(EntityType.SKELETON, run.world);
            else add = new Zombie(EntityType.ZOMBIE, run.world);
            double angle = RANDOM.nextDouble() * Math.PI * 2.0D;
            double radius = 5.0D + RANDOM.nextDouble() * 4.0D;
            add.snapTo(run.center.getX() + 0.5D + Math.cos(angle) * radius, run.center.getY() + 1.0D,
                    run.center.getZ() + 0.5D + Math.sin(angle) * radius);
            add.setYRot(RANDOM.nextFloat() * 360.0F);
            add.setXRot(0.0F);
            add.setPersistenceRequired();
            add.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 20 * 60 * 10, run.secretRift ? 2 : 1));
            if (run.world.addFreshEntity(add)) track(run, add);
        }
    }

    enum Difficulty {
        EASY("easy", 2, 0.35F, 0.05F),
        MEDIUM("medium", 3, 0.55F, 0.10F),
        HARD("hard", 4, 0.75F, 0.20F),
        IMPOSSIBLE("impossible", 5, 0.90F, 0.35F);
        final String id;
        final int waves;
        final float bonusLootChance;
        final float bonusStoneChance;
        Difficulty(String id, int waves, float bonusLootChance, float bonusStoneChance) {
            this.id = id; this.waves = waves;
            this.bonusLootChance = bonusLootChance; this.bonusStoneChance = bonusStoneChance;
        }
        Component label() { return Component.translatable("difficulty.evolution." + id); }
    }

    private static final class TrialRun {
        final UUID playerId;
        final ServerLevel world;
        final BlockPos center;
        final Difficulty difficulty;
        final Set<UUID> alive = new HashSet<>();
        int wave = 1;
        boolean waveAnnounced;
        final int theme;
        final boolean secretRift;
        UUID bossId;
        int bossPhase;
        TrialRun(UUID playerId, ServerLevel world, BlockPos center, Difficulty difficulty, int theme, boolean secretRift) {
            this.playerId = playerId; this.world = world; this.center = center; this.difficulty = difficulty;
            this.theme = theme; this.secretRift = secretRift;
        }
    }
}
