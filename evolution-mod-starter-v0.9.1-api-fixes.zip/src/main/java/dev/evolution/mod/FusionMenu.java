package dev.evolution.mod;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.SimpleContainer;

/** A 3-input menu; fusion choices are generated dynamically from the complete essence set. */
public final class FusionMenu extends AbstractContainerMenu {
    public static final int BUTTON_FUSE = 0;
    public static final int BUTTON_SPLIT = 1;
    public static final int BUTTON_UPGRADE = 2;
    public static final int BUTTON_DAMAGE = 3;
    public static final int BUTTON_RANGE = 4;
    public static final int BUTTON_TARGETS = 5;
    public static final int BUTTON_DEFENSE = 6;
    public static final int BUTTON_EQUIPMENT = 7;
    public static final int BUTTON_DURATION = 8;
    public static final int BUTTON_CONTROL = 9;
    public static final int BUTTON_CRITICAL = 10;
    public static final int BUTTON_ELEMENTAL = 11;
    public static final int BUTTON_MOBILITY = 12;
    public static final int BUTTON_STYLE = 13;
    public static final int BUTTON_RESPEC = 14;
    private final SimpleContainer input;

    public FusionMenu(int containerId, Inventory playerInventory) {
        this(containerId, playerInventory, new SimpleContainer(3));
    }

    public FusionMenu(int containerId, Inventory playerInventory, SimpleContainer input) {
        super(ModMenus.FUSION_MENU, containerId);
        this.input = input;
        checkContainerSize(input, 3);
        input.startOpen(playerInventory.player);

        for (int i = 0; i < 3; i++) {
            addSlot(new Slot(input, i, 91 + i * 36, 34) {
                @Override public boolean mayPlace(ItemStack stack) { return FusionData.isFusionIngredient(stack) || FusionData.isUpgradeStone(stack); }
                @Override public int getMaxStackSize(ItemStack stack) { return stack.getMaxStackSize(); }
            });
        }
        // Main player inventory: 27 slots in three rows.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, 9 + row * 9 + col, 49 + col * 18, 164 + row * 18));
            }
        }
        // Hotbar.
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 49 + col * 18, 242));
        }
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (!(player instanceof ServerPlayer serverPlayer)) return false;
        if (id == BUTTON_FUSE) return fuse(serverPlayer);
        if (id == BUTTON_SPLIT) return split(serverPlayer);
        if (id == BUTTON_UPGRADE) return upgrade(serverPlayer);
        if (id == BUTTON_DAMAGE) return improve(serverPlayer, FusionData.Upgrade.DAMAGE);
        if (id == BUTTON_RANGE) return improve(serverPlayer, FusionData.Upgrade.RANGE);
        if (id == BUTTON_TARGETS) return improve(serverPlayer, FusionData.Upgrade.TARGETS);
        if (id == BUTTON_DEFENSE) return improve(serverPlayer, FusionData.Upgrade.DEFENSE);
        if (id == BUTTON_EQUIPMENT) return improve(serverPlayer, FusionData.Upgrade.EQUIPMENT);
        if (id == BUTTON_DURATION) return improve(serverPlayer, FusionData.Upgrade.DURATION);
        if (id == BUTTON_CONTROL) return improve(serverPlayer, FusionData.Upgrade.CONTROL);
        if (id == BUTTON_CRITICAL) return improve(serverPlayer, FusionData.Upgrade.CRITICAL);
        if (id == BUTTON_ELEMENTAL) return improve(serverPlayer, FusionData.Upgrade.ELEMENTAL);
        if (id == BUTTON_MOBILITY) return improve(serverPlayer, FusionData.Upgrade.MOBILITY);
        if (id == BUTTON_STYLE) return cycleStyle(serverPlayer);
        if (id == BUTTON_RESPEC) return respec(serverPlayer);
        return false;
    }

    private boolean fuse(ServerPlayer player) {
        List<EssenceItem.Power> combined = new ArrayList<>();
        List<Integer> occupiedSlots = new ArrayList<>();
        Set<EssenceItem.Power> unique = new HashSet<>();

        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            if (!FusionData.isFusionIngredient(stack)) {
                tell(player, "message.evolution.fusion.invalid_ingredient");
                return false;
            }
            occupiedSlots.add(i);
            List<EssenceItem.Power> stackPowers = FusionData.readPowers(stack);
            for (EssenceItem.Power power : stackPowers) {
                if (!unique.add(power)) {
                    tell(player, "message.evolution.fusion.duplicate_power");
                    return false;
                }
                combined.add(power);
            }
        }

        if (occupiedSlots.size() < 2 || combined.size() < 2 || combined.size() > 3) {
            tell(player, "message.evolution.fusion.need_two_or_three");
            return false;
        }

        ItemStack output = FusionData.create(combined);
        if (output.isEmpty()) {
            tell(player, "message.evolution.fusion.invalid");
            return false;
        }

        for (int slot : occupiedSlots) input.removeItem(slot, 1);
        input.setChanged();
        giveOrDrop(player, output);
        FusionCodexItem.recordDiscovery(player, combined);
        tell(player, "message.evolution.fusion.success", combined.size());
        broadcastChanges();
        return true;
    }


    private boolean upgrade(ServerPlayer player) {
        int fusedSlot = -1;
        int stoneSlot = -1;
        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            if (stack.is(ModItems.FUSED_ESSENCE)) {
                if (fusedSlot != -1) { tell(player, "message.evolution.fusion.upgrade_one_essence"); return false; }
                fusedSlot = i;
            } else if (FusionData.isUpgradeStone(stack)) {
                if (stoneSlot != -1) { tell(player, "message.evolution.fusion.upgrade_one_stone"); return false; }
                stoneSlot = i;
            } else {
                tell(player, "message.evolution.fusion.upgrade_invalid");
                return false;
            }
        }
        if (fusedSlot == -1 || stoneSlot == -1) {
            tell(player, "message.evolution.fusion.upgrade_needs_pair");
            return false;
        }
        ItemStack fused = input.getItem(fusedSlot);
        ItemStack catalyst = input.getItem(stoneSlot);
        int gained = FusionData.applyCatalyst(fused, catalyst);
        if (gained <= 0) {
            tell(player, "message.evolution.fusion.catalyst_full");
            return false;
        }
        // The catalyst item is deliberately not consumed: it can be reused indefinitely.
        input.setChanged();
        tell(player, "message.evolution.fusion.catalyst_points", gained, FusionData.points(fused));
        broadcastChanges();
        return true;
    }

    private ItemStack oneFusedInput(ServerPlayer player) {
        ItemStack found = ItemStack.EMPTY;
        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            if (!stack.is(ModItems.FUSED_ESSENCE) || !found.isEmpty()) {
                tell(player, "message.evolution.skill.place_one_fused");
                return ItemStack.EMPTY;
            }
            found = stack;
        }
        if (found.isEmpty()) tell(player, "message.evolution.skill.place_one_fused");
        return found;
    }

    private boolean improve(ServerPlayer player, FusionData.Upgrade upgrade) {
        ItemStack fused = oneFusedInput(player);
        if (fused.isEmpty()) return false;
        int cost = FusionData.upgradeCost(fused, upgrade);
        int requiredBosses = FusionData.requiredBossKills(fused, upgrade);
        if (FusionData.points(fused) < cost) {
            tell(player, "message.evolution.skill.points_needed", cost, FusionData.points(fused));
            return false;
        }
        if (FusionData.bossKills(fused) < requiredBosses) {
            tell(player, "message.evolution.skill.bosses_needed", requiredBosses, FusionData.bossKills(fused));
            return false;
        }
        int requiredSpecial = FusionData.requiredSpecialKills(fused, upgrade);
        int currentSpecial = FusionData.specialKills(fused, upgrade);
        if (currentSpecial < requiredSpecial) {
            tell(player, "message.evolution.skill.special_kills_needed",
                    Component.translatable("upgrade.evolution." + upgrade.name().toLowerCase(java.util.Locale.ROOT)),
                    requiredSpecial, currentSpecial,
                    Component.translatable("tooltip.evolution.skill." + switch (upgrade) {
                        case CRITICAL -> "skeleton_kills";
                        case RANGE -> "enderman_kills";
                        case CONTROL -> "spider_kills";
                        case ELEMENTAL -> "creeper_kills";
                        default -> "kills";
                    }));
            return false;
        }
        if (!FusionData.spendUpgrade(fused, upgrade)) return false;
        tell(player, "message.evolution.skill.upgraded", Component.translatable("upgrade.evolution." + upgrade.name().toLowerCase(java.util.Locale.ROOT)),
                FusionData.upgradeLevel(fused, upgrade), FusionData.points(fused));
        input.setChanged();
        broadcastChanges();
        return true;
    }

    private boolean cycleStyle(ServerPlayer player) {
        ItemStack fused = oneFusedInput(player);
        if (fused.isEmpty()) return false;
        int style = FusionData.cycleStyle(fused);
        tell(player, "message.evolution.skill.style_changed", Component.translatable("style.evolution." + style));
        input.setChanged();
        broadcastChanges();
        return true;
    }

    private boolean respec(ServerPlayer player) {
        ItemStack fused = oneFusedInput(player);
        if (fused.isEmpty()) return false;
        int refunded = FusionData.respec(fused);
        tell(player, "message.evolution.skill.respec", refunded, FusionData.points(fused));
        input.setChanged();
        broadcastChanges();
        return true;
    }

    private boolean split(ServerPlayer player) {
        int fusedSlot = -1;
        List<EssenceItem.Power> powers = List.of();
        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            if (fusedSlot != -1 || !stack.is(ModItems.FUSED_ESSENCE)) {
                tell(player, "message.evolution.fusion.split_one_only");
                return false;
            }
            fusedSlot = i;
            powers = FusionData.readPowers(stack);
        }
        if (fusedSlot == -1 || powers.size() < 2 || powers.size() > 3) {
            tell(player, "message.evolution.fusion.split_one_only");
            return false;
        }

        input.removeItem(fusedSlot, 1);
        input.setChanged();
        for (EssenceItem.Power power : powers) {
            ItemStack base = new ItemStack(ModItems.essenceFor(power));
            giveOrDrop(player, base);
        }
        tell(player, "message.evolution.fusion.split_success", powers.size());
        broadcastChanges();
        return true;
    }

    private static void giveOrDrop(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) return;
        player.getInventory().placeItemBackInInventory(stack);
    }

    private static void tell(ServerPlayer player, String key, Object... args) {
        player.displayClientMessage(Component.translatable(key, args), true);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack original = ItemStack.EMPTY;
        if (index < 0 || index >= slots.size()) return original;
        Slot slot = slots.get(index);
        if (slot == null || !slot.hasItem()) return original;
        ItemStack source = slot.getItem();
        original = source.copy();

        if (index < 3) {
            if (!moveItemStackTo(source, 3, slots.size(), true)) return ItemStack.EMPTY;
        } else {
            if ((!FusionData.isFusionIngredient(source) && !FusionData.isUpgradeStone(source)) || !moveItemStackTo(source, 0, 3, false)) return ItemStack.EMPTY;
        }
        if (source.isEmpty()) slot.set(ItemStack.EMPTY);
        else slot.setChanged();
        if (source.getCount() == original.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, source);
        return original;
    }

    /** UI status recomputed from the synchronized input slots; never used to authorize server actions. */
    public Component previewStatus() {
        List<EssenceItem.Power> combined = new ArrayList<>();
        Set<EssenceItem.Power> unique = new HashSet<>();
        int occupied = 0;
        int fusedCount = 0;
        int stoneCount = 0;
        boolean hasStone = false;
        for (int i = 0; i < input.getContainerSize(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            occupied++;
            if (FusionData.isUpgradeStone(stack)) { hasStone = true; stoneCount++; continue; }
            if (!FusionData.isFusionIngredient(stack)) return Component.translatable("label.evolution.fusion.invalid");
            if (stack.is(ModItems.FUSED_ESSENCE)) fusedCount++;
            for (EssenceItem.Power power : FusionData.readPowers(stack)) {
                if (!unique.add(power)) return Component.translatable("label.evolution.fusion.duplicate");
                combined.add(power);
            }
        }
        if (hasStone) {
            if (occupied == 2 && fusedCount == 1 && stoneCount == 1) return Component.translatable("label.evolution.fusion.upgrade_ready");
            return Component.translatable("label.evolution.fusion.invalid");
        }
        if (occupied == 1 && fusedCount == 1 && stoneCount == 0) {
            for (int i = 0; i < input.getContainerSize(); i++) {
                ItemStack stack = input.getItem(i);
                if (stack.is(ModItems.FUSED_ESSENCE)) return Component.translatable("label.evolution.fusion.selected_stats", FusionData.points(stack), FusionData.kills(stack));
            }
        }
        if (occupied == 0) return Component.translatable("label.evolution.fusion.empty");
        if (occupied < 2) return Component.translatable("label.evolution.fusion.add_another");
        if (combined.size() < 2) return Component.translatable("label.evolution.fusion.need_two_or_three");
        if (combined.size() > 3) return Component.translatable("label.evolution.fusion.too_many");
        return Component.translatable("label.evolution.fusion.ready", combined.size());
    }

    @Override
    public boolean stillValid(Player player) { return player.isAlive() && !player.isRemoved(); }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (player instanceof ServerPlayer serverPlayer) {
            for (int i = 0; i < input.getContainerSize(); i++) {
                ItemStack stack = input.removeItemNoUpdate(i);
                if (!stack.isEmpty()) giveOrDrop(serverPlayer, stack);
            }
        }
        input.stopOpen(player);
    }
}
