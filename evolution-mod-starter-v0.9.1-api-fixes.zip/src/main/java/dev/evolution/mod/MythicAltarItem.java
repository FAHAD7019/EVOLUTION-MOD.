package dev.evolution.mod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Opens the final ritual GUI; only the 26 separate, unmerged base essences are accepted. */
public final class MythicAltarItem extends Item {
    public MythicAltarItem(Properties properties) { super(properties.stacksTo(1)); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.openMenu(new SimpleMenuProvider(
                    (id, inventory, owner) -> new MythicForgeMenu(id, inventory),
                    Component.translatable("screen.evolution.mythic_forge.title")));
        }
        return InteractionResult.SUCCESS;
    }
}
