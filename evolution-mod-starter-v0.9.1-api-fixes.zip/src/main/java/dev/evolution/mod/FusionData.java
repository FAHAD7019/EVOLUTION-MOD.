package dev.evolution.mod;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/** Persistent fused-stone data: kill-earned upgrade points, ten branches, style and discovery data. */
public final class FusionData {
    private static final String POWER_KEY = "evolution_fusion_powers";
    private static final String USES_KEY = "evolution_fusion_uses";
    private static final String POINTS_KEY = "evolution_fusion_points";
    private static final String TOTAL_POINTS_KEY = "evolution_fusion_total_points";
    private static final String KILLS_KEY = "evolution_fusion_kills";
    private static final String BOSS_KILLS_KEY = "evolution_fusion_boss_kills";
    private static final String SKELETON_KILLS_KEY = "evolution_fusion_skeleton_kills";
    private static final String ENDERMAN_KILLS_KEY = "evolution_fusion_enderman_kills";
    private static final String SPIDER_KILLS_KEY = "evolution_fusion_spider_kills";
    private static final String CREEPER_KILLS_KEY = "evolution_fusion_creeper_kills";
    private static final String DAMAGE_KEY = "evolution_fusion_damage";
    private static final String RANGE_KEY = "evolution_fusion_range";
    private static final String TARGETS_KEY = "evolution_fusion_targets";
    private static final String DEFENSE_KEY = "evolution_fusion_defense";
    private static final String EQUIPMENT_KEY = "evolution_fusion_equipment";
    private static final String DURATION_KEY = "evolution_fusion_duration";
    private static final String CONTROL_KEY = "evolution_fusion_control";
    private static final String CRITICAL_KEY = "evolution_fusion_critical";
    private static final String ELEMENTAL_KEY = "evolution_fusion_elemental";
    private static final String MOBILITY_KEY = "evolution_fusion_mobility";
    private static final String SPENT_KEY = "evolution_fusion_spent";
    private static final String STYLE_KEY = "evolution_fusion_style";
    private FusionData() {}

    public enum Upgrade { DAMAGE, RANGE, TARGETS, DEFENSE, EQUIPMENT, DURATION, CONTROL, CRITICAL, ELEMENTAL, MOBILITY }


    public static boolean isFusionIngredient(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (stack.getItem() instanceof EssenceItem essence) return essence.getPower() != EssenceItem.Power.GRAND_ASCENSION;
        return stack.is(ModItems.FUSED_ESSENCE) && !readPowers(stack).isEmpty();
    }

    public static boolean isUpgradeStone(ItemStack stack) {
        return stack != null && !stack.isEmpty() && (stack.is(ModItems.STONE_COMMON) || stack.is(ModItems.STONE_REFINED)
                || stack.is(ModItems.STONE_SUPERIOR) || stack.is(ModItems.STONE_LEGENDARY) || stack.is(ModItems.STONE_VOID));
    }

    public static List<EssenceItem.Power> readPowers(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return List.of();
        if (stack.getItem() instanceof EssenceItem essence)
            return essence.getPower() == EssenceItem.Power.GRAND_ASCENSION ? List.of() : List.of(essence.getPower());
        if (!stack.is(ModItems.FUSED_ESSENCE)) return List.of();
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        if (data == null || data.isEmpty()) return List.of();
        String encoded = data.copyTag().getStringOr(POWER_KEY, "");
        if (encoded.isBlank()) return List.of();
        List<EssenceItem.Power> powers = new ArrayList<>();
        Set<EssenceItem.Power> unique = new HashSet<>();
        try {
            for (String token : encoded.split(",", -1)) {
                EssenceItem.Power power = EssenceItem.Power.valueOf(token);
                if (power == EssenceItem.Power.GRAND_ASCENSION || !unique.add(power)) return List.of();
                powers.add(power);
            }
        } catch (IllegalArgumentException invalidData) { return List.of(); }
        return powers.size() >= 2 && powers.size() <= 3 ? List.copyOf(powers) : List.of();
    }

    public static ItemStack create(List<EssenceItem.Power> powers) {
        if (powers == null || powers.size() < 2 || powers.size() > 3 || powers.stream().anyMatch(java.util.Objects::isNull)) return ItemStack.EMPTY;
        Set<EssenceItem.Power> unique = new HashSet<>(powers);
        if (unique.size() != powers.size() || unique.contains(EssenceItem.Power.GRAND_ASCENSION)) return ItemStack.EMPTY;
        List<EssenceItem.Power> canonical = new ArrayList<>(powers);
        canonical.sort((a, b) -> Integer.compare(a.ordinal(), b.ordinal()));
        ItemStack stack = new ItemStack(ModItems.FUSED_ESSENCE);
        CompoundTag tag = new CompoundTag();
        tag.putString(POWER_KEY, canonical.stream().map(Enum::name).collect(Collectors.joining(",")));
        tag.putInt(USES_KEY, 0);
        tag.putInt(POINTS_KEY, 0);
        tag.putInt(TOTAL_POINTS_KEY, 0);
        tag.putInt(KILLS_KEY, 0);
        tag.putInt(BOSS_KILLS_KEY, 0);
        tag.putInt(SKELETON_KILLS_KEY, 0); tag.putInt(ENDERMAN_KILLS_KEY, 0);
        tag.putInt(SPIDER_KILLS_KEY, 0); tag.putInt(CREEPER_KILLS_KEY, 0);
        tag.putInt(DAMAGE_KEY, 0); tag.putInt(RANGE_KEY, 0); tag.putInt(TARGETS_KEY, 0);
        tag.putInt(DEFENSE_KEY, 0); tag.putInt(EQUIPMENT_KEY, 0); tag.putInt(DURATION_KEY, 0);
        tag.putInt(CONTROL_KEY, 0); tag.putInt(CRITICAL_KEY, 0); tag.putInt(ELEMENTAL_KEY, 0);
        tag.putInt(MOBILITY_KEY, 0); tag.putInt(SPENT_KEY, 0); tag.putInt(STYLE_KEY, 0);
        CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
        return stack;
    }

    public static int useCount(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(USES_KEY, 0)); }

    /** Kill-earned damage points affect damage gradually with diminishing returns; skill levels have no cap. */
    public static int effectTier(ItemStack stack) {
        int damage = upgradeLevel(stack, Upgrade.DAMAGE);
        return Math.max(0, (int) Math.floor(Math.log1p(Math.max(0, damage)) * 2.2D));
    }
    public static int rangeLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.RANGE); }
    public static int targetLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.TARGETS); }
    public static int defenseLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.DEFENSE); }
    public static int equipmentLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.EQUIPMENT); }
    public static int durationLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.DURATION); }
    public static int controlLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.CONTROL); }
    public static int criticalLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.CRITICAL); }
    public static int elementalLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.ELEMENTAL); }
    public static int mobilityLevel(ItemStack stack) { return upgradeLevel(stack, Upgrade.MOBILITY); }
    public static int style(ItemStack stack) { return Math.max(0, Math.min(2, readTag(stack).getIntOr(STYLE_KEY, 0))); }
    public static int kills(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(KILLS_KEY, 0)); }
    public static int bossKills(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(BOSS_KILLS_KEY, 0)); }
    public static int points(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(POINTS_KEY, 0)); }
    public static int spentPoints(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(SPENT_KEY, 0)); }

    /** Tracks activations for stats only. Activating a fused stone never raises a rank by itself. */
    public static int recordSuccessfulUse(ItemStack stack) {
        CompoundTag tag = copyTag(stack);
        int uses = Math.max(0, tag.getIntOr(USES_KEY, 0));
        uses = uses == Integer.MAX_VALUE ? Integer.MAX_VALUE : uses + 1;
        tag.putInt(USES_KEY, uses);
        CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
        return uses;
    }

    /** A kill made while this fused item is held gives points and an item-specific target counter. */
    public static int recordKill(ItemStack stack, boolean boss, net.minecraft.world.entity.LivingEntity victim) {
        if (!stack.is(ModItems.FUSED_ESSENCE) || readPowers(stack).isEmpty()) return 0;
        CompoundTag tag = copyTag(stack);
        increment(tag, KILLS_KEY, 1);
        int awarded = boss ? 12 : 1;
        increment(tag, POINTS_KEY, awarded);
        increment(tag, TOTAL_POINTS_KEY, awarded);
        if (boss) increment(tag, BOSS_KILLS_KEY, 1);
        if (victim != null) {
            var type = victim.getType();
            if (type == net.minecraft.world.entity.EntityType.SKELETON
                    || type == net.minecraft.world.entity.EntityType.WITHER_SKELETON
                    || type == net.minecraft.world.entity.EntityType.STRAY
                    || type == net.minecraft.world.entity.EntityType.BOGGED) increment(tag, SKELETON_KILLS_KEY, 1);
            if (type == net.minecraft.world.entity.EntityType.ENDERMAN) increment(tag, ENDERMAN_KILLS_KEY, 1);
            if (type == net.minecraft.world.entity.EntityType.SPIDER
                    || type == net.minecraft.world.entity.EntityType.CAVE_SPIDER) increment(tag, SPIDER_KILLS_KEY, 1);
            if (type == net.minecraft.world.entity.EntityType.CREEPER) increment(tag, CREEPER_KILLS_KEY, 1);
        }
        CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
        return awarded;
    }

    private static void increment(CompoundTag tag, String key, int amount) {
        int oldValue = Math.max(0, tag.getIntOr(key, 0));
        tag.putInt(key, oldValue > Integer.MAX_VALUE - amount ? Integer.MAX_VALUE : oldValue + amount);
    }

    /** Per-essence monster counters are permanent and are used by branch-specific milestones. */
    public static int skeletonKills(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(SKELETON_KILLS_KEY, 0)); }
    public static int endermanKills(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(ENDERMAN_KILLS_KEY, 0)); }
    public static int spiderKills(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(SPIDER_KILLS_KEY, 0)); }
    public static int creeperKills(ItemStack stack) { return Math.max(0, readTag(stack).getIntOr(CREEPER_KILLS_KEY, 0)); }

    /** Reaching each fifth milestone in selected branches requires special mob kills with this same essence. */
    public static int requiredSpecialKills(ItemStack stack, Upgrade upgrade) {
        if (upgrade != Upgrade.CRITICAL && upgrade != Upgrade.RANGE
                && upgrade != Upgrade.CONTROL && upgrade != Upgrade.ELEMENTAL) return 0;
        int currentLevel = upgradeLevel(stack, upgrade);
        if (currentLevel >= Integer.MAX_VALUE) return Integer.MAX_VALUE;
        int nextLevel = currentLevel + 1;
        if (nextLevel < 5 || nextLevel % 5 != 0) return 0;
        return (nextLevel / 5) * 20;
    }

    public static int specialKills(ItemStack stack, Upgrade upgrade) {
        return switch (upgrade) {
            case CRITICAL -> skeletonKills(stack);
            case RANGE -> endermanKills(stack);
            case CONTROL -> spiderKills(stack);
            case ELEMENTAL -> creeperKills(stack);
            default -> 0;
        };
    }

    /** Reusable stones act as point catalysts. They are intentionally never consumed. */
    public static int applyCatalyst(ItemStack fused, ItemStack stone) {
        if (!fused.is(ModItems.FUSED_ESSENCE) || readPowers(fused).isEmpty() || !isUpgradeStone(stone)) return 0;
        int bonus = stone.is(ModItems.STONE_COMMON) ? 1
                : stone.is(ModItems.STONE_REFINED) ? 3
                : stone.is(ModItems.STONE_SUPERIOR) ? 6
                : stone.is(ModItems.STONE_LEGENDARY) ? 15 : 30;
        CompoundTag tag = copyTag(fused);
        int current = Math.max(0, tag.getIntOr(POINTS_KEY, 0));
        int next = current > Integer.MAX_VALUE - bonus ? Integer.MAX_VALUE : current + bonus;
        if (next == current) return 0;
        tag.putInt(POINTS_KEY, next);
        int lifetime = Math.max(0, tag.getIntOr(TOTAL_POINTS_KEY, 0));
        tag.putInt(TOTAL_POINTS_KEY, lifetime > Integer.MAX_VALUE - bonus ? Integer.MAX_VALUE : lifetime + bonus);
        CustomData.set(DataComponents.CUSTOM_DATA, fused, tag);
        return bonus;
    }

    public static int upgradeLevel(ItemStack stack, Upgrade upgrade) {
        CompoundTag tag = readTag(stack);
        String key = switch (upgrade) {
            case DAMAGE -> DAMAGE_KEY; case RANGE -> RANGE_KEY; case TARGETS -> TARGETS_KEY;
            case DEFENSE -> DEFENSE_KEY; case EQUIPMENT -> EQUIPMENT_KEY; case DURATION -> DURATION_KEY;
            case CONTROL -> CONTROL_KEY; case CRITICAL -> CRITICAL_KEY; case ELEMENTAL -> ELEMENTAL_KEY; case MOBILITY -> MOBILITY_KEY;
        };
        return Math.max(0, tag.getIntOr(key, 0));
    }

    /** Upgrade costs scale with branch level; effect formulas use diminishing returns. */
    public static int upgradeCost(ItemStack stack, Upgrade upgrade) {
        int level = upgradeLevel(stack, upgrade);
        int base = switch (upgrade) {
            case DAMAGE -> 1; case RANGE, DEFENSE, DURATION, MOBILITY -> 2;
            case TARGETS, EQUIPMENT, CONTROL, CRITICAL, ELEMENTAL -> 3;
        };
        return base + (int) Math.floor(Math.sqrt((double) level));
    }

    public static int requiredBossKills(ItemStack stack, Upgrade upgrade) {
        int currentLevel = upgradeLevel(stack, upgrade);
        if (currentLevel >= Integer.MAX_VALUE) return Integer.MAX_VALUE;
        int nextLevel = currentLevel + 1;
        // Every five levels after level 5 require one more lifetime boss kill, encouraging varied content.
        return nextLevel < 6 ? 0 : 1 + (nextLevel - 6) / 5;
    }

    public static boolean canUpgrade(ItemStack stack, Upgrade upgrade) {
        if (stack == null || stack.isEmpty() || upgrade == null
                || !stack.is(ModItems.FUSED_ESSENCE) || readPowers(stack).isEmpty()) return false;
        // The NBT counters are integers; refuse a no-op upgrade at numeric saturation rather than charging points.
        if (upgradeLevel(stack, upgrade) >= Integer.MAX_VALUE) return false;
        return points(stack) >= upgradeCost(stack, upgrade)
                && bossKills(stack) >= requiredBossKills(stack, upgrade)
                && specialKills(stack, upgrade) >= requiredSpecialKills(stack, upgrade);
    }

    public static boolean spendUpgrade(ItemStack stack, Upgrade upgrade) {
        if (upgrade == null || !canUpgrade(stack, upgrade)) return false;
        CompoundTag tag = copyTag(stack);
        int cost = upgradeCost(stack, upgrade);
        tag.putInt(POINTS_KEY, Math.max(0, tag.getIntOr(POINTS_KEY, 0) - cost));
        int spent = Math.max(0, tag.getIntOr(SPENT_KEY, 0));
        tag.putInt(SPENT_KEY, spent > Integer.MAX_VALUE - cost ? Integer.MAX_VALUE : spent + cost);
        String key = switch (upgrade) {
            case DAMAGE -> DAMAGE_KEY; case RANGE -> RANGE_KEY; case TARGETS -> TARGETS_KEY;
            case DEFENSE -> DEFENSE_KEY; case EQUIPMENT -> EQUIPMENT_KEY; case DURATION -> DURATION_KEY;
            case CONTROL -> CONTROL_KEY; case CRITICAL -> CRITICAL_KEY; case ELEMENTAL -> ELEMENTAL_KEY; case MOBILITY -> MOBILITY_KEY;
        };
        int current = Math.max(0, tag.getIntOr(key, 0));
        tag.putInt(key, current == Integer.MAX_VALUE ? Integer.MAX_VALUE : current + 1);
        CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
        return true;
    }

    public static int respec(ItemStack stack) {
        if (!stack.is(ModItems.FUSED_ESSENCE) || readPowers(stack).isEmpty()) return 0;
        CompoundTag tag = copyTag(stack);
        int refunded = Math.max(0, tag.getIntOr(SPENT_KEY, 0));
        int current = Math.max(0, tag.getIntOr(POINTS_KEY, 0));
        tag.putInt(POINTS_KEY, current > Integer.MAX_VALUE - refunded ? Integer.MAX_VALUE : current + refunded);
        tag.putInt(SPENT_KEY, 0);
        tag.putInt(DAMAGE_KEY, 0); tag.putInt(RANGE_KEY, 0); tag.putInt(TARGETS_KEY, 0);
        tag.putInt(DEFENSE_KEY, 0); tag.putInt(EQUIPMENT_KEY, 0); tag.putInt(DURATION_KEY, 0);
        tag.putInt(CONTROL_KEY, 0); tag.putInt(CRITICAL_KEY, 0); tag.putInt(ELEMENTAL_KEY, 0);
        tag.putInt(MOBILITY_KEY, 0); tag.putInt(STYLE_KEY, 0);
        CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
        return refunded;
    }

    public static int cycleStyle(ItemStack stack) {
        CompoundTag tag = copyTag(stack);
        int style = (Math.max(0, tag.getIntOr(STYLE_KEY, 0)) + 1) % 3;
        tag.putInt(STYLE_KEY, style);
        CustomData.set(DataComponents.CUSTOM_DATA, stack, tag);
        return style;
    }

    public static String recipeSignature(List<EssenceItem.Power> powers) {
        List<EssenceItem.Power> canonical = new ArrayList<>(powers);
        canonical.sort((a, b) -> Integer.compare(a.ordinal(), b.ordinal()));
        return canonical.stream().map(Enum::name).collect(Collectors.joining("+"));
    }

    public static boolean hasTripleSynergy(List<EssenceItem.Power> powers) {
        if (powers.size() != 3) return false;
        int familyCount = (int) powers.stream().map(FusionData::family).distinct().count();
        return familyCount >= 3 || (powers.contains(EssenceItem.Power.THUNDER_STRIKE) && powers.contains(EssenceItem.Power.DASH));
    }

    /** Authored two-element reactions. Ordering never changes a recipe. */
    public static String binarySynergyKey(List<EssenceItem.Power> powers) {
        if (powers.size() != 2) return "";
        Set<EssenceItem.Power> set = Set.copyOf(powers);
        if (set.equals(Set.of(EssenceItem.Power.FIRE_WARD, EssenceItem.Power.FROST_EDGE))) return "thermal_shock";
        if (set.equals(Set.of(EssenceItem.Power.FIRE_WARD, EssenceItem.Power.THUNDER_STRIKE))) return "plasma_burst";
        if (set.equals(Set.of(EssenceItem.Power.FROST_EDGE, EssenceItem.Power.THUNDER_STRIKE))) return "cryo_storm";
        if (set.equals(Set.of(EssenceItem.Power.SHADOW, EssenceItem.Power.LIFE_LEECH))) return "soul_hunt";
        if (set.equals(Set.of(EssenceItem.Power.STONE_SKIN, EssenceItem.Power.REPULSE))) return "seismic_wall";
        if (set.equals(Set.of(EssenceItem.Power.DEEP_BREATH, EssenceItem.Power.FROST_EDGE))) return "glacier_breath";
        if (set.equals(Set.of(EssenceItem.Power.HEALING, EssenceItem.Power.REGENERATION))) return "renewal";
        if (set.equals(Set.of(EssenceItem.Power.SPEED, EssenceItem.Power.DASH))) return "windrunner";
        if (set.equals(Set.of(EssenceItem.Power.NIGHT_SIGHT, EssenceItem.Power.SHADOW_STEP))) return "night_rider";
        if (set.equals(Set.of(EssenceItem.Power.MINER, EssenceItem.Power.PROSPECTOR))) return "deep_seeker";
        return "";
    }

    /** Eight authored secret triple combinations unlock bespoke effects. */
    public static String secretTripleKey(List<EssenceItem.Power> powers) {
        if (powers.size() != 3) return "";
        Set<EssenceItem.Power> set = Set.copyOf(powers);
        if (set.equals(Set.of(EssenceItem.Power.THUNDER_STRIKE, EssenceItem.Power.DASH, EssenceItem.Power.SHADOW_STEP))) return "storm_phantom";
        if (set.equals(Set.of(EssenceItem.Power.FIRE_WARD, EssenceItem.Power.FROST_EDGE, EssenceItem.Power.THUNDER_STRIKE))) return "prism_tempest";
        if (set.equals(Set.of(EssenceItem.Power.HEALING, EssenceItem.Power.REGENERATION, EssenceItem.Power.LIFE_LEECH))) return "eternal_cycle";
        if (set.equals(Set.of(EssenceItem.Power.STONE_SKIN, EssenceItem.Power.REPULSE, EssenceItem.Power.ENERGY_SHIELD))) return "fortress";
        if (set.equals(Set.of(EssenceItem.Power.SHADOW, EssenceItem.Power.SHADOW_STEP, EssenceItem.Power.NIGHT_SIGHT))) return "night_reaper";
        if (set.equals(Set.of(EssenceItem.Power.DEEP_BREATH, EssenceItem.Power.FROST_EDGE, EssenceItem.Power.FEATHERFALL))) return "glacier_diver";
        if (set.equals(Set.of(EssenceItem.Power.MINER, EssenceItem.Power.PROSPECTOR, EssenceItem.Power.HUNTER))) return "relic_hunter";
        if (set.equals(Set.of(EssenceItem.Power.STRENGTH, EssenceItem.Power.EVOLUTION_SURGE, EssenceItem.Power.THUNDER_STRIKE))) return "overdrive";
        return "";
    }

    private enum Family { FIRE, ICE, SHADOW, STORM, EARTH, LIFE, NATURE }
    private static Family family(EssenceItem.Power p) {
        return switch (p) {
            case FIRE_WARD, EVOLUTION_SURGE -> Family.FIRE;
            case FROST_EDGE, DEEP_BREATH -> Family.ICE;
            case SHADOW, SHADOW_STEP, NIGHT_SIGHT -> Family.SHADOW;
            case THUNDER_STRIKE, SPEED, DASH -> Family.STORM;
            case STONE_SKIN, STRENGTH, REPULSE -> Family.EARTH;
            case HEALING, REGENERATION, ABSORPTION, LIFE_LEECH, ENERGY_SHIELD, VENOM_GUARD -> Family.LIFE;
            case LEAP, MINER, FEATHERFALL, HUNTER, DANGER_SENSE, PROSPECTOR -> Family.NATURE;
            case GRAND_ASCENSION -> Family.NATURE;
        };
    }
    private static int compatibilityScore(List<EssenceItem.Power> powers) {
        int score = 0;
        for (int i = 0; i < powers.size(); i++) for (int j = i + 1; j < powers.size(); j++) {
            Family a = family(powers.get(i)), b = family(powers.get(j));
            if (a == b) score++;
            else if ((a == Family.FIRE && b == Family.ICE) || (a == Family.ICE && b == Family.FIRE)
                    || (a == Family.SHADOW && b == Family.LIFE) || (a == Family.LIFE && b == Family.SHADOW)) score--;
            else if ((a == Family.STORM && b == Family.FIRE) || (a == Family.FIRE && b == Family.STORM)
                    || (a == Family.ICE && b == Family.LIFE) || (a == Family.LIFE && b == Family.ICE)
                    || (a == Family.NATURE && b == Family.LIFE) || (a == Family.LIFE && b == Family.NATURE)) score++;
        }
        return score;
    }
    private static CompoundTag readTag(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data == null || data.isEmpty() ? new CompoundTag() : data.copyTag();
    }
    private static CompoundTag copyTag(ItemStack stack) { return readTag(stack); }

    public static int ordinaryPowerCount() {
        int count = 0;
        for (EssenceItem.Power power : EssenceItem.Power.values()) if (power != EssenceItem.Power.GRAND_ASCENSION) count++;
        return count;
    }
    public static int pairCombinationCount() { int n = ordinaryPowerCount(); return n * (n - 1) / 2; }
    public static int tripleCombinationCount() { int n = ordinaryPowerCount(); return n * (n - 1) * (n - 2) / 6; }
}
