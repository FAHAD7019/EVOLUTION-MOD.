package dev.evolution.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** Fusion, reusable-stone upgrade and per-stone skill-tree interface. */
public final class FusionScreen extends AbstractContainerScreen<FusionMenu> {
    public FusionScreen(FusionMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 260;
        imageHeight = 268;
        inventoryLabelY = 153;
    }

    private void sendButton(int id) {
        if (minecraft != null && minecraft.gameMode != null)
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.translatable("button.evolution.fusion.combine"), b -> sendButton(FusionMenu.BUTTON_FUSE)).bounds(leftPos + 6, topPos + 57, 80, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("button.evolution.fusion.separate"), b -> sendButton(FusionMenu.BUTTON_SPLIT)).bounds(leftPos + 90, topPos + 57, 80, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("button.evolution.fusion.upgrade"), b -> sendButton(FusionMenu.BUTTON_UPGRADE)).bounds(leftPos + 174, topPos + 57, 80, 20).build());

        addSkillButton("button.evolution.skill.damage", FusionMenu.BUTTON_DAMAGE, 4, 81);
        addSkillButton("button.evolution.skill.range", FusionMenu.BUTTON_RANGE, 54, 81);
        addSkillButton("button.evolution.skill.targets", FusionMenu.BUTTON_TARGETS, 104, 81);
        addSkillButton("button.evolution.skill.defense", FusionMenu.BUTTON_DEFENSE, 154, 81);
        addSkillButton("button.evolution.skill.equipment", FusionMenu.BUTTON_EQUIPMENT, 204, 81);
        addSkillButton("button.evolution.skill.duration", FusionMenu.BUTTON_DURATION, 4, 101);
        addSkillButton("button.evolution.skill.control", FusionMenu.BUTTON_CONTROL, 54, 101);
        addSkillButton("button.evolution.skill.critical", FusionMenu.BUTTON_CRITICAL, 104, 101);
        addSkillButton("button.evolution.skill.elemental", FusionMenu.BUTTON_ELEMENTAL, 154, 101);
        addSkillButton("button.evolution.skill.mobility", FusionMenu.BUTTON_MOBILITY, 204, 101);
        addRenderableWidget(Button.builder(Component.translatable("button.evolution.skill.style"), b -> sendButton(FusionMenu.BUTTON_STYLE))
                .bounds(leftPos + 38, topPos + 123, 84, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("button.evolution.skill.respec"), b -> sendButton(FusionMenu.BUTTON_RESPEC))
                .bounds(leftPos + 138, topPos + 123, 84, 18).build());
    }

    private void addSkillButton(String label, int action, int x, int y) {
        addRenderableWidget(Button.builder(Component.translatable(label), b -> sendButton(action))
                .bounds(leftPos + x, topPos + y, 48, 18).build());
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        graphics.fill(x, y, x + imageWidth, y + imageHeight, 0xF0181724);
        graphics.fill(x, y, x + imageWidth, y + 2, 0xFFFFD36B);
        graphics.fill(x, y + imageHeight - 2, x + imageWidth, y + imageHeight, 0xFF7C52C8);
        graphics.fill(x, y, x + 2, y + imageHeight, 0xFFFFD36B);
        graphics.fill(x + imageWidth - 2, y, x + imageWidth, y + imageHeight, 0xFF7C52C8);
        graphics.fill(x + 8, y + 25, x + imageWidth - 8, y + 51, 0xAA332B4C);
        graphics.fill(x + 8, y + 158, x + imageWidth - 8, y + 262, 0x99312A40);
        for (int i = 0; i < 3; i++) drawSlot(graphics, x + 91 + i * 36, y + 34);
        graphics.drawString(font, "+", x + 112, y + 38, 0xFFFFD36B, false);
        graphics.drawString(font, "+", x + 148, y + 38, 0xFFFFD36B, false);
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++) drawSlot(graphics, x + 49 + col * 18, y + 164 + row * 18);
        for (int col = 0; col < 9; col++) drawSlot(graphics, x + 49 + col * 18, y + 242);
        graphics.fill(x + 12, y + 142, x + imageWidth - 12, y + 143, 0xFF66518C);
    }

    private static void drawSlot(GuiGraphics graphics, int x, int y) {
        graphics.fill(x - 1, y - 1, x + 17, y + 17, 0xFF0C0C12);
        graphics.fill(x, y, x + 16, y + 16, 0xFF574D6A);
        graphics.fill(x + 1, y + 1, x + 15, y + 15, 0xFF282536);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        String heading = title.getString();
        graphics.drawString(font, heading, (imageWidth - font.width(heading)) / 2, 7, 0xFFFFD36B, false);
        graphics.drawString(font, Component.translatable("label.evolution.fusion.inputs"), 10, 20, 0xFFE9DDFB, false);
        String status = menu.previewStatus().getString();
        int maxStatusWidth = imageWidth - 20;
        if (font.width(status) > maxStatusWidth) status = "…";
        graphics.drawString(font, status, (imageWidth - font.width(status)) / 2, 144, 0xFFB8F4D0, false);
        graphics.drawString(font, Component.translatable("container.inventory"), 10, inventoryLabelY, 0xFFE9DDFB, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
