package dev.evolution.mod;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.EmptyLootItem;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

/** Adds a separate, rarity-weighted chance of finding reusable Evolution Stones in existing vanilla chests. */
public final class StoneLootModifier {
    private StoneLootModifier() {}

    public static void initialize() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (!source.isBuiltin()) return;
            // Use the current resource-key accessor for Minecraft 1.21.11.
            var tableId = key.identifier();
            if (!"minecraft".equals(tableId.getNamespace())) return;
            Weights weights = weightsFor(tableId.getPath());
            if (weights == null) return;

            LootPool.Builder pool = LootPool.lootPool()
                .setRolls(ConstantValue.exactly(1.0F))
                .add(EmptyLootItem.emptyItem().setWeight(weights.empty()))
                .add(LootItem.lootTableItem(ModItems.STONE_COMMON).setWeight(weights.common()))
                .add(LootItem.lootTableItem(ModItems.STONE_REFINED).setWeight(weights.refined()))
                .add(LootItem.lootTableItem(ModItems.STONE_SUPERIOR).setWeight(weights.superior()))
                .add(LootItem.lootTableItem(ModItems.STONE_LEGENDARY).setWeight(weights.legendary()))
                .add(LootItem.lootTableItem(ModItems.STONE_VOID).setWeight(weights.voidStone()));
            tableBuilder.withPool(pool);

            // The Rift Key is a second, independent roll. It opens the secret end-game zone.
            // It is never guaranteed: even late-game structures only have a tiny chance to contain it.
            int keyWeight = riftKeyWeight(tableId.getPath());
            if (keyWeight > 0) {
                LootPool.Builder keyPool = LootPool.lootPool()
                    .setRolls(ConstantValue.exactly(1.0F))
                    .add(EmptyLootItem.emptyItem().setWeight(10000 - keyWeight))
                    .add(LootItem.lootTableItem(ModItems.RIFT_KEY).setWeight(keyWeight));
                tableBuilder.withPool(keyPool);
            }
        });
    }

    private static Weights weightsFor(String path) {
        if (path.startsWith("chests/village/")) {
            // About a 10% chance for any stone; the Void Stone remains exceptionally rare.
            return new Weights(9000, 600, 300, 80, 19, 1);
        }
        if (path.contains("chests/end_city") || path.contains("chests/bastion")
                || path.contains("chests/ancient_city") || path.contains("chests/nether_bridge")) {
            // Dangerous late-game structures: roughly 30% chance for a stone and much better rare odds.
            return new Weights(7000, 1700, 850, 330, 100, 20);
        }
        if (path.contains("chests/desert_pyramid") || path.contains("chests/jungle_temple")
                || path.contains("chests/stronghold_") || path.contains("chests/pillager_outpost")
                || path.contains("chests/woodland_mansion") || path.contains("chests/buried_treasure")
                || path.contains("chests/trial_chambers") || path.contains("chests/underwater_ruin")) {
            // Mid-game structures: roughly 20% chance for a stone.
            return new Weights(8000, 1200, 550, 200, 45, 5);
        }
        if (path.contains("chests/simple_dungeon") || path.contains("chests/abandoned_mineshaft")
                || path.contains("chests/shipwreck") || path.contains("chests/igloo")
                || path.contains("chests/ruined_portal") || path.contains("chests/spawn_bonus_chest")) {
            // Small/early structures: roughly 15% chance for a stone; even rare stones can very rarely appear.
            return new Weights(8500, 950, 400, 120, 25, 5);
        }
        return null;
    }

    private static int riftKeyWeight(String path) {
        if (path.contains("chests/end_city") || path.contains("chests/ancient_city")
                || path.contains("chests/bastion") || path.contains("chests/nether_bridge")) return 25; // 0.25%
        if (path.contains("chests/stronghold_") || path.contains("chests/woodland_mansion")
                || path.contains("chests/trial_chambers")) return 5; // 0.05%
        return 0;
    }

    private record Weights(int empty, int common, int refined, int superior, int legendary, int voidStone) {}
}
