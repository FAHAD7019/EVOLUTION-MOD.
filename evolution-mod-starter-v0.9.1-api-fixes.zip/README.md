# EVOLUTION: World vs You — Source 0.9.1

EVOLUTION is a source project for Minecraft Java Edition **1.21.11**, Fabric, and Java 21. This archive contains source code and assets; it is **not a prebuilt JAR**. The current environment did not have Gradle or access to dependency download servers, so this release has not been compiled or launched in Minecraft here.

## What is in 0.9.1

- Deep-audit fix: loot-table keys use Minecraft 1.21.11 `ResourceKey.identifier()` rather than the older accessor.

### Fusing and point-based growth
- 26 original essences (25 ordinary powers plus Grand Ascension). Two-power fusions have 300 distinct combinations and three-power fusions have 2,300. The rare Grand Ascension essence cannot be fused.
- Fused essences are reusable and have no activation cooldown. They store their power IDs and independent progression data in the vanilla `custom_data` component.
- There are **no weak/medium/normal/strong upgrade ranks** and no automatic level-up every ten uses. Each fused essence earns its own points from hostile kills while held (1 point per normal kill; 12 for a major boss). Points stay with that specific fused item.
- Ten upgrade branches: damage, range, targets, defense, equipment resonance, duration, control, critical effects, elemental effects, and mobility. Costs grow by branch level; boss-kill milestones unlock higher levels. At every fifth milestone, selected branches additionally require accumulated kills of skeletons, Endermen, spiders, or creepers with that same fused item. Branch levels have no designed gameplay cap; counters are stored as Java integers and saturate at Integer.MAX_VALUE for data safety. Effect formulas use scaling and bounds to prevent unsafe world impact.
- The altar GUI supports point catalysts, all ten upgrades, activation-style switching, and refunding spent points through respec. Catalyst stones do not get consumed.
- Ten binary elemental reactions and eight secret triple recipes add effects beyond simply activating the component powers.

### Exploration, challenges, and economy
- The Trial Sigil opens a random-themed, enclosed arena with Easy/Medium/Hard/Impossible difficulties, waves, a multi-phase custom boss, and an exit that opens on victory. Each victory guarantees one random stone; additional loot and a possible second stone use separate random rolls.
- Original vanilla village and structure chest loot gets an extra weighted chance for reusable Evolution Stones; the original chest loot is preserved. Rare advanced structures have better odds. A separately rolled ultra-rare Rift Key can appear in selected late-game structures.
- Villager trades provide another stone/key acquisition path. The Rift Key opens a secret, high-difficulty rift challenge.

### Final ritual and Ender Dragon
- Carrying all **26 distinct unmerged original essences** triggers the “you can finish the game now” message and opens the Mythic Forge GUI. The menu accepts only one of each original essence; fused essences and duplicates are rejected. Forging consumes the 26 originals and grants a reusable Mythic Essence. Activating it grants all component powers plus strong temporary buffs and tags the player as a legend.
- The Ender Dragon is increased to 1,800 health and gets phase transitions, healing bursts, and additional Endermen. This is source-level behavior and still needs in-game balancing tests.

## Important gameplay details
- Ordinary essences, fused essences, upgrade stones, the Rift Key, and the Mythic Essence are reusable on activation. The mythic ritual intentionally consumes the 26 unmerged originals to create the final relic.
- Chest bonuses are generated when the loot table is rolled. Already-opened chests do not retroactively receive new items.
- This project has not been runtime-tested in Minecraft as part of this archive generation.

## Build environment
- Minecraft `1.21.11`
- Fabric Loader `0.20.1`
- Fabric API `0.141.6+1.21.11`
- Fabric Loom `1.14.10`
- Java `21`

`gradle.properties` pins the target versions. There is no complete Gradle Wrapper in the archive. In a connected environment with Gradle 9.2.1 available, run:

```bash
python3 tools/verify_project.py
gradle --no-daemon clean build
```

On Windows use `python tools\verify_project.py` then `gradle --no-daemon clean build`. The GitHub Actions workflow also runs static checks and uploads the actual remapped JAR if build succeeds. Back up worlds before testing; try a new single-player world first.

## Main code
- `ModItems.java`: item registration and creative tab
- `EssenceItem.java`: 26 base powers and effects
- `FusionData.java`: saved point balance, kill counts, ten upgrade branches and fusion recipe logic
- `FusionMenu.java` / `FusionScreen.java`: fusion, upgrade, style and respec GUI
- `TrialSystem.java`: arenas, waves, bosses and random rewards
- `StoneLootModifier.java` / `EvolutionTrades.java`: structure chest additions and villager trading
- `MythicForgeMenu.java` / `MythicEssenceItem.java`: final all-powers ritual and legendary state
- `EvolutionSystem.java`: world evolution, combat history, essence drops and Ender Dragon phases
- `tools/verify_project.py`: static resource/source consistency checks only (not a Java compilation or game launch)
